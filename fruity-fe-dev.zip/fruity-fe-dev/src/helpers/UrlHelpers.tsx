import { Location } from "react-router-dom";

export const getIdFromUrl = (url: Location): number => {
	const currentUrl = url.pathname.split("/");
	const id = currentUrl[currentUrl.length - 1];
	return parseInt(id);
};
