import { ReactElement } from "react";
import { WorkTypeVm } from "../core/be/WorkTypeVm";
import { Link } from "react-router-dom";
import routes, { routesParams } from "../config/routes";
import { Button } from "antd";
import { WorkVm } from "../core/be/WorkVm";

export const getAddonsWorkLinks = (
	workTypes: WorkTypeVm[] | undefined,
	selectedWork: WorkVm | undefined
): ReactElement => {
	if (workTypes === undefined || selectedWork === undefined) {
		return <></>;
	}
	const type = workTypes.find((type) => type.id === selectedWork.type.id);

	return (
		<>
			{type?.workersTab && (
				<Button>
					<Link
						to={routes.ROUTE_WORKS_WORKERS.replace(
							routesParams.workId,
							selectedWork.id.toString()
						)}>
						Djelatnici
					</Link>
				</Button>
			)}
			{type?.rowsTab && (
				<Button>
					<Link
						to={routes.ROUTE_WORKS_ROWS.replace(
							routesParams.workId,
							selectedWork.id.toString()
						)}>
						Redovi
					</Link>
				</Button>
			)}
			{type?.equipmentsTab && (
				<Button>
					<Link
						to={routes.ROUTE_WORKS_EQUIPMENTS.replace(
							routesParams.workId,
							selectedWork.id.toString()
						)}>
						Oprema
					</Link>
				</Button>
			)}
			{type?.attachmentsTab && (
				<Button>
					<Link
						to={routes.ROUTE_WORKS_ATTACHMENTS.replace(
							routesParams.workId,
							selectedWork.id.toString()
						)}>
						Priključci
					</Link>
				</Button>
			)}
			{type?.agentsTab && (
				<Button>
					<Link
						to={routes.ROUTE_WORKS_AGENTS.replace(
							routesParams.workId,
							selectedWork.id.toString()
						)}>
						Sredstva
					</Link>
				</Button>
			)}
		</>
	);
};

export const getAddonsRealisationLinks = (
	workTypes: WorkTypeVm[] | undefined,
	selectedWork: WorkVm | undefined,
	realisationId: number | undefined
): ReactElement => {
	if (
		workTypes === undefined ||
		selectedWork === undefined ||
		realisationId === undefined
	) {
		return <></>;
	}
	const type = workTypes.find((type) => type.id === selectedWork.type.id);

	return (
		<>
			{type?.rowsTab && (
				<Button>
					<Link
						to={routes.ROUTE_REALISATIONS_ROWS.replace(
							routesParams.realisationId,
							realisationId.toString()
						)}>
						Redovi
					</Link>
				</Button>
			)}
			{type?.equipmentsTab && (
				<Button>
					<Link
						to={routes.ROUTE_REALISATIONS_EQUIPMENTS.replace(
							routesParams.realisationId,
							realisationId.toString()
						)}>
						Oprema
					</Link>
				</Button>
			)}
			{type?.attachmentsTab && (
				<Button>
					<Link
						to={routes.ROUTE_REALISATIONS_ATTACHMENTS.replace(
							routesParams.realisationId,
							realisationId.toString()
						)}>
						Priključci
					</Link>
				</Button>
			)}
			{type?.agentsTab && (
				<Button>
					<Link
						to={routes.ROUTE_REALISATIONS_AGENTS.replace(
							routesParams.realisationId,
							realisationId.toString()
						)}>
						Sredstva
					</Link>
				</Button>
			)}
			{type?.quantitiesTab && (
				<Button>
					<Link
						to={routes.ROUTE_REALISATIONS_QUANTITIES.replace(
							routesParams.realisationId,
							realisationId.toString()
						)}>
						Količine
					</Link>
				</Button>
			)}
		</>
	);
};
