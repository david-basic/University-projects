export const calculateTableDimensions = () => {
	const headerClass = document.getElementsByClassName("ant-table-thead");
	const tableHeaderClass =
		document.getElementsByClassName("header_container");

	console.log("height", window.innerHeight);
	console.log("header", headerClass.item(0)?.clientHeight);
	console.log("table header", tableHeaderClass.item(0)?.clientHeight);

	return {
		screenHeight: window.innerHeight || 0,
		headerHeight: headerClass.item(0)?.clientHeight || 0,
		tableHeaderHeight: tableHeaderClass.item(0)?.clientHeight || 0,
	};
};
