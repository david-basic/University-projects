import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../store";
import api_routes from "../config/api-routes";
import localforage from "localforage";
import { authActions } from "../store/auth-slice";
import routes from "../config/routes";
import { useCallback } from "react";
import { message } from "antd";

const useRefreshToken = () => {
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const refreshToken: string | undefined = useSelector(
		(state: RootState) => state.auth.refreshToken
	);

	const sendTokenRequest = useCallback(async () => {
		if (refreshToken !== "") {
			const response = await fetch(api_routes.ROUTE_AUTH_REFRESH_TOKEN, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({ refreshToken: refreshToken }),
			});

			const responseData = await response.json();

			if (responseData.error !== undefined) {
				localforage.clear();
				sessionStorage.clear();
				localStorage.clear();

				dispatch(authActions.setIsLoggedIn(false));
				dispatch(authActions.resetAllStateToDefaults());

				dispatch(authActions.setIsTokenValid(false));

				navigate(routes.ROUTE_AUTH, { replace: true }); //TODO: redirect ne radi instantno pa je ovo bolje rješenje
				message.warning(
					"Vaša sesija je istekla! Molimo vas prijavite se ponovo"
				);
			} else {
				dispatch(authActions.setIsTokenValid(true));
				dispatch(authActions.setTokenType(responseData.data.tokenType));
				dispatch(
					authActions.setAccessToken(responseData.data.accessToken)
				);
				dispatch(
					authActions.setRefreshToken(responseData.data.refreshToken)
				);
			}
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	return { sendTokenRequest };
};

export default useRefreshToken;
