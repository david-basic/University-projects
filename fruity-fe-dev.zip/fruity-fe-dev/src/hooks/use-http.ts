import { useCallback, useState } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../store";
import useRefreshToken from "./use-refreshToken";

const useHttp = () => {
	const [isLoading, setIsLoading] = useState(false);
	const { sendTokenRequest } = useRefreshToken();
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const fullToken = `${tokenType} ${token}`;
	const isLoggedIn = useSelector((state: RootState) => state.auth.isLoggedIn);
	const tokenIsValid = useSelector(
		(state: RootState) => state.auth.tokenValid
	);

	sendTokenRequest();

	const sendRequest = useCallback(
		async (
			requestConfig: RequestConfig,
			manageResponseData: (arg: any) => void
		) => {
			setIsLoading(true);

			// console.log("Token state:");
			// console.log(tokenIsValid);
			// console.log("Logged in state:");
			// console.log(isLoggedIn);
			// console.log("refreshToken:");
			// console.log(refreshToken);
			if (tokenIsValid || !isLoggedIn) {
				// console.log("I fetch data");
				const response = await fetch(requestConfig.url, {
					method: requestConfig.method ? requestConfig.method : "GET",
					headers: requestConfig.headers
						? requestConfig.headers
						: {
								Authorization: fullToken,
						  },
					body: requestConfig.body
						? JSON.stringify(requestConfig.body)
						: null,
				});

				const responseData = await response.json();

				manageResponseData(responseData);

				setIsLoading(false);
			}
		},
		// eslint-disable-next-line react-hooks/exhaustive-deps
		[]
	);

	return {
		isLoading,
		sendRequest,
	};
};

export default useHttp;
