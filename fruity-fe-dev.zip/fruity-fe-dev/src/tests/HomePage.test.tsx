import HomePage from "../pages/HomePage";
import { render, screen } from "@testing-library/react";

describe("HomePage component", () => {
	test("rendered.", () => {
		render(<HomePage />);

		const imgElement: HTMLImageElement = screen.getByTestId("imgTag");

		expect(imgElement).toBeInTheDocument();
	});
});
