import MatchMediaMock from "jest-matchmedia-mock";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Login from "../components/Auth/Login";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import * as reactRedux from "react-redux";
import store from "../store/index";

const mockedUsedNavigate = jest.fn();
jest.mock("react-router-dom", () => ({
	...(jest.requireActual("react-router-dom") as any),
	useNavigate: () => mockedUsedNavigate,
}));

const mockedUsedDispatch = jest.fn();
jest.mock("react-redux", () => ({
	...(jest.requireActual("react-redux") as any),
	useDispatch: () => mockedUsedDispatch,
}));

let matchMedia: any;

describe("Login component", () => {
	const useDispatchMock = jest.spyOn(reactRedux, "useDispatch");
	const useSelectorMock = jest.spyOn(reactRedux, "useSelector");

	beforeAll(() => {
		matchMedia = new MatchMediaMock();
	});

	beforeEach(() => {
		useDispatchMock.mockClear();
		useSelectorMock.mockClear();
	});

	afterEach(() => {
		matchMedia.clear();
	});

	test("renders login form", () => {
		render(
			<Provider store={store}>
				<BrowserRouter>
					<Login />
				</BrowserRouter>
			</Provider>
		);

		const loginFormElement = screen.queryByTestId("loginForm");

		expect(loginFormElement).toBeInTheDocument();
	});

	test("renders username input field", () => {
		render(
			<Provider store={store}>
				<BrowserRouter>
					<Login />
				</BrowserRouter>
			</Provider>
		);

		const inputFormElement = screen.queryByTestId("usernameInput");

		expect(inputFormElement).toBeInTheDocument();
	});

	test("renders password input field", () => {
		render(
			<Provider store={store}>
				<BrowserRouter>
					<Login />
				</BrowserRouter>
			</Provider>
		);

		const inputFormElement = screen.queryByTestId("passwordInput");

		expect(inputFormElement).toBeInTheDocument();
	});

	test("renders a login button", () => {
		render(
			<Provider store={store}>
				<BrowserRouter>
					<Login />
				</BrowserRouter>
			</Provider>
		);

		const loginBtn = screen.queryByTestId("loginButton");

		expect(loginBtn).toBeInTheDocument();
	});

	test("does not navigate to different URL when no input data given", async () => {
		render(
			<Provider store={store}>
				<BrowserRouter>
					<Login />
				</BrowserRouter>
			</Provider>
		);

		const oldURL = window.location.pathname;

		const loginBtn = screen.getByTestId("loginButton");
		userEvent.click(loginBtn);

		const currURL = window.location.pathname;

		expect(currURL).toBe(oldURL);
	});
});
