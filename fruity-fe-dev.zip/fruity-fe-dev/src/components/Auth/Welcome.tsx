import { Button } from "antd";
import styles from "./Welcome.module.css";
import { useNavigate } from "react-router-dom";
import routes from "../../config/routes";
import { useSelector } from "react-redux";
import { useEffect } from "react";
import { RootState } from "../../store";

const Welcome = () => {
	const navigate = useNavigate();
	const isLoggedIn: boolean = useSelector(
		(state: RootState) => state.auth.isLoggedIn
	);

	useEffect(() => {
		if (isLoggedIn) {
			navigate(routes.ROUTE_HOME, { replace: true });
		}
	}, [isLoggedIn, navigate]);

	const clickHandler = () => {
		navigate(routes.ROUTE_AUTH, { replace: true });
	};

	return (
		<div className={`${styles.content} ${styles["centered-element"]}`}>
			<ul>
				<li>
					<h1>Dobrodošli!</h1>
				</li>
				<li>
					<p className={styles["lighter-text"]}>
						Molimo vas provjerite svoj email. <br />
						Poslali smo vam link za potvrdu.
					</p>
				</li>
				<li>
					<Button
						className={styles["btn-rounded-dark"]}
						shape='round'
						size='large'
						type='text'
						onClick={clickHandler}>
						Nastavi
					</Button>
				</li>
			</ul>
		</div>
	);
};

export default Welcome;
