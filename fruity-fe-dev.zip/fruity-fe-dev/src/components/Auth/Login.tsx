import { FC, useEffect, useState } from "react";
import styles from "./Login.module.css";
import { LockOutlined, UserOutlined } from "@ant-design/icons";
import { Button, Form, Input } from "antd";
import { NavLink, useNavigate } from "react-router-dom";
import useHttp from "../../hooks/use-http";
import { useDispatch, useSelector } from "react-redux";
import { authActions } from "../../store/auth-slice";
import api_routes from "../../config/api-routes";
import routes from "../../config/routes";
import localforage from "localforage";
import { RootState } from "../../store/index";

const Login: FC = () => {
	const [loginValid, setLoginValid] = useState(true);
	const [loginErrorMessage, setLoginErrorMessage] = useState("");
	const { sendRequest: sendLoginRequest } = useHttp();
	const dispatch = useDispatch();
	const navigate = useNavigate();
	const isLoggedIn: boolean = useSelector(
		(state: RootState) => state.auth.isLoggedIn
	);

	useEffect(() => {
		if (isLoggedIn) {
			navigate(routes.ROUTE_HOME, { replace: true });
		}
	}, [isLoggedIn, navigate]);

	const onSubmit = (values: any) => {
		const userData = {
			username: values.username,
			password: values.password,
		};

		sendLoginRequest(
			{
				url: api_routes.ROUTE_AUTH_LOGIN,
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: userData,
			},
			manageLoginResponseData.bind(null, userData.username)
		);

		function manageLoginResponseData(username: string, loginData: any) {
			if (loginData.status !== 200) {
				setLoginValid(false);
				setLoginErrorMessage(loginData.message);

				dispatch(authActions.setIsLoggedIn(false));
				localforage.setItem<boolean>("isLoggedIn", false);

				// console.log(loginErrorMessage);
			} else {
				dispatch(
					authActions.setAccessToken(loginData.data.accessToken)
				);
				dispatch(
					authActions.setRefreshToken(loginData.data.refreshToken)
				);
				dispatch(authActions.setTokenType(loginData.data.tokenType));
				dispatch(authActions.setIsTokenValid(true));

				dispatch(authActions.setUsername(username));
				dispatch(authActions.setIsLoggedIn(true));

				localforage.setItem<string>(
					"accessToken",
					loginData.data.accessToken
				);
				localforage.setItem<string>(
					"refreshToken",
					loginData.data.refreshToken
				);
				localforage.setItem<string>(
					"tokenType",
					loginData.data.tokenType
				);
				localforage.setItem<string>("username", username);
				localforage.setItem<boolean>("isLoggedIn", true);

				sessionStorage.setItem("canFetchUserData", "true");

				navigate(routes.ROUTE_HOME, { replace: true });
			}
		}
	};

	return (
		<div className={`${styles.content} ${styles["centered-element"]}`}>
			<Form
				name='login'
				className='login-form'
				onFinish={onSubmit}
				data-testid='loginForm'>
				<h1>Prijava</h1>
				<p className={styles["lighter-text"]}>
					Unesite svoje podatke za nastavak
				</p>
				{!loginValid && (
					<p className={styles["error-text"]}>{loginErrorMessage}</p>
				)}
				<Form.Item
					name='username'
					rules={[
						{
							required: true,
							message: "Molimo vas unesite Korisničko ime!",
						},
					]}>
					<Input
						data-testid='usernameInput'
						suffix={
							<UserOutlined className='site-form-item-icon' />
						}
						placeholder='Korisničko ime'
					/>
				</Form.Item>
				<Form.Item
					name='password'
					rules={[
						{
							required: true,
							message: "Molimo vas unesite Zaporku!",
						},
					]}>
					<Input
						data-testid='passwordInput'
						suffix={
							<LockOutlined className='site-form-item-icon' />
						}
						type='password'
						placeholder='Zaporka'
					/>
				</Form.Item>
				<Form.Item>
					<NavLink
						className={styles["link-text"]}
						to={routes.ROUTE_AUTH_PASSWORD_RESET}
						replace={true}>
						Ne sjećam se lozinke.
					</NavLink>
				</Form.Item>
				<Form.Item>
					<Button
						type='text'
						shape='round'
						size='large'
						htmlType='submit'
						data-testid='loginButton'
						className={styles["btn-rounded-dark"]}>
						Prijavi se
					</Button>
				</Form.Item>
				<p className={styles["lighter-text"]}>
					Nemam korisnički račun.{" "}
					<NavLink
						className={styles["link-text"]}
						to={routes.ROUTE_AUTH_SIGNUP}
						replace={true}>
						Registriraj se.
					</NavLink>
				</p>
			</Form>
		</div>
	);
};

export default Login;
