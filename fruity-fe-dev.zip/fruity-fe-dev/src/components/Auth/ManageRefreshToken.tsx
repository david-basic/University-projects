import React, { FC, ReactElement } from "react";
import useHttp from "../../hooks/use-http";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../store";
import api_routes from "../../config/api-routes";
import { authActions } from "../../store/auth-slice";
import localforage from "localforage";
import { useNavigate } from "react-router-dom";
import routes from "../../config/routes";

interface Props {
	children?: ReactElement;
}

const ManageRefreshToken: FC<Props> = (props: Props) => {
	const { sendRequest: fetchRequest } = useHttp();
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const refreshToken: string = useSelector(
		(state: RootState) => state.auth.refreshToken
	);

	fetchRequest(
		{
			url: api_routes.ROUTE_AUTH_REFRESH_TOKEN,
			method: "POST",
			headers: {
				"Content-Type": "application/json",
			},
			body: { refreshToken: refreshToken },
		},
		manageTokenRefreshResponse.bind(null)
	);

	function manageTokenRefreshResponse(responseData: any) {
		if (responseData.error !== undefined) {
			localforage.clear();
			sessionStorage.clear();
			localStorage.clear();

			dispatch(authActions.setIsLoggedIn(false));
			dispatch(authActions.resetAllStateToDefaults());

			navigate(routes.ROUTE_AUTH, { replace: true });
		}
	}

	const { children } = props;
	return <>{children}</>;
};

export default ManageRefreshToken;
