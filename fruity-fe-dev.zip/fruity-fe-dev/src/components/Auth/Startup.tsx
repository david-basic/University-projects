import { FC, useEffect } from "react";
import styles from "./Startup.module.css";
import { Button } from "antd";
import { useNavigate } from "react-router-dom";
import routes from "../../config/routes";
import { useSelector } from "react-redux";
import { RootState } from "../../store/index";

const Startup: FC = () => {
	const navigate = useNavigate();
	const isLoggedIn: boolean = useSelector(
		(state: RootState) => state.auth.isLoggedIn
	);

	useEffect(() => {
		if (isLoggedIn) {
			navigate(routes.ROUTE_HOME, { replace: true });
		}
	}, [isLoggedIn, navigate]);

	const navigateToSignup = () => {
		navigate(routes.ROUTE_AUTH_SIGNUP, { replace: true });
	};
	const navigateToLogin = () => {
		navigate(routes.ROUTE_AUTH_LOGIN, { replace: true });
	};

	return (
		<div className={`${styles.content} ${styles["centered-element"]}`}>
			<ul>
				<li>
					<h1>Dobrodošli u Fruity,</h1>
					<h1>najbolji voćarski app!</h1>
				</li>
				<li className={styles["lighter-text"]}>
					<p>
						Hvala Vam što ste za svoj OPG odabrali Fruity.
						<br /> Nećete požaliti!
					</p>
				</li>
				<li>
					<Button
						className={styles["btn-rounded-dark"]}
						type='text'
						shape='round'
						size='large'
						onClick={navigateToSignup}>
						Registriraj se
					</Button>
				</li>
				<li>
					<Button
						className={styles["btn-rounded-light"]}
						type='text'
						shape='round'
						size='large'
						onClick={navigateToLogin}>
						Prijavi se
					</Button>
				</li>
				<li className={styles["lighter-text"]}>
					<p>
						Pristupanjem aplikaciji, prihvaćate Terms and Conditions
						<br /> i Privacy politiku!
					</p>
				</li>
			</ul>
		</div>
	);
};

export default Startup;
