import { useNavigate } from "react-router-dom";
import styles from "./Terms.module.css";
import { Button, Checkbox, Form } from "antd";
import routes from "../../config/routes";
import { useEffect } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../../store";

const Terms = () => {
	const navigate = useNavigate();
	const isLoggedIn: boolean = useSelector(
		(state: RootState) => state.auth.isLoggedIn
	);

	useEffect(() => {
		if (isLoggedIn) {
			navigate(routes.ROUTE_HOME, { replace: true });
		}
	}, [isLoggedIn, navigate]);

	const onFinish = (values: any) => {
		console.log(values);
		navigate(routes.ROUTE_AUTH_WELCOME, { replace: true });
	};

	return (
		<div className={`${styles.content} ${styles["centered-element"]}`}>
			<Form
				name='terms'
				initialValues={{ remember: false }}
				className={styles["terms-form"]}
				onFinish={onFinish}>
				<Form.Item>
					<h1>Terms & Conditions</h1>
					<p className={styles["lighter-text"]}>
						Molimo vas da prihvatite GDPR politiku privatnosti.
						<br />
						Prateći GDPR politiku privatnost vi u svakom trenu
						<br />
						možete zatražiti brisanje vaših osobnih podataka.
						<br />
						Pritiskom na kvačice također prihvaćate da ćete
						<br />
						aplikaciju koristiti prateći pravila korištenja.
					</p>
				</Form.Item>
				<Form.Item>
					<Form.Item
						name='tos'
						valuePropName='checked'
						rules={[
							{
								required: true,
								message:
									"Za nastavak morate prihvatiti TOS i politiku privatnosti",
							},
						]}>
						<Checkbox name='accept'>
							Prihvaćam TOS i Privacy politiku.
						</Checkbox>
					</Form.Item>
				</Form.Item>
				<Form.Item>
					<Button
						type='text'
						shape='round'
						size='large'
						htmlType='submit'
						className={styles["btn-rounded-dark"]}>
						Nastavi
					</Button>
				</Form.Item>
			</Form>
		</div>
	);
};

export default Terms;
