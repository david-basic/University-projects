import { LockOutlined } from "@ant-design/icons";
import { Button, Form, Input } from "antd";
import { FC } from "react";
import { Link, redirect } from "react-router-dom";
import styles from "./PwdResetForm.module.css";
import routes from "../../config/routes";

const PwdResetForm: FC = () => {
	const onFinish = (values: any) => {
		console.log(values);

		//TODO: needs backend logic for changing passwords

		redirect(routes.ROUTE_AUTH);
	};

	return (
		<div className={`${styles.content} ${styles["centered-element"]}`}>
			<Form
				name='passowrd-change'
				initialValues={{ remember: false }}
				className={styles["reset-form"]}
				onFinish={onFinish}>
				<h1>
					<LockOutlined /> Forma za reset lozinke
				</h1>
				<Form.Item
					name='old-password'
					hasFeedback
					rules={[
						{
							required: true,
							message: "Potrebno je unesti staru lozinku!",
						},
					]}>
					<Input
						suffix={<LockOutlined />}
						type='password'
						placeholder='Stara lozinka'
					/>
				</Form.Item>
				<Form.Item
					name='password'
					hasFeedback
					rules={[
						{
							required: true,
							pattern: new RegExp(
								"^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,255}$"
							),
							message:
								"Lozinka mora biti min 8, max 250 znakova, mora sadržavati minimalno jedan broj, jedno malo slovo, jedno veliko slovo, jedan specijalni znak i ne smije sadržavati razmake.",
						},
						({ getFieldValue }) => ({
							validator(_, value) {
								if (
									!value ||
									getFieldValue("old-password") !== value
								) {
									return Promise.resolve();
								}
								return Promise.reject(
									new Error(
										"Stara i nova lozinka se NE smiju poklapati!"
									)
								);
							},
						}),
					]}>
					<Input
						suffix={<LockOutlined />}
						type='password'
						placeholder='Nova lozinka'
					/>
				</Form.Item>
				<Form.Item
					name='confirmPassword'
					dependencies={["password"]}
					hasFeedback
					rules={[
						{
							required: true,
							message: "Molimo vas potvrdite lozinku!",
						},
						({ getFieldValue }) => ({
							validator(_, value) {
								if (
									!value ||
									getFieldValue("password") === value
								) {
									return Promise.resolve();
								}
								return Promise.reject(
									new Error(
										"Unesene lozinke se ne poklapaju!"
									)
								);
							},
						}),
					]}>
					<Input.Password placeholder='Potvrdite lozinku' />
				</Form.Item>
				<Form.Item>
					<Link to={routes.ROUTE_AUTH}>
						<Button
							type='text'
							shape='round'
							size='large'
							style={{ margin: "5px" }}
							className={styles["btn-rounded-dark"]}>
							Odustani
						</Button>
					</Link>
					<Button
						type='text'
						shape='round'
						size='large'
						htmlType='submit'
						style={{ margin: "5px" }}
						className={styles["btn-rounded-dark"]}>
						Potvrdi
					</Button>
				</Form.Item>
			</Form>
		</div>
	);
};

export default PwdResetForm;
