import { FC, useRef, useState } from "react";
import styles from "./Signup.module.css";
import {
	LockOutlined,
	IdcardOutlined,
	UserOutlined,
	MailOutlined,
	NumberOutlined,
} from "@ant-design/icons";
import { Button, Checkbox, Form, Input, InputRef } from "antd";
import { NavLink, useNavigate } from "react-router-dom";
import useHttp from "../../hooks/use-http";
import api_routes from "../../config/api-routes";
import routes from "../../config/routes";

const Signup: FC = () => {
	const navigate = useNavigate();
	const { sendRequest: sendRegisterRequest } = useHttp();
	const [registerErrorMessage, setRegisterErrorMessage] = useState("");

	const firstNameRef = useRef<InputRef>(null);
	const lastNameRef = useRef<InputRef>(null);
	const usernameRef = useRef<InputRef>(null);
	const emailRef = useRef<InputRef>(null);
	const oibRef = useRef<InputRef>(null);
	const passwordRef = useRef<InputRef>(null);

	const onFinish = (values: any) => {
		const registerUserInputData = {
			firstName: values.firstname,
			lastName: values.lastname,
			username: values.username,
			email: values.email,
			oib: values.oib,
			password: values.password,
			confirmRegistrationUrl: "http://localhost:4000/auth/congrats",
		};

		const manageRegisterResponseData = (registerResponseData: any) => {
			if (registerResponseData.success === undefined) {
				console.log("There was response error");
				setRegisterErrorMessage(registerResponseData.message);
			} else {
				setRegisterErrorMessage("");

				navigate(routes.ROUTE_AUTH_TERMS, { replace: true });
			}
		};

		sendRegisterRequest(
			{
				url: api_routes.ROUTE_AUTH_REGISTER,
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: registerUserInputData,
			},
			manageRegisterResponseData.bind(null)
		);
	};

	return (
		<div className={`${styles.content} ${styles["centered-element"]}`}>
			<Form
				name='signup'
				initialValues={{ remember: false }}
				className={styles["signup-form"]}
				onFinish={onFinish}>
				<h1>Registracija</h1>
				<p className={styles["lighter-text"]}>
					Unesite svoje podatke za nastavak
				</p>
				{registerErrorMessage !== "" && (
					<p className={styles["error-text"]}>
						{registerErrorMessage}
					</p>
				)}
				<Form.Item
					name='firstname'
					rules={[
						{
							required: true,
							message: "Molimo unesite vaše Ime!",
						},
					]}>
					<Input
						suffix={<IdcardOutlined />}
						placeholder='Ime'
						ref={firstNameRef}
					/>
				</Form.Item>
				<Form.Item
					name='lastname'
					rules={[
						{
							required: true,
							message: "Molimo unesite vaše Prezime!",
						},
					]}>
					<Input
						suffix={<IdcardOutlined />}
						placeholder='Prezime'
						ref={lastNameRef}
					/>
				</Form.Item>
				<Form.Item
					name='username'
					rules={[
						{
							required: true,
							message: "Molimo unesite vaše korisničko ime!",
						},
						({ getFieldValue }) => ({
							validator(_) {
								if (getFieldValue("username").length >= 5) {
									return Promise.resolve();
								}
								return Promise.reject(
									new Error(
										"Duljina korisničkog imena mora biti više od 5 znakova"
									)
								);
							},
						}),
					]}>
					<Input
						suffix={<UserOutlined />}
						placeholder='Korisničko ime'
						ref={usernameRef}
					/>
				</Form.Item>
				<Form.Item
					name='email'
					hasFeedback
					rules={[
						{
							required: true,
							pattern: new RegExp(
								// eslint-disable-next-line no-useless-escape
								/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
							),
							message: "Molimo da unesete validan email!",
						},
					]}>
					<Input
						suffix={<MailOutlined />}
						placeholder='Email'
						ref={emailRef}
					/>
				</Form.Item>
				<Form.Item
					name='oib'
					hasFeedback
					rules={[
						{
							required: true,
							pattern: new RegExp(/^(\d{10}(\d))$/),
							message: "Molimo unesite validan OIB!",
						},
					]}>
					<Input
						suffix={<NumberOutlined />}
						placeholder='OIB'
						ref={oibRef}
					/>
				</Form.Item>
				<Form.Item
					name='password'
					hasFeedback
					rules={[
						{
							required: true,
							pattern: new RegExp(
								"^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,255}$"
							),
							message:
								"Lozinka mora biti min 8, max 250 znakova, mora sadržavati minimalno jedan broj, jedno malo slovo, jedno veliko slovo, jedan specijalni znak i ne smije sadržavati razmake.",
						},
					]}>
					<Input
						suffix={<LockOutlined />}
						type='password'
						placeholder='Lozinka'
						ref={passwordRef}
					/>
				</Form.Item>
				<Form.Item
					name='confirmPassword'
					dependencies={["password"]}
					hasFeedback
					rules={[
						{
							required: true,
							message: "Molimo vas potvrdite lozinku!",
						},
						({ getFieldValue }) => ({
							validator(_, value) {
								if (
									!value ||
									getFieldValue("password") === value
								) {
									return Promise.resolve();
								}
								return Promise.reject(
									new Error(
										"Unesene lozinke se ne poklapaju!"
									)
								);
							},
						}),
					]}>
					<Input.Password placeholder='Potvrdite lozinku' />
				</Form.Item>
				<Form.Item>
					<Form.Item
						name='accept'
						valuePropName='checked'
						rules={[
							{
								required: true,
								message: "",
							},
							() => ({
								validator(_) {
									if (
										document.querySelector(
											"#tos-checkbox:checked"
										) !== null
									) {
										return Promise.resolve();
									}
									return Promise.reject(
										new Error(
											"Za nastavak morate prihvatiti TOS i politiku privatnosti"
										)
									);
								},
							}),
						]}>
						<Checkbox name='accept' id='tos-checkbox'>
							Prihvaćam TOS i Privacy politiku.
						</Checkbox>
					</Form.Item>
				</Form.Item>
				<Form.Item>
					<Button
						type='text'
						shape='round'
						size='large'
						htmlType='submit'
						className={styles["btn-rounded-dark"]}>
						Registriraj se
					</Button>
				</Form.Item>
				<p className={styles["lighter-text"]}>
					Već imate korisnički račun?{" "}
					<NavLink className={styles["link-text"]} to='/auth/login'>
						Prijavi se.
					</NavLink>
				</p>
			</Form>
		</div>
	);
};

export default Signup;
