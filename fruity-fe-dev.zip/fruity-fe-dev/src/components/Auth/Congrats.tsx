import { Button } from "antd";
import handshake from "../../assets/handshake.png";
import styles from "./Terms.module.css";
import { useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";
import useHttp from "../../hooks/use-http";
import api_routes from "../../config/api-routes";
import routes from "../../config/routes";

const Congrats = () => {
	const navigation = useNavigate();
	const { isLoading, sendRequest: sendConfirmRegistrationRequest } =
		useHttp();
	const params = useParams();
	const token = params.token;

	const manageConfirmRegisterResponseData = (confirmResponseData: any) => {
		console.log(confirmResponseData);
    
		//TODO: implement logic of what to do with data that is received with this

	};

	// does things when page first loads
	useEffect(() => {
		console.log("Confirming token");
		const confirmRegData = {
			registrationToken: token,
		};

		sendConfirmRegistrationRequest(
			{
				url: api_routes.ROUTE_AUTH_CONFIRM_REGISTRATION,
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: confirmRegData,
			},
			manageConfirmRegisterResponseData.bind(null)
		);

		console.log(`Finished confirming token: ${token}`);
	}, [sendConfirmRegistrationRequest, token]);

	const clickHandler = () => {
		// will prevent navigating out of the page before the request to confirm registration has been processed and if the
		if (!isLoading) {
			navigation(routes.ROUTE_AUTH_LOGIN);
		}
	};

	return (
		<div className={`${styles.content} ${styles["centered-element"]}`}>
			<ul>
				<li>
					<img src={handshake} alt='' />
				</li>
				<li>
					<h1>Čestitamo!</h1>
				</li>
				<li>
					<p className={styles["lighter-text"]}>
						Vaš račun je uspješno kreiran.
						<br />
						Uživajte u Fruity aplikaciji!
					</p>
				</li>
				<li>
					<Button
						type='text'
						shape='round'
						size='large'
						onClick={clickHandler}
						className={styles["btn-rounded-dark"]}>
						Prijavi se
					</Button>
				</li>
			</ul>
		</div>
	);
};

export default Congrats;
