import { FC, useEffect } from "react";

import { MailOutlined } from "@ant-design/icons";
import { Button, Form, Input } from "antd";
import styles from "./PasswordReset.module.css";
import { NavLink, useNavigate } from "react-router-dom";
import routes from "../../config/routes";
import { useSelector } from "react-redux";
import { RootState } from "../../store";

const PasswordReset: FC = () => {
	const navigate = useNavigate();
	const isLoggedIn: boolean = useSelector(
		(state: RootState) => state.auth.isLoggedIn
	);

	useEffect(() => {
		if (isLoggedIn) {
			navigate(routes.ROUTE_HOME, { replace: true });
		}
	}, [isLoggedIn, navigate]);

	const onSubmit = (values: any) => {
		console.log(values);
    
		//TODO: Password reset logic once backend part of it is done

	};

	return (
		<div className={`${styles.content} ${styles["centered-element"]}`}>
			<Form
				className={styles["password-reset-form"]}
				name='password_reset'
				initialValues={{ remember: false }}
				onFinish={onSubmit}>
				<h1>Zaboravljena lozinka</h1>
				<p className={styles["lighter-text"]}>
					Unesite važeću email adresu na koju ćemo <br /> Vam poslati
					link na formu za reset lozinke
				</p>
				<Form.Item
					name='email'
					hasFeedback
					rules={[
						{
							required: true,
							pattern: new RegExp(
								// eslint-disable-next-line no-useless-escape
								/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
							),
							message: "Molimo da unesete validan email!",
						},
					]}>
					<Input suffix={<MailOutlined />} placeholder='Email' />
				</Form.Item>
				<Form.Item>
					<Button
						type='text'
						shape='round'
						size='large'
						htmlType='submit'
						className={styles["btn-rounded-dark"]}>
						Reset lozinke
					</Button>
				</Form.Item>
				<p className={styles["lighter-text"]}>
					Sjećam se svoje lozinke!{" "}
					<NavLink
						className={styles["link-text"]}
						to={routes.ROUTE_AUTH_LOGIN}
						replace={true}>
						Prijavi se.
					</NavLink>
				</p>
			</Form>
		</div>
	);
};

export default PasswordReset;
