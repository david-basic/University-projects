import { Modal, message } from "antd";
import useHttp from "../../hooks/use-http";

interface Props {
	url: string;
	isVisible: boolean;
	setVisible: (newState: boolean) => void;
	setDeleted: (newState: boolean) => void;
}

const DeleteModal: React.FC<Props> = (props: Props) => {
	const { url, isVisible, setVisible, setDeleted } = props;

	const { sendRequest: attachmentsRequest } = useHttp();

	const handleCancel = () => {
		setVisible(false);
	};

	const employeeDelete = (url: string) => {
		const response = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error(responseData.message);
			} else {
				message.info(responseData.message);
				setVisible(false);
				setDeleted(true);
			}
		};

		attachmentsRequest(
			{
				url: url,
				method: "DELETE",
				body: null,
			},
			response.bind(null)
		);
	};

	return (
		<Modal
			title='Brisanje'
			open={isVisible}
			onOk={() => {
				employeeDelete(url);
			}}
			onCancel={handleCancel}>
			<p>Jeste li sigurni da želite obrisati ovaj entitet?</p>
		</Modal>
	);
};

export default DeleteModal;
