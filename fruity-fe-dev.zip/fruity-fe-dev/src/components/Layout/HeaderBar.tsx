import { UserOutlined } from "@ant-design/icons";
import { Col, Row } from "antd";
import { Link } from "react-router-dom";
import routes from "../../config/routes";
import logo from "../../assets/Fruity_logo.png";
import { Header } from "antd/es/layout/layout";
import "./styles.css";
import { useSelector } from "react-redux";
import { RootState } from "../../store";
import styles from "./HeaderBar.module.css";

export const HeaderBar: React.FC = () => {
	const username = useSelector((state: RootState) => state.auth.username);
	return (
		<Header>
			<Row className='header'>
				<div style={{ marginLeft: "10px" }}>
					<Link to={routes.ROUTE_HOME}>
						<img
							src={logo}
							style={{ height: "64px", width: "64px" }}
							alt=''
						/>
					</Link>
				</div>
				<div
					style={{
						display: "flex",
						height: "64px",
						alignItems: "center",
					}}>
					<Link
						to={routes.ROUTE_USER_CHANGE_PASSWORD}
						style={{ color: "white" }}>
						<UserOutlined style={{ marginRight: "7.5px" }} />
						{username}
					</Link>
				</div>
			</Row>
		</Header>
	);
};
