import { Layout } from "antd";
import { Content } from "antd/es/layout/layout";
import { ReactElement, useEffect } from "react";
import { HeaderBar } from "./HeaderBar";
import { SideBar } from "./Sidebar";
import "./styles.css";
import useHttp from "../../hooks/use-http";
import { useSelector } from "react-redux";
import { RootState } from "../../store";
import api_routes from "../../config/api-routes";

interface Props {
	children: ReactElement;
}
const MainLayout: React.FC<Props> = (props: Props) => {
	const { sendRequest: fetchRequest } = useHttp();
	const tokenType: string = useSelector(
		(state: RootState) => state.auth.tokenType
	);
	const accessToken: string = useSelector(
		(state: RootState) => state.auth.accessToken
	);

	useEffect(() => {
		if (sessionStorage.getItem("canFetchUserData") === "true") {
			fetchRequest(
				{
					url: api_routes.ROUTE_USERS_GET,
					method: "GET",
					headers: {
						Authorization: `${tokenType} ${accessToken}`,
					},
					body: null,
				},
				manageFetchedUserData.bind(null)
			);

			sessionStorage.setItem("canFetchUserData", "false");
		}
	});

	function manageFetchedUserData(userResponseData: any) {
		sessionStorage.setItem("name", userResponseData.data.name);
		sessionStorage.setItem("phone", userResponseData.data.phoneNumber);
		sessionStorage.setItem("oib", userResponseData.data.oib);
		sessionStorage.setItem("address", userResponseData.data.address);
		sessionStorage.setItem(
			"countyLabel",
			`${userResponseData.data.county.abbreviation} ${userResponseData.data.county.name}`
		);
		sessionStorage.setItem(
			"countyId",
			`${userResponseData.data.county.id}`
		);
	}

	const { children } = props;
	return (
		<Layout>
			<HeaderBar />
			<Content style={{ margin: 0 }}>
				<Layout>
					<SideBar />
					<Layout>
						<Content className='content_padding'>
							{children}
						</Content>
					</Layout>
				</Layout>
			</Content>
		</Layout>
	);
};

export default MainLayout;
