import {
	ClusterOutlined,
	ToolOutlined,
	PartitionOutlined,
	SettingOutlined,
	PoweroffOutlined,
} from "@ant-design/icons";
import { Menu } from "antd";
import Sider from "antd/es/layout/Sider";
import { Link, NavLink } from "react-router-dom";
import routes, { sidebarKey } from "../../config/routes";

export const SideBar: React.FC = () => {
	const sideBarItems = [
		{
			key: sidebarKey.Inventar,
			icon: <ClusterOutlined />,
			label: (
				<Link to={routes.ROUTE_INVENTORY_CADASTRAL_PARCEL}>
					Inventar
				</Link>
			),
		},
		{
			key: sidebarKey.Resursi,
			icon: <ToolOutlined />,
			label: "Resursi",
			children: [
				{
					key: sidebarKey.Djelatnici,
					label: (
						<Link to={routes.ROUTE_RESOURCES_EMPLOYEE}>
							Djelatnici
						</Link>
					),
				},
				{
					key: sidebarKey.Oprema,
					label: (
						<Link to={routes.ROUTE_RESOURCES_EQUIPMENT}>
							Oprema
						</Link>
					),
				},
				{
					key: sidebarKey.Prikljucci,
					label: (
						<Link to={routes.ROUTE_RESOURCES_ATTACHMENTS}>
							Priključci
						</Link>
					),
				},
			],
		},
		{
			key: sidebarKey.Radovi,
			icon: <PartitionOutlined />,
			label: <Link to={routes.ROUTE_WORKS}>Radovi</Link>,
		},
		{
			key: sidebarKey.Settings,
			icon: <SettingOutlined />,
			label: (
				<Link to={routes.ROUTE_USER_PROFILE_SETTINGS}>Postavke</Link>
			),
		},
		{
			key: sidebarKey.LogOut,
			icon: <PoweroffOutlined />,
			// label: "Log out",
			label: <NavLink to={routes.ROUTE_USER_LOGOUT}>Odjava</NavLink>,
		},
	];

	return (
		<>
			<Sider collapsible width={200} style={{ overflowY: "scroll" }}>
				<Menu
					theme='dark'
					mode='inline'
					style={{ height: "100%" }}
					items={sideBarItems}></Menu>
			</Sider>
		</>
	);
};
