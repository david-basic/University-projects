import { Drawer } from "antd";

interface Props {
	isVisible: boolean;
	setVisible: (newState: boolean) => void;
}

const CrudDrawer: React.FC<Props> = (props) => {
	const { isVisible, setVisible } = props;

	return (
		<Drawer
			onClose={() => setVisible(false)}
			title='Kreiraj'
			placement='right'
			width={"80vw"}
			open={isVisible}></Drawer>
	);
};

export default CrudDrawer;
