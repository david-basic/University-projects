import { Table, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";
import api_routes from "../../config/api-routes";
import { realisationTableFixedColumns } from "../../config/works-columns";
import { FormState } from "../../core/AppEnums";
import { RealisationVm } from "../../core/be/RealisationVm";
import { TableColumn } from "../../core/fe/TableColumns";
import useHttp from "../../hooks/use-http";
import { WorkVm } from "../../core/be/WorkVm";

interface Props {
	selectedWork: WorkVm;
	workTypeId: number;
	setFormState: (newState: FormState) => void;
	setDeleteModalUrl: (newState: string) => void;
	setOpenDeleteModal: (newState: boolean) => void;
	setSelectedWork: (newState: WorkVm) => void;
	setWorkTypeId: (newState: number) => void;
	setRealisationId: (newState: number) => void;
}

const RealisationList: React.FC<Props> = (props: Props) => {
	const {
		selectedWork,
		workTypeId,
		setFormState,
		setDeleteModalUrl,
		setOpenDeleteModal,
		setSelectedWork,
		setWorkTypeId,
		setRealisationId,
	} = props;
	const [changed, setChanged] = useState<boolean>(false);
	const [realisations, setRealisations] = useState<RealisationVm[]>([]);

	const deleteRealisation = (recivedId: number) => {
		setDeleteModalUrl(
			`${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${recivedId}`
		);
		setOpenDeleteModal(true);
	};

	const editDrawer = (recievedId: number) => {
		setSelectedWork(selectedWork);
		setWorkTypeId(workTypeId);
		setRealisationId(recievedId);
		setFormState(FormState.Edit);
	};

	const allRealisationsColumns: TableColumn[] = [
		...realisationTableFixedColumns(editDrawer, deleteRealisation),
	];

	const realisationList: ColumnsType<any> | undefined =
		allRealisationsColumns?.map((tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		}));

	const { sendRequest: request } = useHttp();

	const fetchRealisations = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data: RealisationVm[] = responseData.data.map(
					(object: RealisationVm) => Object.assign({}, object)
				);
				setRealisations(data);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${selectedWork.id}/realisations`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		fetchRealisations();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Table
				size='small'
				key='works-table'
				pagination={false}
				columns={realisationList}
				dataSource={realisations}
			/>
		</>
	);
};

export default RealisationList;
