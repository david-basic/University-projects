import {
	Button,
	Col,
	Drawer,
	Form,
	Input,
	Row,
	Select,
	Space,
	message,
} from "antd";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import api_routes from "../../../config/api-routes";
import { FormState } from "../../../core/AppEnums";
import { RowVm } from "../../../core/be/RowVm";
import { SelectOption } from "../../../core/fe/Option";
import useHttp from "../../../hooks/use-http";
import { RootState } from "../../../store";

interface Props {
	formState: FormState;
	realisationId: number;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const RealisationRowForm: React.FC<Props> = (props) => {
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const { formState, realisationId, setFormState, setChanged } = props;
	const [form] = Form.useForm();
	const [isVisible, setVisible] = useState<boolean>(false);
	const [cadastralParcelDropDown, setCadastralParcelDropDown] =
		useState<SelectOption[]>();
	const [arcodeParcelDropDown, setArecodeParcelDropDown] =
		useState<SelectOption[]>();
	const [rowClusterDropDown, setRowClusterDropDown] =
		useState<SelectOption[]>();
	const [rowDropDown, setRowDropDown] = useState<SelectOption[]>();
	const [rows, setRows] = useState<RowVm[]>();

	const onFinish = (values: any) => {
		const createRealisationRowData = {
			cadastralParcelFk: values.cadastralParcelFk,
			arcodeParcelFk: values.arcodeParcelFk,
			rowClusterFk: values.rowClusterFk,
			rowFks: values.rowFks,
			note: values.note,
		};

		const mapData = (responseData: any) => {
			if (responseData.success === undefined) {
				message.error(responseData.message);
			} else {
				message.info(responseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/rows`,
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					Authorization: fullToken,
				},
				body: createRealisationRowData,
			},
			mapData.bind(null)
		);
	};

	const { sendRequest: request } = useHttp();

	const getCadastralParcelDD = () => {
		const mapData = (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];
				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: value.name,
					})
				);
				setCadastralParcelDropDown(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_INVENTORY_CADASTRAL_PARCELS,
			},
			mapData.bind(null)
		);
	};

	const getArcodeParcelDD = () => {
		const mapData = (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];
				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: value.name,
					})
				);
				setArecodeParcelDropDown(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_INVENTORY_ARKOD_PARCELS,
			},
			mapData.bind(null)
		);
	};

	const getRowClusterDD = () => {
		const mapData = (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];
				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: value.name,
					})
				);
				setRowClusterDropDown(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_INVENTORY_ROW_CLUSTERS,
			},
			mapData.bind(null)
		);
	};

	const getRowDD = () => {
		const mapData = (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];
				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: `${
							rowClusterDropDown?.find(
								(cluster) =>
									cluster.value === value.rowClusterFk
							)?.label
						} ${value.ordinal}`,
					})
				);
				setRowDropDown(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_INVENTORY_ROWS,
			},
			mapData.bind(null)
		);
	};

	const getDropDowns = () => {
		getRowClusterDD();
		getCadastralParcelDD();
		getArcodeParcelDD();
	};

	useEffect(() => {
		getRowDD();
	}, [cadastralParcelDropDown]);

	useEffect(() => {
		if (formState === FormState.New) {
			getDropDowns();
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
	}, [formState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={
				formState === FormState.New
					? "Kreiraj red na realizaciji"
					: "Prilagodi red na realizaciji"
			}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='cadastral-parcel-form' onFinish={onFinish}>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"cadastralParcelFk"}
							key={"form-cadastral-parcel-name"}
							label='Katastarska čestica'>
							<Select options={cadastralParcelDropDown} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"arcodeParcelFk"}
							key={"form-cadastral-parcel-name"}
							label='Arkod parcela'>
							<Select options={arcodeParcelDropDown} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"rowClusterFk"}
							key={"form-cadastral-parcel-name"}
							label='Tabela'>
							<Select options={rowClusterDropDown} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"rowFks"}
							key={"form-cadastral-parcel-name"}
							label='Redak'>
							<Select options={rowDropDown} mode='multiple' />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"note"}
							key={"form-cadastral-parcel-name"}
							label='Bilješka'>
							<Input />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>
			</Form>
		</Drawer>
	);
};

export default RealisationRowForm;
