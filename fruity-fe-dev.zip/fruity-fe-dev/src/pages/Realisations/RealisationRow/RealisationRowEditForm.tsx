import { Drawer, Row, Col, Form, Input, Space, Button, message } from "antd";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import api_routes from "../../../config/api-routes";
import { FormState } from "../../../core/AppEnums";
import { RowVm } from "../../../core/be/RowVm";
import useHttp from "../../../hooks/use-http";
import { RootState } from "../../../store";

interface Props {
	formState: FormState;
	realisationId: number;
	rowId?: number;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const RealisationRowEditForm: React.FC<Props> = (props) => {
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const { formState, realisationId, rowId, setFormState, setChanged } = props;
	const [form] = Form.useForm();
	const [isVisible, setVisible] = useState<boolean>(false);
	const [row, setRow] = useState<RowVm | null>(null);

	const { sendRequest: request } = useHttp();

	const onFinish = (values: any) => {
		const createRealisationRowData = {
			rowFk: values.row,
			costPerHour: values.costPerHour,
			note: values.note,
		};

		const mapData = (registerResponseData: any) => {
			if (registerResponseData.success === undefined) {
				message.error(registerResponseData.message);
			} else {
				message.info(registerResponseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/rows/${rowId}`,
				method: "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: fullToken,
				},
				body: createRealisationRowData,
			},
			mapData.bind(null)
		);
	};

	const getRow = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
				setRow(responseData.data.row);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/rows/${rowId}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getRow();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
	}, [formState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={`Prilagodi red ${row?.ordinal} na realizaciji`}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='cadastral-parcel-form' onFinish={onFinish}>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"note"}
							key={"form-cadastral-parcel-name"}
							label='Bilješka'>
							<Input />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>
			</Form>
		</Drawer>
	);
};

export default RealisationRowEditForm;
