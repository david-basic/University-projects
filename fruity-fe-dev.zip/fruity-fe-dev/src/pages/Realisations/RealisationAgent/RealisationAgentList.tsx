import { message, Row, Button, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import DeleteModal from "../../../components/Modals/DeleteModal";
import api_routes from "../../../config/api-routes";
import { workAgentTableFixedColumns } from "../../../config/works-columns";
import { FormState } from "../../../core/AppEnums";
import { WorkAgentVm } from "../../../core/be/WorkVm";
import { TableColumn } from "../../../core/fe/TableColumns";
import { getIdFromUrl } from "../../../helpers/UrlHelpers";
import useHttp from "../../../hooks/use-http";
import { PlusSquareOutlined } from "@ant-design/icons";
import RealisationAgentForm from "./RealisationAgentForm";
import { TABLE_HEIGHT } from "../../../config/constants";

const RealisationAgentList: React.FC = () => {
	const realisationId = getIdFromUrl(useLocation());
	const [formState, setFormState] = useState<FormState>(FormState.None);
	const [openModal, setOpenModal] = useState<boolean>(false);
	const [agentId, setAgentId] = useState<number | undefined>();
	const [workAgents, setWorkAgents] = useState<WorkAgentVm[]>();
	const [changed, setChanged] = useState<boolean>(false);

	const editDrawer = (recivedId: number) => {
		setAgentId(recivedId);
		setFormState(FormState.Edit);
	};
	const deleteEmploye = (recivedId: number) => {
		setAgentId(recivedId);
		setOpenModal(true);
	};

	const allAgentColumns: TableColumn[] = [
		...workAgentTableFixedColumns(editDrawer, deleteEmploye),
	];

	const agentColumns: ColumnsType<any> | undefined = allAgentColumns?.map(
		(tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		})
	);

	const { sendRequest: request } = useHttp();

	const fetchAgents = () => {
		const mapAgents = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const attachments: WorkAgentVm[] = responseData.data.map(
					(attachmentData: WorkAgentVm[]) =>
						Object.assign({}, attachmentData)
				);
				setWorkAgents(attachments);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/agents`,
			},
			mapAgents.bind(null)
		);
	};

	useEffect(() => {
		fetchAgents();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Row
				className='header_container'
				align='middle'
				style={{ marginBottom: "15px" }}>
				<div>
					<h2 style={{ margin: "0px" }}>Sredstva na realizaciji</h2>
				</div>
				<div>
					<Button
						style={{ margin: "0px" }}
						onClick={() => setFormState(FormState.New)}>
						<PlusSquareOutlined />
						Dodaj sredstvo na realizaciji
					</Button>
				</div>
			</Row>

			<Table
				size='small'
				key={"work-agents-table"}
				pagination={false}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				columns={agentColumns}
				dataSource={workAgents}
			/>

			<RealisationAgentForm
				key='work-agent-drawer-form'
				formState={formState}
				realisationId={realisationId}
				agentId={agentId}
				setChanged={setChanged}
				setFormState={setFormState}
			/>

			<DeleteModal
				url={`${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/agents/${agentId}`}
				isVisible={openModal}
				setVisible={setOpenModal}
				setDeleted={setChanged}
			/>
		</>
	);
};

export default RealisationAgentList;
