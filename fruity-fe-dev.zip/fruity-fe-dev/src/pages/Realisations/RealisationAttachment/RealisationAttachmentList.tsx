import { message, Row, Button, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import DeleteModal from "../../../components/Modals/DeleteModal";
import api_routes from "../../../config/api-routes";
import { workAttachmentTableFixedColumns } from "../../../config/works-columns";
import { FormState } from "../../../core/AppEnums";
import { WorkAttachmentVm } from "../../../core/be/WorkVm";
import { TableColumn } from "../../../core/fe/TableColumns";
import { getIdFromUrl } from "../../../helpers/UrlHelpers";
import useHttp from "../../../hooks/use-http";
import { PlusSquareOutlined } from "@ant-design/icons";
import RealisationAttachmentForm from "./RealisationAttachmentForm";
import { TABLE_HEIGHT } from "../../../config/constants";

const RealisationAttachmentList: React.FC = () => {
	const realisationId = getIdFromUrl(useLocation());
	const [formState, setFormState] = useState<FormState>(FormState.None);
	const [openModal, setOpenModal] = useState<boolean>(false);
	const [attachmentId, setAttachmentId] = useState<number | undefined>();
	const [realisationAttachments, setRealisationAttachments] =
		useState<WorkAttachmentVm[]>();
	const [changed, setChanged] = useState<boolean>(false);

	const editDrawer = (recivedId: number) => {
		setAttachmentId(recivedId);
		setFormState(FormState.Edit);
	};
	const deleteEmploye = (recivedId: number) => {
		setAttachmentId(recivedId);
		setOpenModal(true);
	};

	const allAttachmentColumns: TableColumn[] = [
		...workAttachmentTableFixedColumns(editDrawer, deleteEmploye),
	];

	const attachmentColumns: ColumnsType<any> | undefined =
		allAttachmentColumns?.map((tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		}));

	const { sendRequest: request } = useHttp();

	const fetchAttachments = () => {
		const mapAttachments = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const attachments: WorkAttachmentVm[] = responseData.data.map(
					(attachmentData: WorkAttachmentVm[]) =>
						Object.assign({}, attachmentData)
				);
				setRealisationAttachments(attachments);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/attachments`,
			},
			mapAttachments.bind(null)
		);
	};

	useEffect(() => {
		fetchAttachments();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Row
				className='header_container'
				align='middle'
				style={{ marginBottom: "15px" }}>
				<div>
					<h2 style={{ margin: "0px" }}>Priključci na realizaciji</h2>
				</div>
				<div>
					<Button
						style={{ margin: "0px" }}
						onClick={() => setFormState(FormState.New)}>
						<PlusSquareOutlined />
						Dodaj priključak na realizaciji
					</Button>
				</div>
			</Row>

			<Table
				size='small'
				key={"realisation-attachments-table"}
				pagination={false}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				columns={attachmentColumns}
				dataSource={realisationAttachments}
			/>

			<RealisationAttachmentForm
				key='realisation-attachment-drawer-form'
				formState={formState}
				realisationId={realisationId}
				attachmentId={attachmentId}
				setChanged={setChanged}
				setFormState={setFormState}
			/>

			<DeleteModal
				url={`${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/attachments/${attachmentId}`}
				isVisible={openModal}
				setVisible={setOpenModal}
				setDeleted={setChanged}
			/>
		</>
	);
};

export default RealisationAttachmentList;
