import {
	Button,
	Col,
	Drawer,
	Form,
	Input,
	InputNumber,
	Row,
	Select,
	Space,
	message,
} from "antd";
import { EuroOutlined } from "@ant-design/icons";
import { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import api_routes from "../../../config/api-routes";
import { FormState } from "../../../core/AppEnums";
import { AttachmentVm } from "../../../core/be/AttachmentVm";
import { SelectOption } from "../../../core/fe/Option";
import useHttp from "../../../hooks/use-http";
import { RootState } from "../../../store";

interface Props {
	formState: FormState;
	realisationId: number;
	attachmentId?: number;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const RealisationAttachmentForm: React.FC<Props> = (props) => {
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const { formState, realisationId, attachmentId, setFormState, setChanged } =
		props;
	const [form] = Form.useForm();
	const [isVisible, setVisible] = useState<boolean>(false);
	const [attachmentsDropDown, setAttachmentsDropDown] =
		useState<SelectOption[]>();
	const [attachments, setAttachments] = useState<AttachmentVm[]>();

	const getCostPerHour = (id: number) => {
		const cost = attachments?.find(
			(attachment) => attachment.id === id
		)?.costPerHour;
		form.setFieldValue("costPerHour", cost);
	};

	const onFinish = (values: any) => {
		const createRealisationAttachmentData = {
			attachmentFk: values.attachment,
			costPerHour: values.costPerHour,
			note: values.note,
		};

		const mapData = (responseData: any) => {
			if (responseData.success === undefined) {
				message.error(responseData.message);
			} else {
				message.info(responseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		request(
			{
				url:
					formState === FormState.New
						? `${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/attachments`
						: `${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/attachments/${attachmentId}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: fullToken,
				},
				body: createRealisationAttachmentData,
			},
			mapData.bind(null)
		);
	};

	const { sendRequest: request } = useHttp();

	const getAttachments = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data: AttachmentVm[] = responseData.data.map(
					(attachmentData: AttachmentVm) =>
						Object.assign({}, attachmentData)
				);
				setAttachments(data);
				const tempList: SelectOption[] = [];
				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: value.name,
					})
				);
				setAttachmentsDropDown(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_RESOURCES_ATTACHMENTS,
			},
			mapData.bind(null)
		);
	};

	const getAttachment = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
				form.setFieldValue(
					"attachment",
					responseData.data.attachment.id
				);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_REALISATIONS}/${realisationId}/attachments/${attachmentId}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			getAttachments();
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getAttachments();
			getAttachment();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
	}, [formState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={
				formState === FormState.New
					? "Kreiraj priključak na realizaciji"
					: "Prilagodi priključak na realizaciji"
			}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='cadastral-parcel-form' onFinish={onFinish}>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"attachment"}
							key={"form-cadastral-parcel-name"}
							label='Naziv'
							rules={[
								{
									required: true,
									message: "Odaberite priključak!",
								},
							]}>
							<Select
								options={attachmentsDropDown}
								onChange={(record) => getCostPerHour(record)}
							/>
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"costPerHour"}
							key={"form-cadastral-parcel-name"}
							label='Trošak po satu'
							rules={[
								{
									required: true,
									message: "Unesite trošak po satu!",
								},
								() => ({
									validator(_, value) {
										if (!value || value > 0) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Trošak ne smije biti negativan!"
											)
										);
									},
								}),
							]}>
							<InputNumber prefix={<EuroOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"note"}
							key={"form-cadastral-parcel-name"}
							label='Bilješka'>
							<Input />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>
			</Form>
		</Drawer>
	);
};

export default RealisationAttachmentForm;
