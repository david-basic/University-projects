import { message, Row, Button, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import DeleteModal from "../../../components/Modals/DeleteModal";
import api_routes from "../../../config/api-routes";
import { workEquipmentTableFixedColumns } from "../../../config/works-columns";
import { FormState } from "../../../core/AppEnums";
import { WorkEquipmentVm } from "../../../core/be/WorkVm";
import { TableColumn } from "../../../core/fe/TableColumns";
import { getIdFromUrl } from "../../../helpers/UrlHelpers";
import useHttp from "../../../hooks/use-http";
import WorkEquipmentForm from "./WorkEquipmentForm";
import { PlusSquareOutlined } from "@ant-design/icons";
import { TABLE_HEIGHT } from "../../../config/constants";

const WorkEquipmentList: React.FC = () => {
	const workId = getIdFromUrl(useLocation());
	const [formState, setFormState] = useState<FormState>(FormState.None);
	const [openModal, setOpenModal] = useState<boolean>(false);
	const [equipmentId, setEquipmentId] = useState<number | undefined>();
	const [workEquipments, setWorkEquipments] = useState<WorkEquipmentVm[]>();
	const [changed, setChanged] = useState<boolean>(false);

	const editDrawer = (recivedId: number) => {
		setEquipmentId(recivedId);
		setFormState(FormState.Edit);
	};
	const deleteEmploye = (recivedId: number) => {
		setEquipmentId(recivedId);
		setOpenModal(true);
	};

	const allEquipmentColumns: TableColumn[] = [
		...workEquipmentTableFixedColumns(editDrawer, deleteEmploye),
	];

	const equipmentColumns: ColumnsType<any> | undefined =
		allEquipmentColumns?.map((tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		}));

	const { sendRequest: request } = useHttp();

	const fetchEquipments = () => {
		const mapEquipments = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const attachments: WorkEquipmentVm[] = responseData.data.map(
					(attachmentData: WorkEquipmentVm[]) =>
						Object.assign({}, attachmentData)
				);
				setWorkEquipments(attachments);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/equipment`,
			},
			mapEquipments.bind(null)
		);
	};

	useEffect(() => {
		fetchEquipments();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Row
				className='header_container'
				align='middle'
				style={{ marginBottom: "15px" }}>
				<div>
					<h2 style={{ margin: "0px" }}>Oprema na radu</h2>
				</div>
				<div>
					<Button
						style={{ margin: "0px" }}
						onClick={() => setFormState(FormState.New)}>
						<PlusSquareOutlined />
						Dodaj opremu na rad
					</Button>
				</div>
			</Row>

			<Table
				size='small'
				key={"work-equipments-table"}
				pagination={false}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				columns={equipmentColumns}
				dataSource={workEquipments}
			/>

			<WorkEquipmentForm
				key='work-equipment-drawer-form'
				formState={formState}
				workId={workId}
				equipmentId={equipmentId}
				setChanged={setChanged}
				setFormState={setFormState}
			/>

			<DeleteModal
				url={`${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/equipment/${equipmentId}`}
				isVisible={openModal}
				setVisible={setOpenModal}
				setDeleted={setChanged}
			/>
		</>
	);
};

export default WorkEquipmentList;
