import { message, Row, Button, Table } from "antd";
import { ColumnsType } from "antd/es/table";
import { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import DeleteModal from "../../../components/Modals/DeleteModal";
import api_routes from "../../../config/api-routes";
import { workAttachmentTableFixedColumns } from "../../../config/works-columns";
import { FormState } from "../../../core/AppEnums";
import { WorkAttachmentVm } from "../../../core/be/WorkVm";
import { TableColumn } from "../../../core/fe/TableColumns";
import { getIdFromUrl } from "../../../helpers/UrlHelpers";
import useHttp from "../../../hooks/use-http";
import WorkAttachmentForm from "./WorkAttachmentForm";
import { PlusSquareOutlined } from "@ant-design/icons";
import { TABLE_HEIGHT } from "../../../config/constants";

const WorkAttachmentList: React.FC = () => {
	const workId = getIdFromUrl(useLocation());
	const [formState, setFormState] = useState<FormState>(FormState.None);
	const [openModal, setOpenModal] = useState<boolean>(false);
	const [attachmentId, setAttachmentId] = useState<number | undefined>();
	const [workAttachments, setWorkAttachments] =
		useState<WorkAttachmentVm[]>();
	const [changed, setChanged] = useState<boolean>(false);

	const editDrawer = (recivedId: number) => {
		setAttachmentId(recivedId);
		setFormState(FormState.Edit);
	};
	const deleteEmploye = (recivedId: number) => {
		setAttachmentId(recivedId);
		setOpenModal(true);
	};

	const allAttachmentColumns: TableColumn[] = [
		...workAttachmentTableFixedColumns(editDrawer, deleteEmploye),
	];

	const attachmentColumns: ColumnsType<any> | undefined =
		allAttachmentColumns?.map((tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		}));

	const { sendRequest: request } = useHttp();

	const fetchAttachments = () => {
		const mapAttachments = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const attachments: WorkAttachmentVm[] = responseData.data.map(
					(attachmentData: WorkAttachmentVm[]) =>
						Object.assign({}, attachmentData)
				);
				setWorkAttachments(attachments);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/attachments`,
			},
			mapAttachments.bind(null)
		);
	};

	useEffect(() => {
		fetchAttachments();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Row
				className='header_container'
				align='middle'
				style={{ marginBottom: "15px" }}>
				<div>
					<h2 style={{ margin: "0px" }}>Priključci na radu</h2>
				</div>
				<div>
					<Button
						style={{ margin: "0px" }}
						onClick={() => setFormState(FormState.New)}>
						<PlusSquareOutlined />
						Dodaj priključak na rad
					</Button>
				</div>
			</Row>

			<Table
				size='small'
				key={"work-attachments-table"}
				pagination={false}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				columns={attachmentColumns}
				dataSource={workAttachments}
			/>

			<WorkAttachmentForm
				key='work-attachment-drawer-form'
				formState={formState}
				workId={workId}
				attachmentId={attachmentId}
				setChanged={setChanged}
				setFormState={setFormState}
			/>

			<DeleteModal
				url={`${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/attachments/${attachmentId}`}
				isVisible={openModal}
				setVisible={setOpenModal}
				setDeleted={setChanged}
			/>
		</>
	);
};

export default WorkAttachmentList;
