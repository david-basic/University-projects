import {
	Button,
	Col,
	Drawer,
	Form,
	Input,
	InputNumber,
	Row,
	Select,
	Space,
	message,
} from "antd";
import { EuroOutlined } from "@ant-design/icons";
import { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import api_routes from "../../../config/api-routes";
import { FormState } from "../../../core/AppEnums";
import { AgentVm } from "../../../core/be/AgentVm";
import { SelectOption } from "../../../core/fe/Option";
import useHttp from "../../../hooks/use-http";
import { RootState } from "../../../store";

interface Props {
	formState: FormState;
	workId: number;
	agentId?: number;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const WorkAgentForm: React.FC<Props> = (props) => {
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const { formState, workId, agentId, setFormState, setChanged } = props;
	const [form] = Form.useForm();
	const [isVisible, setVisible] = useState<boolean>(false);
	const [agentsDropDown, setAgentsDropDown] = useState<SelectOption[]>();
	const [unitOfMeasurementDropDown, setUnitOfMeasurementDropDown] =
		useState<SelectOption[]>();
	const [agents, setAgents] = useState<AgentVm[]>();

	const onFinish = (values: any) => {
		const createWorkAgentData = {
			agentFk: values.agentFk,
			agentQuantity: values.agentQuantity,
			agentUnitOfMeasureFk: values.agentUnitOfMeasureFk,
			costPerUnitOfMeasure: values.costPerUnitOfMeasure,
			waterQuantity: values.waterQuantity,
			waterUnitOfMeasureFk: values.waterUnitOfMeasureFk,
			note: values.note,
		};

		const mapData = (responseData: any) => {
			if (responseData.success === undefined) {
				message.error(responseData.message);
			} else {
				message.info(responseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		request(
			{
				url:
					formState === FormState.New
						? `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/agents`
						: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/agents/${agentId}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: fullToken,
				},
				body: createWorkAgentData,
			},
			mapData.bind(null)
		);
	};

	const { sendRequest: request } = useHttp();

	const getDropDowns = () => {
		getAgents();
		getUnitOfMeasurements();
	};

	const getAgents = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];
				console.log(responseData.data);
				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: `${
							value.manufacturer === null
								? ""
								: value.manufacturer
						} ${value.name}`,
					})
				);
				setAgentsDropDown(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_RESOURCES_AGENTS,
			},
			mapData.bind(null)
		);
	};

	const getUnitOfMeasurements = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];
				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: `${value.abbreviation} ${value.name}`,
					})
				);
				setUnitOfMeasurementDropDown(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_RESOURCES_UNIT_OF_MEASUREMENT,
			},
			mapData.bind(null)
		);
	};

	const getAgent = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
				form.setFieldValue("agentFk", responseData.data.agent.id);
				form.setFieldValue(
					"agentUnitOfMeasureFk",
					responseData.data.agentUnitOfMeasure.id
				);
				form.setFieldValue(
					"waterUnitOfMeasureFk",
					responseData.data.waterUnitOfMeasure.id
				);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/agents/${agentId}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			getDropDowns();
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getDropDowns();
			getAgent();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
	}, [formState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={
				formState === FormState.New
					? "Kreiraj sredstvo na radu"
					: "Prilagodi sredstvo na radu"
			}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='cadastral-parcel-form' onFinish={onFinish}>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"agentFk"}
							key={"form-cadastral-parcel-name"}
							label='Sredstvo'
							rules={[
								{
									required: true,
									message: "Odaberite sredstvo!",
								},
							]}>
							<Select options={agentsDropDown} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={4}>
						<Form.Item
							name={"agentQuantity"}
							key={"form-cadastral-parcel-name"}
							label='Količina sredstva'
							rules={[
								{
									required: true,
									message: "Definirajte količinu!",
								},
								() => ({
									validator(_, value) {
										if (!value || value > 0) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Količina ne smije biti negativna!"
											)
										);
									},
								}),
							]}>
							<InputNumber />
						</Form.Item>
					</Col>
					<Col span={4}>
						<Form.Item
							name={"agentUnitOfMeasureFk"}
							key={"form-cadastral-parcel-name"}
							rules={[
								{
									required: true,
									message: "Odaberite mjernu jedinicu!",
								},
							]}>
							<Select options={unitOfMeasurementDropDown} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"costPerUnitOfMeasure"}
							key={"form-cadastral-parcel-name"}
							label='Trošak po jedinici mjere sredstva'
							rules={[
								{
									required: true,
									message: "Definirajte trošak!",
								},
								() => ({
									validator(_, value) {
										if (!value || value > 0) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Trošak ne smije biti negativan!"
											)
										);
									},
								}),
							]}>
							<InputNumber prefix={<EuroOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={4}>
						<Form.Item
							name={"waterQuantity"}
							key={"form-cadastral-parcel-name"}
							label='Količina vode'
							rules={[
								{
									required: true,
									message: "Definirajte količinu!",
								},
								() => ({
									validator(_, value) {
										if (!value || value > 0) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Količina ne smije biti negativna!"
											)
										);
									},
								}),
							]}>
							<InputNumber />
						</Form.Item>
					</Col>
					<Col span={4}>
						<Form.Item
							name={"waterUnitOfMeasureFk"}
							key={"form-cadastral-parcel-name"}
							rules={[
								{
									required: true,
									message: "Odaberite mjernu jedinicu!",
								},
							]}>
							<Select options={unitOfMeasurementDropDown} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"note"}
							key={"form-cadastral-parcel-name"}
							label='Bilješka'>
							<Input />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>
			</Form>
		</Drawer>
	);
};

export default WorkAgentForm;
