import { Form, useLocation } from "react-router-dom";
import { Row, Button, Table, message } from "antd";
import { PlusSquareOutlined } from "@ant-design/icons";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";
import WorkRowForm from "./WorkRowForm";
import WorkRowEditForm from "./WorkRowEditForm";
import { getIdFromUrl } from "../../../helpers/UrlHelpers";
import { FormState } from "../../../core/AppEnums";
import { WorkRowVm } from "../../../core/be/WorkVm";
import { TableColumn } from "../../../core/fe/TableColumns";
import DeleteModal from "../../../components/Modals/DeleteModal";
import api_routes from "../../../config/api-routes";
import { workRowTableFixedColumns } from "../../../config/works-columns";
import useHttp from "../../../hooks/use-http";
import { TABLE_HEIGHT } from "../../../config/constants";

const WorkRowList: React.FC = () => {
	const workId = getIdFromUrl(useLocation());
	const [formState, setFormState] = useState<FormState>(FormState.None);
	const [rowFormState, setRowFormState] = useState<FormState>(FormState.None);
	const [openModal, setOpenModal] = useState<boolean>(false);
	const [rowId, setRowId] = useState<number | undefined>();
	const [workRows, setWorkRows] = useState<WorkRowVm[]>();
	const [changed, setChanged] = useState<boolean>(true);

	const editDrawer = (recivedId: number) => {
		setRowId(recivedId);
		setRowFormState(FormState.Edit);
	};
	const deleteEmploye = (recivedId: number) => {
		setRowId(recivedId);
		setOpenModal(true);
	};

	const allRowColumns: TableColumn[] = [
		...workRowTableFixedColumns(editDrawer, deleteEmploye),
	];

	const rowColumns: ColumnsType<any> | undefined = allRowColumns?.map(
		(tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		})
	);

	const { sendRequest: request } = useHttp();

	const fetchRows = () => {
		const mapRows = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const attachments: WorkRowVm[] = responseData.data.map(
					(attachmentData: WorkRowVm[]) =>
						Object.assign({}, attachmentData)
				);
				setWorkRows(attachments);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/rows`,
			},
			mapRows.bind(null)
		);
	};

	useEffect(() => {
		fetchRows();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Row
				className='header_container'
				align='middle'
				style={{ marginBottom: "15px" }}>
				<div>
					<h2 style={{ margin: "0px" }}>Redovi na radu</h2>
				</div>
				<div>
					<Button
						style={{ margin: "0px" }}
						onClick={() => setFormState(FormState.New)}>
						<PlusSquareOutlined />
						Dodaj red na rad
					</Button>
				</div>
			</Row>

			<Table
				size='small'
				key={"work-rows-table"}
				pagination={false}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				columns={rowColumns}
				dataSource={workRows}
			/>

			<WorkRowForm
				key='work-row-drawer-form'
				formState={formState}
				workId={workId}
				setChanged={setChanged}
				setFormState={setFormState}
			/>

			<WorkRowEditForm
				key='work-row-drawer-form'
				formState={rowFormState}
				workId={workId}
				rowId={rowId}
				setChanged={setChanged}
				setFormState={setRowFormState}
			/>

			<DeleteModal
				url={`${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/rows/${rowId}`}
				isVisible={openModal}
				setVisible={setOpenModal}
				setDeleted={setChanged}
			/>
		</>
	);
};

export default WorkRowList;
