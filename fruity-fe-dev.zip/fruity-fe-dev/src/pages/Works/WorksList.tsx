import { Button, Row, Table, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";
import { PlusSquareOutlined } from "@ant-design/icons";
import WorkForm from "./WorkForm";
import RealisationList from "../Realisations/RealisationList";
import { FormState } from "../../core/AppEnums";
import api_routes from "../../config/api-routes";
import { WorkVm } from "../../core/be/WorkVm";
import { TableColumn } from "../../core/fe/TableColumns";
import { workTableFixedColumns } from "../../config/works-columns";
import useHttp from "../../hooks/use-http";
import DeleteModal from "../../components/Modals/DeleteModal";
import RealisationForm from "../Realisations/RealisationForm";
import { TABLE_HEIGHT } from "../../config/constants";

const WorksList: React.FC = () => {
	const [deleteModalUrl, setDeleteModalUrl] = useState<string>("");
	const [openDeleteModal, setOpenDeleteModal] = useState<boolean>(false);
	const [changed, setChanged] = useState<boolean>(true);
	const [workFormState, setWorkFormState] = useState<FormState>(
		FormState.None
	);
	const [realisationFormState, setRealisationFormState] = useState<FormState>(
		FormState.None
	);
	const [selectedWork, setSelectedWork] = useState<WorkVm | undefined>(
		undefined
	);
	const [realisationId, setRealisationId] = useState<number | undefined>(
		undefined
	);
	const [workTypeId, setWorkTypeId] = useState<number | undefined>(undefined);
	const [works, setWorks] = useState<WorkVm[]>([]);

	const deleteWork = (recivedId: number) => {
		setDeleteModalUrl(
			`${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${recivedId}`
		);
		setOpenDeleteModal(true);
	};

	const openNewForm = () => {
		setWorkFormState(FormState.New);
	};

	const newRealisation = (record: WorkVm) => {
		setSelectedWork(record);
		setRealisationFormState(FormState.New);
	};

	const editDrawer = (recieved: WorkVm) => {
		setSelectedWork(recieved);
		setWorkFormState(FormState.Edit);
	};

	const allWorksColumns: TableColumn[] = [
		...workTableFixedColumns(newRealisation, editDrawer, deleteWork),
	];

	const workList: ColumnsType<any> | undefined = allWorksColumns?.map(
		(tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		})
	);

	const { sendRequest: request } = useHttp();

	const fetchWorks = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data: WorkVm[] = responseData.data.map((object: WorkVm) =>
					Object.assign({}, object)
				);
				setWorks(data);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		fetchWorks();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Row
				className='header_container'
				align='middle'
				style={{ marginBottom: "15px" }}>
				<div>
					<h2 style={{ margin: "0px" }}>Radovi</h2>
				</div>
				<div>
					<Button style={{ margin: "0px" }} onClick={openNewForm}>
						<PlusSquareOutlined />
						Dodaj Rad
					</Button>
				</div>
			</Row>
			<Table
				size='small'
				key='works-table'
				pagination={false}
				columns={workList}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				expandable={{
					expandedRowRender: (record) => (
						<RealisationList
							selectedWork={record}
							workTypeId={record.type.id}
							setSelectedWork={setSelectedWork}
							setWorkTypeId={setWorkTypeId}
							setDeleteModalUrl={setDeleteModalUrl}
							setFormState={setRealisationFormState}
							setOpenDeleteModal={setOpenDeleteModal}
							setRealisationId={setRealisationId}
						/>
					),
				}}
				dataSource={works.map((row) => ({
					...row,
					key: `cp${row.id}`,
				}))}
			/>

			<DeleteModal
				url={deleteModalUrl}
				isVisible={openDeleteModal}
				setVisible={setOpenDeleteModal}
				setDeleted={setChanged}
			/>
			<WorkForm
				key='work-drawer-form'
				formState={workFormState}
				selectedWork={selectedWork}
				setSelectedWork={setSelectedWork}
				setChanged={setChanged}
				setFormState={setWorkFormState}
			/>
			<RealisationForm
				key='realisation-drawer-form'
				formState={realisationFormState}
				selectedWork={selectedWork}
				realisationId={realisationId}
				setRealisationId={setRealisationId}
				setChanged={setChanged}
				setFormState={setRealisationFormState}
			/>
		</>
	);
};

export default WorksList;
