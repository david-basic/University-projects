import {
	Drawer,
	Row,
	Col,
	Input,
	Space,
	Button,
	Form,
	Select,
	message,
	DatePicker,
	Checkbox,
} from "antd";
import { FontSizeOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import { useState, useEffect, ReactElement } from "react";
import { useSelector } from "react-redux";
import api_routes from "../../config/api-routes";
import { FormState, FormType } from "../../core/AppEnums";
import { WorkTypeVm } from "../../core/be/WorkTypeVm";
import { SelectOption } from "../../core/fe/Option";
import { getAddonsWorkLinks } from "../../helpers/ButtonsHelpers";
import useHttp from "../../hooks/use-http";
import { RootState } from "../../store";
import { WorkVm } from "../../core/be/WorkVm";
import { unescape } from "querystring";

interface Props {
	formState: FormState;
	selectedWork?: WorkVm | undefined;
	setSelectedWork: (newState: WorkVm | undefined) => void;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const WorkForm: React.FC<Props> = (props) => {
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const {
		formState,
		selectedWork,
		setFormState,
		setSelectedWork,
		setChanged,
	} = props;
	const [isVisible, setVisible] = useState<boolean>(false);
	const [form] = Form.useForm();
	const [finished, setFinished] = useState<boolean>();
	const [workTypes, setWorkTypes] = useState<WorkTypeVm[]>();
	const [workTypesDropdown, setWorkTypesDropdown] = useState<SelectOption[]>(
		[]
	);
	const [selectedWorkType, setSelectedWorkType] = useState<
		number | undefined
	>();

	const [additionalButtons, setAdditionalButtons] = useState<ReactElement>();

	const { sendRequest: request } = useHttp();

	const onFinish = (values: any) => {
		const createWorkData = {
			startDateTime: values.wstartDateTime,
			endDateTime: values.wendDateTime,
			finished: finished,
			note: values.note,
			typeFk: values.type,
		};

		const mapData = (responseData: any) => {
			if (responseData.success === undefined) {
				message.error(responseData.message);
			} else {
				message.info(responseData.message);
				setSelectedWork(responseData.data);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		request(
			{
				url:
					formState === FormState.New
						? api_routes.ROUTE_WORK_MANAGEMENT_WORKS
						: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${selectedWork?.id}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: fullToken,
				},
				body: createWorkData,
			},
			mapData.bind(null)
		);
	};

	const getWorkTypes = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data: WorkTypeVm[] = responseData.data.map(
					(object: WorkTypeVm[]) => Object.assign({}, object)
				);
				setWorkTypes(data);
				const tempList: SelectOption[] = [];
				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: value.name,
					})
				);
				setWorkTypesDropdown(tempList);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/types`,
			},
			mapData.bind(null)
		);
	};

	const getWork = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
				setFinished(responseData.data.finished);
				form.setFieldValue("type", responseData.data.type.id);
				setSelectedWorkType(responseData.data.type.id);
				form.setFieldValue(
					"wstartDateTime",
					dayjs(responseData.data.startDateTime)
				);
				form.setFieldValue(
					"wendDateTime",
					dayjs(responseData.data.endDateTime)
				);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${selectedWork?.id}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		setAdditionalButtons(getAddonsWorkLinks(workTypes, selectedWork));
	}, [selectedWorkType, selectedWork]);

	useEffect(() => {
		if (formState === FormState.New) {
			getWorkTypes();
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getWorkTypes();
			getWork();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setSelectedWork(undefined);
			setFinished(false);
			setVisible(false);
		}
	}, [formState]);

	return (
		<>
			<Drawer
				onClose={() => setFormState(FormState.None)}
				title={
					formState === FormState.New
						? "Kreiraj rad"
						: "Prilagodi rad"
				}
				placement='right'
				width={"80vw"}
				open={isVisible}
				footer={additionalButtons}>
				<Form
					form={form}
					name='cadastral-parcel-form'
					onFinish={onFinish}>
					<Row gutter={16}>
						<Col span={8}>
							<Form.Item
								name={"wstartDateTime"}
								key={"form-work-startDateTime"}
								label='Vrijeme početka'
								rules={[
									{
										required: true,
										message: "Odaberite vrijeme početka!",
									},
								]}>
								<DatePicker showTime format='HH:mm DD.MM.YY.' />
							</Form.Item>
						</Col>
					</Row>

					<Row gutter={16}>
						<Col span={8}>
							<Form.Item
								name={"wendDateTime"}
								key={"form-work-endDateTime"}
								label='Vrijeme završetka'
								rules={[
									{
										required: true,
										message: "Odaberite vrijeme završetka!",
									},
								]}>
								<DatePicker format='HH:mm DD.MM.YY.' showTime />
							</Form.Item>
						</Col>
					</Row>

					<Row gutter={16}>
						<Col span={8}>
							<Form.Item
								name={"finished"}
								key={"form-work-finished"}
								label='Posao obavljen'>
								<Checkbox
									checked={finished}
									onClick={() => setFinished(!finished)}
								/>
							</Form.Item>
						</Col>
					</Row>

					<Row gutter={16}>
						<Col span={8}>
							<Form.Item
								name={"note"}
								key={"form-work-note"}
								label='Bilješka'
								rules={[
									() => ({
										validator(_, value) {
											if (!value || value.length <= 500) {
												return Promise.resolve();
											}
											return Promise.reject(
												new Error(
													"Bilješka mora biti duljine maksimalno 500 znakova."
												)
											);
										},
									}),
								]}>
								<Input addonAfter={<FontSizeOutlined />} />
							</Form.Item>
						</Col>
					</Row>

					<Row gutter={16}>
						<Col span={8}>
							<Form.Item
								name={"type"}
								key={"form-work-type"}
								label='Tip'
								rules={[
									{
										required: true,
										message: "Odaberite tip rada!",
									},
								]}>
								<Select
									options={workTypesDropdown}
									onChange={(record) =>
										setSelectedWorkType(record)
									}
								/>
							</Form.Item>
						</Col>
					</Row>

					<Row>
						<Col span={8}>
							<Space>
								<Button
									type='primary'
									danger
									onClick={() => setVisible(false)}>
									Odustani
								</Button>
								<Button type='primary' htmlType='submit'>
									Spremi
								</Button>
							</Space>
						</Col>
					</Row>

					<Form.Item
						name={"rowCluster"}
						key={
							"form-cadastral-parcel-cadastral-row-cluster-fk"
						}></Form.Item>
				</Form>
			</Drawer>
		</>
	);
};

export default WorkForm;
