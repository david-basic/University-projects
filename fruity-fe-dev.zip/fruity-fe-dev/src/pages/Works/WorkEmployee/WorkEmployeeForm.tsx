import {
	Button,
	Col,
	Drawer,
	Form,
	Input,
	InputNumber,
	Row,
	Select,
	Space,
	message,
} from "antd";
import { EuroOutlined } from "@ant-design/icons";
import { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import api_routes from "../../../config/api-routes";
import { FormState } from "../../../core/AppEnums";
import { EmployeeVm } from "../../../core/be/EmployeeVm";
import { SelectOption } from "../../../core/fe/Option";
import useHttp from "../../../hooks/use-http";
import { RootState } from "../../../store";

interface Props {
	formState: FormState;
	workId: number;
	employeeId?: number;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const WorkEmployeeForm: React.FC<Props> = (props) => {
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const { formState, workId, employeeId, setFormState, setChanged } = props;
	const [form] = Form.useForm();
	const [isVisible, setVisible] = useState<boolean>(false);
	const [employeesDropDown, setEmployeesDropDown] =
		useState<SelectOption[]>();
	const [employees, setEmployees] = useState<EmployeeVm[]>();

	const getCostPerHour = (id: number) => {
		const cost = employees?.find(
			(employee) => employee.id === id
		)?.costPerHour;
		form.setFieldValue("costPerHour", cost);
	};

	const onFinish = (values: any) => {
		const createWorkEmployeeData = {
			employeeFk: values.employee,
			costPerHour: values.costPerHour,
			note: values.note,
		};

		const mapData = (responseData: any) => {
			if (responseData.success === undefined) {
				message.error(responseData.message);
			} else {
				message.info(responseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		request(
			{
				url:
					formState === FormState.New
						? `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/employees`
						: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/employees/${employeeId}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: fullToken,
				},
				body: createWorkEmployeeData,
			},
			mapData.bind(null)
		);
	};

	const { sendRequest: request } = useHttp();

	const getEmployees = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data: EmployeeVm[] = responseData.data.map(
					(attachmentData: EmployeeVm) =>
						Object.assign({}, attachmentData)
				);
				setEmployees(data);
				const tempList: SelectOption[] = [];
				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: `${value.firstName} ${value.lastName}`,
					})
				);
				setEmployeesDropDown(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_RESOURCES_EMPLOYEES,
			},
			mapData.bind(null)
		);
	};

	const getEmployee = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
				form.setFieldValue("employee", responseData.data.employee.id);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_WORK_MANAGEMENT_WORKS}/${workId}/employees/${employeeId}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			getEmployees();
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getEmployees();
			getEmployee();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
	}, [formState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={
				formState === FormState.New
					? "Kreiraj radnika na radu"
					: "Prilagodi radnika na radu"
			}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='cadastral-parcel-form' onFinish={onFinish}>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"employee"}
							key={"form-cadastral-parcel-name"}
							label='Ime'
							rules={[
								{
									required: true,
									message: "Odaberite radnika!",
								},
							]}>
							<Select
								options={employeesDropDown}
								onChange={(record) => getCostPerHour(record)}
							/>
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"costPerHour"}
							key={"form-cadastral-parcel-name"}
							label='Trošak po satu'
							rules={[
								{
									required: true,
									message: "Unesite trošak po satu!",
								},
								() => ({
									validator(_, value) {
										if (!value || value > 0) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Trošak ne smije biti negativan!"
											)
										);
									},
								}),
							]}>
							<InputNumber prefix={<EuroOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"note"}
							key={"form-cadastral-parcel-name"}
							label='Bilješka'>
							<Input />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>
			</Form>
		</Drawer>
	);
};

export default WorkEmployeeForm;
