import { Table, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { TableColumn } from "../../../core/fe/TableColumns";
import { rowClusterTableFixedColumns } from "../../../config/inventory-columns";
import api_routes from "../../../config/api-routes";
import { Key, useEffect, useState } from "react";
import useHttp from "../../../hooks/use-http";
import { RowClusterVm } from "../../../core/be/RowClusterVm";
import RowList from "../Row/RowList";
import RowForm from "../Row/RowForm";
import { FormState, RowState } from "../../../core/AppEnums";

interface Props {
	arkodParcelId: number;
	rowClusterId: number | undefined;
	setDeleteModalUrl: (newState: string) => void;
	setOpenDeleteModal: (newState: boolean) => void;
	setRowClusterId: (newState: number) => void;
	setFormRowClusterState: (newState: FormState) => void;
}

const RowClusterList: React.FC<Props> = (props: Props) => {
	const {
		setDeleteModalUrl,
		setOpenDeleteModal,
		arkodParcelId,
		rowClusterId,
		setRowClusterId,
		setFormRowClusterState,
	} = props;
	const { sendRequest: request } = useHttp();
	const [changed, setChanged] = useState<boolean>(false);
	const [expandedRows, setExpandedRows] = useState<readonly Key[]>([]);
	const [rowClusters, setRowClusters] = useState<RowClusterVm[]>([]);
	const [rowFormState, setRowFormState] = useState<FormState>(FormState.None);
	const [rowState, setRowState] = useState<RowState>(RowState.None);
	const [rowCount, setRowCount] = useState<number>(0);
	const [rowId, setRowId] = useState<number | undefined>();

	const openNewRowDrawer = (recivedId: number) => {
		setRowClusterId(recivedId);
		setRowFormState(FormState.New);
		setRowState(RowState.None);
	};

	const deleteRowCluster = (recivedId: number) => {
		setDeleteModalUrl(
			`${api_routes.ROUTE_INVENTORY_ROW_CLUSTERS}/${recivedId}`
		);
		setOpenDeleteModal(true);
	};

	const editRowClusterDrawer = (recivedId: number) => {
		setRowClusterId(recivedId);
		setFormRowClusterState(FormState.Edit);
	};

	const allRowClusterColumns: TableColumn[] = [
		...rowClusterTableFixedColumns(
			openNewRowDrawer,
			editRowClusterDrawer,
			deleteRowCluster
		),
	];

	const rowClusterColumns: ColumnsType<any> | undefined =
		allRowClusterColumns?.map((tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		}));

	const fetchRowClusters = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data: RowClusterVm[] = responseData.data.map(
					(rowClustersData: RowClusterVm) =>
						Object.assign({}, rowClustersData)
				);
				setRowClusters(data);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_INVENTORY_ARKOD_PARCELS}/${arkodParcelId}/row-clusters`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		fetchRowClusters();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Table
				size='small'
				key='row-cluster-table'
				pagination={false}
				columns={rowClusterColumns}
				expandable={{
					expandedRowRender: (record) => (
						<RowList
							setDeleteModalUrl={setDeleteModalUrl}
							setOpenDeleteModal={setOpenDeleteModal}
							rowClusterId={record.id}
							setRowId={setRowId}
							setRowFormState={setRowFormState}
							setRowState={setRowState}
							setRowCount={setRowCount}
						/>
					),
				}}
				dataSource={rowClusters.map((row) => ({
					...row,
					key: `rc${row.id}`,
				}))}
			/>
			<RowForm
				key='row-drawer-form'
				formState={rowFormState}
				rowState={rowState}
				rowId={rowId}
				rowClusterId={rowClusterId}
				rowCount={rowCount}
				setFormState={setRowFormState}
				setRowState={setRowState}
				setChanged={setChanged}
			/>
		</>
	);
};

export default RowClusterList;
