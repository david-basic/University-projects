import { Row, Button, Table, message } from "antd";
import { PlusSquareOutlined } from "@ant-design/icons";
import { Key, useEffect, useState } from "react";
import { CadastralParcelVm } from "../../../core/be/CadastralParcelVm";
import CadastralParcelForm from "./CadastralParcelForm";
import { FormState } from "../../../core/AppEnums";
import { TableColumn } from "../../../core/fe/TableColumns";
import { cadastralParcelTableFixedColumns } from "../../../config/inventory-columns";
import { ColumnsType } from "antd/es/table";
import api_routes from "../../../config/api-routes";
import DeleteModal from "../../../components/Modals/DeleteModal";
import useHttp from "../../../hooks/use-http";
import ArkodParcelList from "../ArkodParcel/ArkodParcelList";
import { TableDimensions } from "../../../core/fe/TableDimensions";
import { calculateTableDimensions } from "../../../helpers/ScreenHeightHelpers";
import ArkodParcelForm from "../ArkodParcel/ArkodParcelForm";
import { TABLE_HEIGHT } from "../../../config/constants";

const CadastralParcelList: React.FC = () => {
	const { sendRequest: request } = useHttp();
	const [expandedRows, setExpandedRows] = useState<Key[]>([]);
	const [formCascadeParcelState, setFormCascadeParcelState] =
		useState<FormState>(FormState.None);
	const [arkodFormState, setFormArkodState] = useState<FormState>(
		FormState.None
	);
	const [deleteModalUrl, setDeleteModalUrl] = useState<string>("");
	const [openDeleteModal, setOpenDeleteModal] = useState<boolean>(false);
	const [changed, setChanged] = useState<boolean>(false);
	const [cadastralParcelId, setCadastralParcelId] = useState<
		number | undefined
	>(undefined);
	const [arkodParcelId, setArkodParcelId] = useState<number | undefined>(
		undefined
	);
	const [cadastralParcels, setCadastralParcels] = useState<
		CadastralParcelVm[]
	>([]);

	const openNewArkodParcelDrawer = (recivedId: number) => {
		setCadastralParcelId(recivedId);
		setFormArkodState(FormState.New);
	};

	const openNewCadastralParcelDrawer = () => {
		setFormCascadeParcelState(FormState.New);
	};

	const deleteCadastralParcel = (recivedId: number) => {
		setDeleteModalUrl(
			`${api_routes.ROUTE_INVENTORY_CADASTRAL_PARCELS}/${recivedId}`
		);
		setOpenDeleteModal(true);
	};

	const editCadastralParcelDrawer = (recivedId: number) => {
		setCadastralParcelId(recivedId);
		setFormCascadeParcelState(FormState.Edit);
	};

	const allCascadePArcelsColumns: TableColumn[] = [
		...cadastralParcelTableFixedColumns(
			openNewArkodParcelDrawer,
			editCadastralParcelDrawer,
			deleteCadastralParcel
		),
	];

	const cadastralarcleList: ColumnsType<any> | undefined =
		allCascadePArcelsColumns?.map((tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		}));

	const fetchCadastralParcels = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data: CadastralParcelVm[] = responseData.data.map(
					(attachmentData: CadastralParcelVm) =>
						Object.assign({}, attachmentData)
				);
				setCadastralParcels(data);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_INVENTORY_CADASTRAL_PARCELS}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		fetchCadastralParcels();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<>
				<Row className='header_container' align='middle'>
					<div>
						<h2 style={{ margin: "0px" }}>Katastarske čestice</h2>
					</div>
					<div>
						<Button
							style={{ margin: "0px" }}
							onClick={openNewCadastralParcelDrawer}>
							<PlusSquareOutlined />
							Dodaj Katastarsku česticu
						</Button>
					</div>
				</Row>
			</>
			<Table
				size='small'
				key='cadastral-parcel-table'
				pagination={false}
				columns={cadastralarcleList}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				expandable={{
					expandedRowRender: (record) => (
						<ArkodParcelList
							setDeleteModalUrl={setDeleteModalUrl}
							setOpenDeleteModal={setOpenDeleteModal}
							cadastralParcelId={record.id}
							arkodParcelId={arkodParcelId}
							setArkodFormState={setFormArkodState}
							setArkodParcelId={setArkodParcelId}
						/>
					),
				}}
				dataSource={cadastralParcels.map((row) => ({
					...row,
					key: `cp${row.id}`,
				}))}
			/>

			<CadastralParcelForm
				key='cadastral-parcel-drawer-form'
				formState={formCascadeParcelState}
				cadastralParcelId={cadastralParcelId}
				setChanged={setChanged}
				setFormState={setFormCascadeParcelState}
			/>

			<ArkodParcelForm
				key='arkod-parcel-drawer-form'
				formState={arkodFormState}
				arkodParcelId={arkodParcelId}
				setChanged={setChanged}
				setFormState={setFormArkodState}
				cadastralParcelId={cadastralParcelId}
			/>

			<DeleteModal
				url={deleteModalUrl}
				isVisible={openDeleteModal}
				setVisible={setOpenDeleteModal}
				setDeleted={setChanged}
			/>
		</>
	);
};

export default CadastralParcelList;
