import {
	Button,
	Col,
	Drawer,
	Form,
	Input,
	InputNumber,
	Row,
	Select,
	Space,
	message,
} from "antd";
import {
	ExpandOutlined,
	NumberOutlined,
	FontSizeOutlined,
} from "@ant-design/icons";
import { FormState } from "../../../core/AppEnums";
import { useEffect, useState } from "react";
import useHttp from "../../../hooks/use-http";
import api_routes from "../../../config/api-routes";
import { SelectOption } from "../../../core/fe/SelectOption";
import { useSelector } from "react-redux";
import { RootState } from "../../../store";

interface Props {
	formState: FormState;
	cadastralParcelId?: number | undefined;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const CadastralParcelForm: React.FC<Props> = (props) => {
	const { formState, cadastralParcelId, setFormState, setChanged } = props;
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const [isVisible, setVisible] = useState<boolean>(false);
	const [form] = Form.useForm();
	const [cadastralMuncitipalities, setCadastralMuncitipalities] = useState<
		SelectOption[]
	>([]);
	const [ownershipStatuses, setOwnershipStatuses] = useState<SelectOption[]>(
		[]
	);

	const { sendRequest: request } = useHttp();

	const onFinish = (values: any) => {
		const createCadastralParcel = {
			name: values.name,
			cadastralMunicipalityFk: Number(values.cadastralMunicipality),
			cadastralNumber: values.cadastralNumber,
			surface: values.surface,
			ownershipStatusFk: Number(values.ownershipStatus),
		};

		const fullToken = `${tokenType} ${token}`;

		const mapData = (cadasterResponseData: any) => {
			if (cadasterResponseData.success === undefined) {
				message.error(cadasterResponseData.message);
			} else {
				message.info(cadasterResponseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		request(
			{
				url:
					formState === FormState.New
						? api_routes.ROUTE_INVENTORY_CADASTRAL_PARCELS
						: `${api_routes.ROUTE_INVENTORY_CADASTRAL_PARCELS}/${cadastralParcelId}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					Authorization: fullToken,
					"Content-Type": "application/json",
				},
				body: createCadastralParcel,
			},
			mapData.bind(null)
		);
	};

	const getCadastralMuniticipalities = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];

				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: value.name,
					})
				);
				setCadastralMuncitipalities(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_INVENTORY_CADASTRAL_MUNITCIPALITIES,
			},
			mapData.bind(null)
		);
	};

	const getOwnershipStatuses = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];

				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: value.name,
					})
				);
				setOwnershipStatuses(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_INVENTORY_OWNERSHIP_STATUSES,
			},
			mapData.bind(null)
		);
	};

	const getCadastralParcel = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
				form.setFieldValue(
					"cadastralMunicipality",
					responseData.data.cadastralMunicipality.id
				);
				form.setFieldValue(
					"ownershipStatus",
					responseData.data.ownershipStatus.id
				);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_INVENTORY_CADASTRAL_PARCELS}/${cadastralParcelId}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			getCadastralMuniticipalities();
			getOwnershipStatuses();
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getCadastralMuniticipalities();
			getOwnershipStatuses();
			getCadastralParcel();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [formState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={
				formState === FormState.New
					? "Kreiraj katastarsku česticu"
					: "Prilagodi katastarsku česticu"
			}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='cadastral-parcel-form' onFinish={onFinish}>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"name"}
							key={"form-cadastral-parcel-name"}
							label='Naziv'
							rules={[
								{
									required: true,
									message: "Unesite naziv čestice!",
								},
								() => ({
									validator(_, value) {
										if (
											!value ||
											(value.length <= 100 &&
												value.length >= 3)
										) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Naziv mora biti duljine minimalno 3 i maksimalno 100 znakova."
											)
										);
									},
								}),
							]}>
							<Input addonAfter={<FontSizeOutlined />} />
						</Form.Item>
					</Col>
				</Row>

				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"cadastralMunicipality"}
							key={"form-cadastral-parcel-cadastral-municipality"}
							label='Katastarska općina'
							rules={[
								{
									required: true,
									message: "Odaberite općinu!",
								},
							]}>
							<Select options={cadastralMuncitipalities} />
						</Form.Item>
					</Col>
				</Row>

				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"cadastralNumber"}
							key={"form-cadastral-parcel-cadastral-number"}
							label='Katastarski broj'
							rules={[
								{
									required: true,
									message: "Unesite katastarski broj!",
								},
								() => ({
									validator(_, value) {
										if (!value || value.length <= 15) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Katastarski broj mora biti duljine maksimalno 15 znakova."
											)
										);
									},
								}),
							]}>
							<Input addonAfter={<NumberOutlined />} />
						</Form.Item>
					</Col>
				</Row>

				<Row gutter={16} style={{}}>
					<Col span={8}>
						<Form.Item
							name={"surface"}
							key={"form-cadastral-parcel-surface"}
							label='Površina'
							rules={[
								{
									required: true,
									pattern: new RegExp(/^(\d+\.?\d+)|(0)$/),
									message:
										"Površina mora biti pozitivan broj ili nula!",
								},
							]}>
							<InputNumber
								style={{ width: 200, marginLeft: "40px" }}
								addonAfter={<ExpandOutlined />}
							/>
						</Form.Item>
					</Col>
				</Row>

				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"ownershipStatus"}
							key={"form-cadastral-parcel-ownership-status"}
							label='Status vlasništva'
							rules={[
								{
									required: true,
									message: "Odaberite status!",
								},
							]}>
							<Select options={ownershipStatuses} />
						</Form.Item>
					</Col>
				</Row>

				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>
			</Form>
		</Drawer>
	);
};

export default CadastralParcelForm;
