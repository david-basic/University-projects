import { Table, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { TableColumn } from "../../../core/fe/TableColumns";
import { arkodParcelTableFixedColumns } from "../../../config/inventory-columns";
import api_routes from "../../../config/api-routes";
import { Key, useEffect, useState } from "react";
import { ArkodParcelVm } from "../../../core/be/ArkodParcelVm";
import useHttp from "../../../hooks/use-http";
import RowClusterList from "../RowCluster/RowClusterList";
import { FormState } from "../../../core/AppEnums";
import RowClusterForm from "../RowCluster/RowClusterForm";

interface Props {
	cadastralParcelId: number;
	arkodParcelId: number | undefined;
	setDeleteModalUrl: (newState: string) => void;
	setOpenDeleteModal: (newState: boolean) => void;
	setArkodFormState: (newState: FormState) => void;
	setArkodParcelId: (newState: number) => void;
}

const ArkodParcelList: React.FC<Props> = (props: Props) => {
	const {
		setDeleteModalUrl,
		cadastralParcelId,
		arkodParcelId,
		setOpenDeleteModal,
		setArkodFormState,
		setArkodParcelId,
	} = props;
	const { sendRequest: request } = useHttp();
	const [changed, setChanged] = useState<boolean>(false);
	const [expandedRows, setExpandedRows] = useState<readonly Key[]>([]);
	const [arkodParcels, setArkodParcels] = useState<ArkodParcelVm[]>([]);
	const [rowClusterId, setRowClusterId] = useState<number | undefined>(
		undefined
	);
	const [rowClusterFormState, setRowClusterFormState] = useState<FormState>(
		FormState.None
	);

	const openNewRowClusterDrawer = (recivedId: number) => {
		setArkodParcelId(recivedId);
		setRowClusterFormState(FormState.New);
	};

	const deleteArkodParcel = (recivedId: number) => {
		setDeleteModalUrl(
			`${api_routes.ROUTE_INVENTORY_ARKOD_PARCELS}/${recivedId}`
		);
		setOpenDeleteModal(true);
	};

	const editArkodParcelDrawer = (recivedId: number) => {
		setArkodParcelId(recivedId);
		setArkodFormState(FormState.Edit);
	};

	const allArkodColumns: TableColumn[] = [
		...arkodParcelTableFixedColumns(
			openNewRowClusterDrawer,
			editArkodParcelDrawer,
			deleteArkodParcel
		),
	];

	const arkodColumns: ColumnsType<any> | undefined = allArkodColumns?.map(
		(tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: `ap${tableColumn.key}`,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		})
	);

	const fetchArkodParcels = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data: ArkodParcelVm[] = responseData.data.map(
					(attachmentData: ArkodParcelVm) =>
						Object.assign({}, attachmentData)
				);
				setArkodParcels(data);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_INVENTORY_CADASTRAL_PARCELS}/${cadastralParcelId}/arcode-parcels`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		fetchArkodParcels();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Table
				size='small'
				key='arkod-parcel-table'
				pagination={false}
				columns={arkodColumns}
				expandable={{
					expandedRowRender: (record) => (
						<RowClusterList
							setDeleteModalUrl={setDeleteModalUrl}
							setOpenDeleteModal={setOpenDeleteModal}
							arkodParcelId={record.id}
							rowClusterId={rowClusterId}
							setRowClusterId={setRowClusterId}
							setFormRowClusterState={setRowClusterFormState}
						/>
					),
				}}
				dataSource={arkodParcels.map((row) => ({
					...row,
					key: `ac${row.id}`,
				}))}
			/>
			<RowClusterForm
				key='row-cluster-drawer-form'
				arkodParcelId={arkodParcelId}
				formState={rowClusterFormState}
				rowClusterId={rowClusterId}
				setChanged={setChanged}
				setFormState={setRowClusterFormState}
			/>
		</>
	);
};

export default ArkodParcelList;
