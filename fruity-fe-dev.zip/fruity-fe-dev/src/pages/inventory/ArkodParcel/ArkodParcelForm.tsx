import {
	Button,
	Col,
	Drawer,
	Form,
	Input,
	InputNumber,
	Row,
	Space,
	message,
} from "antd";
import { ExpandOutlined, NumberOutlined, FontSizeOutlined } from "@ant-design/icons";
import { useEffect, useState } from "react";
import { FormState } from "../../../core/AppEnums";
import useHttp from "../../../hooks/use-http";
import api_routes from "../../../config/api-routes";
import { useSelector } from "react-redux";
import { RootState } from "../../../store";

interface Props {
	formState: FormState;
	arkodParcelId?: number | undefined;
	cadastralParcelId?: number | undefined;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const ArkodParcelForm: React.FC<Props> = (props) => {
	const {
		formState,
		arkodParcelId,
		setFormState,
		setChanged,
		cadastralParcelId,
	} = props;
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const [isVisible, setVisible] = useState<boolean>(false);
	const [form] = Form.useForm();

	const { sendRequest: request } = useHttp();

	const onFinish = (values: any) => {
		const createArkodParcel = {
			name: values.name,
			cadastralParcelFk: values.cadastralParcel,
			arcode: Number(values.arcode),
			surface: Number(values.surface),
		};

		const fullToken = `${tokenType} ${token}`;

		const mapData = (arkodResponseData: any) => {
			if (arkodResponseData.success === undefined) {
				message.error(arkodResponseData.message);
			} else {
				message.info(arkodResponseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		request(
			{
				url:
					formState === FormState.New
						? api_routes.ROUTE_INVENTORY_ARKOD_PARCELS
						: `${api_routes.ROUTE_INVENTORY_ARKOD_PARCELS}/${arkodParcelId}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					Authorization: fullToken,
					"Content-Type": "application/json",
				},
				body: createArkodParcel,
			},
			mapData.bind(null)
		);
	};

	const getArkodParcel = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
				form.setFieldValue(
					"cadastralParcel",
					responseData.data.cadastralParcel.id
				);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_INVENTORY_ARKOD_PARCELS}/${arkodParcelId}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			form.resetFields();
			form.setFieldValue("cadastralParcel", cadastralParcelId);
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getArkodParcel();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [formState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={
				formState === FormState.New
					? "Kreiraj arkod parcelu"
					: "Prilagodi arkod parcelu"
			}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='cadastral-parcel-form' onFinish={onFinish}>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"name"}
							key={"form-cadastral-parcel-name"}
							label='Naziv'
							rules={[
								{
									required: true,
									message: "Unesite naziv čestice!",
								},
								() => ({
									validator(_, value) {
										if (
											!value ||
											(value.length <= 100 &&
												value.length >= 3)
										) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Naziv mora biti duljine minimalno 3 i maksimalno 100 znakova."
											)
										);
									},
								}),
							]}>
							<Input addonAfter={<FontSizeOutlined />} />
						</Form.Item>
					</Col>
				</Row>

				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"arcode"}
							key={"form-cadastral-parcel-arkod"}
							label='Arkod'
							rules={[
								{
									required: true,
									pattern: new RegExp(/^[1-9]+[0-9]*$/),
									message:
										"Arkod broj mora biti pozitivan broj veći od nule!",
								},
							]}>
							<InputNumber addonAfter={<NumberOutlined />} />
						</Form.Item>
					</Col>
				</Row>

				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"surface"}
							key={"form-cadastral-parcel-surface"}
							label='Površina'
							rules={[
								{
									required: true,
									pattern: new RegExp(/^(\d+\.?\d+)|(0)$/),
									message:
										"Površina mora biti pozitivan broj ili nula!",
								},
							]}>
							<InputNumber addonAfter={<ExpandOutlined />} />
						</Form.Item>
					</Col>
				</Row>

				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>

				<Form.Item
					name={"cadastralParcel"}
					key={"form-cadastral-parcel-cadastral-parcel"}></Form.Item>
			</Form>
		</Drawer>
	);
};

export default ArkodParcelForm;
