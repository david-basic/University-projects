import { Table, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { TableColumn } from "../../../core/fe/TableColumns";
import { rowTableFixedColumns } from "../../../config/inventory-columns";
import api_routes from "../../../config/api-routes";
import { Key, useEffect, useState } from "react";
import useHttp from "../../../hooks/use-http";
import { RowVm } from "../../../core/be/RowVm";
import { FormState, RowState } from "../../../core/AppEnums";

interface Props {
	rowClusterId: number;
	setDeleteModalUrl: (newState: string) => void;
	setOpenDeleteModal: (newState: boolean) => void;
	setRowId: (newState: number) => void;
	setRowFormState: (newState: FormState) => void;
	setRowState: (newState: RowState) => void;
	setRowCount: (newState: number) => void;
}

const RowList: React.FC<Props> = (props: Props) => {
	const {
		rowClusterId,
		setDeleteModalUrl,
		setOpenDeleteModal,
		setRowId,
		setRowFormState,
		setRowState,
		setRowCount,
	} = props;
	const { sendRequest: request } = useHttp();
	const [changed, setChanged] = useState<boolean>(false);
	const [expandedRows, setExpandedRows] = useState<readonly Key[]>([]);
	const [rows, setRows] = useState<RowVm[]>([]);

	const openNewAddRowAboveDrawer = (receivedId: number) => {
		setRowId(receivedId);
		setRowFormState(FormState.New);
		setRowState(RowState.Above);
	};
	const openNewAddRowBelowDrawer = (receivedId: number) => {
		setRowId(receivedId);
		setRowFormState(FormState.New);
		setRowState(RowState.Below);
	};
	const deleteRow = (recivedId: number) => {
		setDeleteModalUrl(`${api_routes.ROUTE_INVENTORY_ROWS}/${recivedId}`);
		setOpenDeleteModal(true);
	};
	const editRowDrawer = (recivedId: number) => {
		setRowId(recivedId);
		setRowFormState(FormState.Edit);
		setRowState(RowState.None);
	};

	const allRowColumns: TableColumn[] = [
		...rowTableFixedColumns(
			openNewAddRowAboveDrawer,
			openNewAddRowBelowDrawer,
			editRowDrawer,
			deleteRow
		),
	];

	const rowColumns: ColumnsType<any> | undefined = allRowColumns?.map(
		(tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		})
	);

	const fetchRows = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data: RowVm[] = responseData.data.map((rowData: RowVm) =>
					Object.assign({}, rowData)
				);
				setRows(data);
				setRowCount(data.length);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_INVENTORY_ROW_CLUSTERS}/${rowClusterId}/rows`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		fetchRows();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Table
				size='small'
				key='row-table'
				pagination={false}
				columns={rowColumns}
				dataSource={rows.map((row) => ({
					...row,
					key: `rc${row.id}`,
				}))}
			/>
		</>
	);
};

export default RowList;
