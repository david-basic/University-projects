import {
	Drawer,
	Row,
	Col,
	InputNumber,
	Space,
	Button,
	Form,
	Select,
	message,
} from "antd";
import { CalendarOutlined, NumberOutlined } from "@ant-design/icons";
import { useState, useEffect } from "react";
import { FormState, RowState } from "../../../core/AppEnums";
import useHttp from "../../../hooks/use-http";
import { SelectOption } from "../../../core/fe/Option";
import api_routes from "../../../config/api-routes";
import { useSelector } from "react-redux";
import { RootState } from "../../../store";

interface Props {
	formState: FormState;
	rowState: RowState;
	rowId?: number | undefined;
	rowClusterId?: number | undefined;
	rowCount: number;
	setFormState: (newState: FormState) => void;
	setRowState: (newState: RowState) => void;
	setChanged: (newState: boolean) => void;
}

const RowForm: React.FC<Props> = (props) => {
	const {
		formState,
		rowState,
		rowId,
		rowClusterId,
		rowCount,
		setFormState,
		setRowState,
		setChanged,
	} = props;
	const [isVisible, setVisible] = useState<boolean>(false);
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const [form] = Form.useForm();
	const [fruitCultivars, setfruitCultivars] = useState<SelectOption[]>([]);
	const { sendRequest: request } = useHttp();

	const onFinish = (values: any) => {
		const createRow = {
			ordinal: Number(values.ordinal),
			rowClusterFk: Number(values.rowCluster),
			numberOfSeedlings: Number(values.numberOfSeedlings),
			fruitCultivarFk: Number(values.fruitCultivar),
			plantingYear: Number(values.plantingYear),
		};

		const fullToken = `${tokenType} ${token}`;

		const mapData = (rowResponseData: any) => {
			if (rowResponseData.success === undefined) {
				message.error(rowResponseData.message);
			} else {
				message.info(rowResponseData.message);
				setChanged(true);
				setFormState(FormState.None);
				setRowState(RowState.None);
			}
		};

		request(
			{
				url:
					formState === FormState.New
						? api_routes.ROUTE_INVENTORY_ROWS
						: `${api_routes.ROUTE_INVENTORY_ROWS}/${rowId}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					Authorization: fullToken,
					"Content-Type": "application/json",
				},
				body: createRow,
			},
			mapData.bind(null)
		);
	};

	const getFruitCultivars = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];

				responseData.data.map((value: any) =>
					tempList.push({
						value: value.id,
						label: `${value.species} - ${value.name}`,
					})
				);
				setfruitCultivars(tempList);
			}
		};

		request(
			{
				url: api_routes.ROUTE_INVENTORY_FRUIT_CULTIVARS,
			},
			mapData.bind(null)
		);
	};

	const getRow = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
				form.setFieldValue(
					"rowCluster",
					responseData.data.rowCluster.id
				);
				form.setFieldValue(
					"fruitCultivar",
					responseData.data.fruitCultivar.id
				);
			}
		};

		request(
			{
				url: `${api_routes.ROUTE_INVENTORY_ROWS}/${rowId}`,
			},
			mapData.bind(null)
		);
	};

	const getRowOrdinal = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const data = responseData.data;

				switch (rowState) {
					case RowState.None:
						form.setFieldValue("ordinal", data.length + 1);
						break;
					case RowState.Above:
						form.setFieldValue("ordinal", data.ordinal);
						form.setFieldValue("rowCluster", data.rowCluster.id);
						break;
					case RowState.Below:
						form.setFieldValue("ordinal", data.ordinal + 1);
						form.setFieldValue("rowCluster", data.rowCluster.id);
						break;
				}
			}
		};

		request(
			{
				url:
					rowState === RowState.None
						? `${api_routes.ROUTE_INVENTORY_ROW_CLUSTERS}/${rowClusterId}/rows`
						: `${api_routes.ROUTE_INVENTORY_ROWS}/${rowId}`,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			getFruitCultivars();
			form.resetFields();
			form.setFieldValue("rowCluster", rowClusterId);
			getRowOrdinal();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getRow();
			getFruitCultivars();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [formState, rowState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={
				formState === FormState.New ? "Kreiraj red" : "Prilagodi red"
			}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='row-form' onFinish={onFinish}>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"ordinal"}
							key={"form-row-ordinal"}
							label='Redni broj'
							rules={[
								{
									required: true,
									message: "Odaberite redni broj.",
								},
								() => ({
									validator(_, value) {
										if (formState === FormState.Edit) {
											if (
												!value ||
												(value > 0 &&
													value <= rowCount + 1)
											) {
												return Promise.resolve();
											}
											return Promise.reject(
												new Error(
													`Redni broj mora biti između 0 i ${
														rowCount + 1
													}.`
												)
											);
										} else {
											return Promise.resolve();
										}
									},
								}),
							]}>
							{formState === FormState.Edit ? (
								<InputNumber addonAfter={<NumberOutlined />} />
							) : (
								<InputNumber
									disabled
									addonAfter={<NumberOutlined />}
								/>
							)}
						</Form.Item>
					</Col>
				</Row>

				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"fruitCultivar"}
							key={"form-row-fruit-cultivar-fk"}
							label='Kultura voća'
							rules={[
								{
									required: true,
									message: "Odaberite kulturu voća!",
								},
							]}>
							<Select options={fruitCultivars} />
						</Form.Item>
					</Col>
				</Row>

				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"numberOfSeedlings"}
							key={"form-row-numberOfSeedlings"}
							label='Broj sadnica'
							rules={[
								{
									required: true,
									pattern: new RegExp(/^[1-9]+[0-9]*$/),
									message:
										"Broj sadnica mora biti pozitivan broj ili nula!",
								},
							]}>
							<InputNumber addonAfter={<NumberOutlined />} />
						</Form.Item>
					</Col>
				</Row>

				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"plantingYear"}
							key={"form-row-planting-year"}
							label='Godina sadnje'
							rules={[
								{
									required: true,
									message: "Unesite godinu sadnje!",
								},
								() => ({
									validator(_, value) {
										const date = new Date();
										const year = date.getFullYear();
										if (
											!value ||
											(value > 1990 && value <= year)
										) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												`Godina sadnje mora biti između 1990. i ${
													year + 1
												}.`
											)
										);
									},
								}),
							]}>
							<InputNumber addonAfter={<CalendarOutlined />} />
						</Form.Item>
					</Col>
				</Row>

				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>

				<Form.Item
					name={"rowCluster"}
					key={"form-row-row-cluster-fk"}></Form.Item>
			</Form>
		</Drawer>
	);
};

export default RowForm;
