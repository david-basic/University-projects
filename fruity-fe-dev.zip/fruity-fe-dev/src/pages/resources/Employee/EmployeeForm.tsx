import {
	IdcardOutlined,
	PhoneOutlined,
	MailOutlined,
	EuroOutlined,
} from "@ant-design/icons";
import {
	Button,
	Col,
	Drawer,
	Form,
	Input,
	InputNumber,
	Row,
	Space,
	message,
} from "antd";
import { FormState } from "../../../core/AppEnums";
import { useEffect, useState } from "react";
import useHttp from "../../../hooks/use-http";
import api_routes from "../../../config/api-routes";
import styles from "./EmployeeForm.module.css";

interface Props {
	token: string;
	formState: FormState;
	employeeId?: number | undefined;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const EmployeeForm: React.FC<Props> = (props) => {
	const { formState, token, employeeId, setChanged, setFormState } = props;
	const [form] = Form.useForm();
	const [isVisible, setVisible] = useState<boolean>(false);

	const { sendRequest: employeesRequest } = useHttp();

	const onFinish = (values: any) => {
		const createEmployeeData = {
			firstName: values.firstName,
			lastName: values.lastName,
			email: values.email,
			phoneNumber: values.phone,
			costPerHour: Number(values.costPerHour),
		};

		const mapData = (registerResponseData: any) => {
			if (registerResponseData.success === undefined) {
				message.error(registerResponseData.message);
			} else {
				message.info(registerResponseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		employeesRequest(
			{
				url:
					formState === FormState.New
						? api_routes.ROUTE_RESOURCES_EMPLOYEES
						: `${api_routes.ROUTE_RESOURCES_EMPLOYEES}/${employeeId}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: token,
				},
				body: createEmployeeData,
			},
			mapData.bind(null)
		);
	};

	const getEmployee = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
			}
		};

		employeesRequest(
			{
				url: `${api_routes.ROUTE_RESOURCES_EMPLOYEES}/${employeeId}`,
				method: "GET",
				headers: {
					Authorization: token,
				},
				body: null,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getEmployee();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}

		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [formState]);

	const cancelHandler = () => {
		setVisible(false);
	};

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={formState === FormState.New ? "Kreiraj" : "Prilagodi"}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='employee-form' onFinish={onFinish}>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"firstName"}
							key={"form-employee-firstName"}
							label='Ime'
							rules={[
								{
									required: true,
									message: "Unesite ime zaposlenika!",
								},
							]}>
							<Input
								suffix={<IdcardOutlined />}
								placeholder='Unesite IME zaposlenika.'
							/>
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"lastName"}
							key={"form-employee-lastName"}
							label='Prezime'
							rules={[
								{
									required: true,
									message: "Unesite prezime zaposlenika!",
								},
							]}>
							<Input
								suffix={<IdcardOutlined />}
								placeholder='Unesite PREZIME zaposlenika.'
							/>
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"email"}
							key={"form-employee-email"}
							label='Email'
							rules={[
								{
									required: false,
									pattern: new RegExp(
										// eslint-disable-next-line no-useless-escape
										/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
									),
									message:
										"Molimo vas unesite validan email zaposlenika!",
								},
							]}>
							<Input
								suffix={<MailOutlined />}
								placeholder='Unesite EMAIL zaposlenika.'
							/>
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"phoneNumber"}
							key={"form-employee-phone-number"}
							label='Telefon'
							rules={[
								{
									required: false,
									pattern: new RegExp(/^[0-9*#+/-]+$/),
									message:
										"Molimo vas unesire validan telefonski broj zaposlenika!",
								},
								() => ({
									validator(_, value) {
										if (!value || value.length <= 25) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Duljina telefonskog broja mora biti manja od 25 znakova"
											)
										);
									},
								}),
							]}>
							<Input
								suffix={<PhoneOutlined />}
								placeholder='Unesite TELEFON zaposlenika.'
							/>
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"costPerHour"}
							key={"form-employee-cost-per-hour"}
							label='Satnica'
							rules={[
								{
									required: true,
									pattern: new RegExp(/^(\d+\.?\d+)|(0)$/),
									message:
										"Unesena satnica mora biti pozitivan broj ili nula!",
								},
							]}>
							<InputNumber prefix={<EuroOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={cancelHandler}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>
			</Form>
		</Drawer>
	);
};

export default EmployeeForm;
