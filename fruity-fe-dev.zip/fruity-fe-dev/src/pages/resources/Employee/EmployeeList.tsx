import { Button, Col, Modal, QRCode, Row, Table, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { employeeTableFixedColumns } from "../../../config/resources-columns";
import { TableColumn } from "../../../core/fe/TableColumns";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { EmployeeVm } from "../../../core/be/EmployeeVm";
import { RootState } from "../../../store";
import api_routes from "../../../config/api-routes";
import useHttp from "../../../hooks/use-http";
import DeleteModal from "../../../components/Modals/DeleteModal";
import { PlusSquareOutlined } from "@ant-design/icons";
import EmployeeForm from "./EmployeeForm";
import { FormState } from "../../../core/AppEnums";
import { TABLE_HEIGHT } from "../../../config/constants";

const EmployeeList: React.FC = () => {
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const [changed, setChanged] = useState<boolean>(false);
	const [openModal, setOpenModal] = useState<boolean>(false);
	const [formState, setFormState] = useState<FormState>(FormState.None);
	const [openQrCode, setOpenQrCode] = useState<boolean>(false);
	const [qrCode, setQrCode] = useState<string>();
	const [employeeId, setEmployeeId] = useState<number | undefined>(undefined);
	const [employees, setEmployees] = useState<EmployeeVm[]>([]);

	const openNewForm = () => {
		setFormState(FormState.New);
	};

	const deleteEmploye = (recivedId: number) => {
		setEmployeeId(recivedId);
		setOpenModal(true);
	};

	const editDrawer = (recivedId: number) => {
		setEmployeeId(recivedId);
		setFormState(FormState.Edit);
	};

	const showQRcode = (recivedId: number) => {
		const mapQrCode = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				setQrCode(responseData.data.mobileToken);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		employeesRequest(
			{
				url: `${api_routes.ROUTE_RESOURCES_EMPLOYEES}/${recivedId}`,
				method: "GET",
				headers: {
					Authorization: fullToken,
				},
				body: null,
			},
			mapQrCode.bind(null)
		);
		setOpenQrCode(true);
	};
	const allEmployeeColumns: TableColumn[] = [
		...employeeTableFixedColumns(editDrawer, deleteEmploye, showQRcode),
	];

	const employeeColumns: ColumnsType<any> | undefined =
		allEmployeeColumns?.map((tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		}));

	const { sendRequest: employeesRequest } = useHttp();

	const fetchEmployees = () => {
		const mapEmployees = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const attachments: EmployeeVm[] = responseData.data.map(
					(attachmentData: EmployeeVm) =>
						Object.assign({}, attachmentData)
				);
				setEmployees(attachments);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		employeesRequest(
			{
				url: `${api_routes.ROUTE_RESOURCES_EMPLOYEES}`,
				method: "GET",
				headers: {
					Authorization: fullToken,
				},
				body: null,
			},
			mapEmployees.bind(null)
		);
	};

	useEffect(() => {
		//TODO
		fetchEmployees();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Row
				className='header_container'
				align='middle'
				style={{ marginBottom: "15px" }}>
				<div>
					<h2 style={{ margin: "0px" }}>Zaposlenici</h2>
				</div>
				<div>
					<Button style={{ margin: "0px" }} onClick={openNewForm}>
						<PlusSquareOutlined />
						Dodaj zaposlenika
					</Button>
				</div>
			</Row>
			<Table
				size='small'
				key='attachments-table'
				pagination={false}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				columns={employeeColumns}
				dataSource={employees}
			/>

			<DeleteModal
				url={`${api_routes.ROUTE_RESOURCES_EMPLOYEES}/${employeeId}`}
				isVisible={openModal}
				setVisible={setOpenModal}
				setDeleted={setChanged}
			/>

			<Modal
				title='Korisnicki QR code'
				open={openQrCode}
				onOk={() => {
					setOpenQrCode(false);
				}}
				footer={[
					<Button
						key='qr-code-ok'
						type='primary'
						onClick={() => {
							setOpenQrCode(false);
						}}>
						Ok
					</Button>,
				]}>
				<QRCode color={"#008000"} value={qrCode!} />

				<p>
					Skenirajte QR kod kako biste se autorizirali na mobilnom
					uređaju
				</p>
			</Modal>

			<EmployeeForm
				token={`${tokenType} ${token}`}
				formState={formState}
				employeeId={employeeId}
				setChanged={setChanged}
				setFormState={setFormState}
			/>
		</>
	);
};

export default EmployeeList;
