import {
	Drawer,
	Space,
	Button,
	Input,
	Row,
	Col,
	Form,
	InputNumber,
	Select,
	message,
} from "antd";
import {
	CalendarOutlined,
	SettingOutlined,
	EuroOutlined,
} from "@ant-design/icons";
import { FormState } from "../../../core/AppEnums";
import api_routes from "../../../config/api-routes";
import useHttp from "../../../hooks/use-http";
import { useEffect, useState } from "react";
import { SelectOption } from "../../../core/fe/SelectOption";
import { AttachmentVm } from "../../../core/be/AttachmentVm";
import styles from "./EquipmentForm.module.css";

interface Props {
	token: string;
	formState: FormState;
	equipmentId?: number | undefined;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const EquipmentForm: React.FC<Props> = (props) => {
	const { formState, token, equipmentId, setChanged, setFormState } = props;
	const [attachments, setAttachments] = useState<SelectOption[]>([]);
	const [form] = Form.useForm();
	const [isVisible, setVisible] = useState<boolean>(false);

	const { sendRequest: equipmentRequest } = useHttp();

	const onFinish = (values: any) => {
		const compatibleAttachments =
			values.compatibleAttachmentFks.map(Number);
		const createEquipmentData = {
			name: values.name,
			productionYear: Number(values.productionYear),
			costPerHour: Number(values.costPerHour),
			purchasePrice: Number(values.purchasePrice),
			compatibleAttachmentFks: compatibleAttachments,
		};

		const mapData = (registerResponseData: any) => {
			if (registerResponseData.success === undefined) {
				message.error(registerResponseData.message);
			} else {
				message.info(registerResponseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		equipmentRequest(
			{
				url:
					formState === FormState.New
						? api_routes.ROUTE_RESOURCES_EQUIPMENTS
						: `${api_routes.ROUTE_RESOURCES_EQUIPMENTS}/${equipmentId}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: token,
				},
				body: createEquipmentData,
			},
			mapData.bind(null)
		);
	};

	const getAttachments = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const tempList: SelectOption[] = [];

				responseData.data.map((attachment: any) =>
					tempList.push({
						value: attachment.id,
						label: attachment.name,
					})
				);
				setAttachments(tempList);
			}
		};

		equipmentRequest(
			{
				url: api_routes.ROUTE_RESOURCES_ATTACHMENTS,
				method: "GET",
				headers: {
					Authorization: token,
				},
				body: null,
			},
			mapData.bind(null)
		);
	};

	const getEquipment = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const selectedAttachments: Number[] = [];
				responseData.data.compatibleAttachments.map(
					(value: AttachmentVm) => {
						selectedAttachments.push(value.id);
					}
				);
				form.setFieldsValue(responseData.data);
				form.setFieldValue(
					"compatibleAttachmentFks",
					selectedAttachments
				);
			}
		};

		equipmentRequest(
			{
				url: `${api_routes.ROUTE_RESOURCES_EQUIPMENTS}/${equipmentId}`,
				method: "GET",
				headers: {
					Authorization: token,
				},
				body: null,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			getAttachments();
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getAttachments();
			getEquipment();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
	}, [formState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={formState === FormState.New ? "Kreiraj" : "Prilagodi"}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='equipment-form' onFinish={onFinish}>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"name"}
							key={"form-equipment-name"}
							label='Naziv'
							rules={[
								{
									required: true,
									message: "Unesite naziv opreme",
								},
							]}>
							<Input
								suffix={<SettingOutlined />}
								placeholder='Unesite NAZIV opreme.'
							/>
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"productionYear"}
							key={"form-equipment-production-year"}
							label='Godina proizvodnje'
							rules={[
								{
									required: true,
									message: "Unesite godinu proizvodnje",
								},
								({ getFieldValue }) => ({
									validator(_, value) {
										if (
											!value ||
											getFieldValue("productionYear") >=
												1901
										) {
											return Promise.resolve();
										}
										let year = new Date().getFullYear();
										return Promise.reject(
											new Error(
												`Upišite validnu godinu (1901.-${year}.)`
											)
										);
									},
								}),
							]}>
							<InputNumber prefix={<CalendarOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"costPerHour"}
							key={"form-equipment-cost-per-hour"}
							label='Trošak po satu'
							rules={[
								{
									required: true,
									message: "Unesite trošak po satu",
								},
								({ getFieldValue }) => ({
									validator(_, value) {
										if (
											!value ||
											getFieldValue("costPerHour") >= 0
										) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Trošak NE SMIJE biti negativan broj!"
											)
										);
									},
								}),
							]}>
							<InputNumber prefix={<EuroOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"purchasePrice"}
							key={"form-equipment-purchase-price"}
							label='Trošak kupovine'
							rules={[
								{
									required: true,
									message: "Unesite trošak kupovine",
								},
								({ getFieldValue }) => ({
									validator(_, value) {
										if (
											!value ||
											getFieldValue("purchasePrice") > 0
										) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Trošak NE SMIJE biti negativan broj!"
											)
										);
									},
								}),
							]}>
							<InputNumber prefix={<EuroOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={12}>
						<Form.Item
							name={"compatibleAttachmentFks"}
							key={"form-equipment-compatible-attachments-fks"}
							label='Prikladni priključci'>
							<Select options={attachments} mode='multiple' />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>
			</Form>
		</Drawer>
	);
};

export default EquipmentForm;
