import { Button, Row, Table, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { equipmentTableFixedColumns } from "../../../config/resources-columns";
import { TableColumn } from "../../../core/fe/TableColumns";
import { RootState } from "../../../store";
import { useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { EquipmentVm } from "../../../core/be/EquipmentVm";
import useHttp from "../../../hooks/use-http";
import api_routes from "../../../config/api-routes";
import DeleteModal from "../../../components/Modals/DeleteModal";
import { PlusSquareOutlined } from "@ant-design/icons";
import EquipmentForm from "./EquipmentForm";
import { FormState } from "../../../core/AppEnums";
import { TABLE_HEIGHT } from "../../../config/constants";

const EquipmentList: React.FC = () => {
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const [changed, setChanged] = useState<boolean>(false);
	const [openModal, setOpenModal] = useState<boolean>(false);
	const [formState, setFormState] = useState<FormState>(FormState.None);
	const [equipmentId, setEquipmentId] = useState<number | undefined>(
		undefined
	);
	const [equipments, setEquipments] = useState<EquipmentVm[]>([]);

	const deleteEmploye = (recivedId: number) => {
		setEquipmentId(recivedId);
		setOpenModal(true);
	};

	const openNewForm = () => {
		setFormState(FormState.New);
	};

	const editDrawer = (recivedId: number) => {
		setEquipmentId(recivedId);
		setFormState(FormState.Edit);
	};

	const allEquipmentColumns: TableColumn[] = [
		...equipmentTableFixedColumns(editDrawer, deleteEmploye),
	];

	const equipmentColumns: ColumnsType<any> | undefined =
		allEquipmentColumns?.map((tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		}));

	const { sendRequest: equipmentsRequest } = useHttp();

	const fetchEquipments = () => {
		const mapEquipments = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const equipment: EquipmentVm[] = responseData.data.map(
					(equipmentData: EquipmentVm) =>
						Object.assign({}, equipmentData)
				);
				setEquipments(equipment);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		equipmentsRequest(
			{
				url: `${api_routes.ROUTE_RESOURCES_EQUIPMENTS}`,
				method: "GET",
				headers: {
					Authorization: fullToken,
				},
				body: "",
			},
			mapEquipments.bind(null)
		);
	};

	useEffect(() => {
		//TODO
		fetchEquipments();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Row
				className='header_container'
				align='middle'
				style={{ marginBottom: "15px" }}>
				<div>
					<h2 style={{ margin: "0px" }}>Oprema</h2>
				</div>
				<div>
					<Button style={{ margin: "0px" }} onClick={openNewForm}>
						<PlusSquareOutlined />
						Dodaj opremu
					</Button>
				</div>
			</Row>
			<Table
				size='small'
				key='equipment-table'
				pagination={false}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				columns={equipmentColumns}
				dataSource={equipments}
			/>
			<DeleteModal
				url={`${api_routes.ROUTE_RESOURCES_EQUIPMENTS}/${equipmentId}`}
				isVisible={openModal}
				setVisible={setOpenModal}
				setDeleted={setChanged}
			/>
			<EquipmentForm
				token={`${tokenType} ${token}`}
				formState={formState}
				equipmentId={equipmentId}
				setChanged={setChanged}
				setFormState={setFormState}
			/>
		</>
	);
};

export default EquipmentList;
