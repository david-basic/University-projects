import { Button, Row, Table, message } from "antd";
import { ColumnsType } from "antd/es/table";
import { useEffect, useState } from "react";
import api_routes from "../../../config/api-routes";
import { equipmentTableFixedColumns } from "../../../config/resources-columns";
import { AttachmentVm } from "../../../core/be/AttachmentVm";
import { TableColumn } from "../../../core/fe/TableColumns";
import useHttp from "../../../hooks/use-http";
import { useSelector } from "react-redux";
import { RootState } from "../../../store";
import DeleteModal from "../../../components/Modals/DeleteModal";
import { FormState } from "../../../core/AppEnums";
import { PlusSquareOutlined } from "@ant-design/icons";
import AttachmentsForm from "./AttachmentsForm";
import { TABLE_HEIGHT } from "../../../config/constants";

const AttachmentsList: React.FC = () => {
	const tokenType = useSelector((state: RootState) => state.auth.tokenType);
	const token = useSelector((state: RootState) => state.auth.accessToken);
	const [changed, setChanged] = useState<boolean>(false);
	const [openModal, setOpenModal] = useState<boolean>(false);
	const [formState, setFormState] = useState<FormState>(FormState.None);
	const [attachmentId, setAttachmentId] = useState<number | undefined>(
		undefined
	);
	const [attachments, setAttachments] = useState<AttachmentVm[]>([]);

	const deleteEmploye = (recivedId: number) => {
		setAttachmentId(recivedId);
		setOpenModal(true);
	};

	const openNewForm = () => {
		setFormState(FormState.New);
	};

	const editDrawer = (recievedId: number) => {
		setAttachmentId(recievedId);
		setFormState(FormState.Edit);
	};

	const allAttachmentColumns: TableColumn[] = [
		...equipmentTableFixedColumns(editDrawer, deleteEmploye),
	];

	const attachmentList: ColumnsType<any> | undefined =
		allAttachmentColumns?.map((tableColumn: TableColumn) => ({
			title: `${tableColumn.title}`,
			dataIndex: tableColumn.dataIndex,
			key: tableColumn.key,
			align: tableColumn.align,
			width: tableColumn.width,
			render: tableColumn.render,
		}));

	const { sendRequest: attachmentsRequest } = useHttp();

	const fetchAttachments = () => {
		const mapAttachments = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				const attachments: AttachmentVm[] = responseData.data.map(
					(attachmentData: AttachmentVm) =>
						Object.assign({}, attachmentData)
				);
				setAttachments(attachments);
			}
		};

		const fullToken = `${tokenType} ${token}`;

		attachmentsRequest(
			{
				url: `${api_routes.ROUTE_RESOURCES_ATTACHMENTS}`,
				method: "GET",
				headers: {
					Authorization: fullToken,
				},
				body: "",
			},
			mapAttachments.bind(null)
		);
	};

	useEffect(() => {
		//TODO
		fetchAttachments();
		setChanged(false);
	}, [changed]);

	return (
		<>
			<Row
				className='header_container'
				align='middle'
				style={{ marginBottom: "15px" }}>
				<div>
					<h2 style={{ margin: "0px" }}>Priključci</h2>
				</div>
				<div>
					<Button style={{ margin: "0px" }} onClick={openNewForm}>
						<PlusSquareOutlined />
						Dodaj Priključak
					</Button>
				</div>
			</Row>
			<Table
				size='small'
				key='attachments-table'
				pagination={false}
				scroll={{
					y: TABLE_HEIGHT,
				}}
				columns={attachmentList}
				dataSource={attachments}
			/>
			<DeleteModal
				key='attachments-delete-modal'
				url={`${api_routes.ROUTE_RESOURCES_ATTACHMENTS}/${attachmentId}`}
				isVisible={openModal}
				setVisible={setOpenModal}
				setDeleted={setChanged}
			/>
			<AttachmentsForm
				key='attachments-drawer-form'
				token={`${tokenType} ${token}`}
				formState={formState}
				attachmentId={attachmentId}
				setChanged={setChanged}
				setFormState={setFormState}
			/>
		</>
	);
};

export default AttachmentsList;
