import {
	Drawer,
	Space,
	Button,
	Input,
	Row,
	Col,
	Form,
	InputNumber,
	message,
} from "antd";
import {
	CalendarOutlined,
	SettingOutlined,
	EuroOutlined,
} from "@ant-design/icons";
import { FormState } from "../../../core/AppEnums";
import useHttp from "../../../hooks/use-http";
import api_routes from "../../../config/api-routes";
import { useEffect, useState } from "react";
import styles from "./AttachmentsForm.module.css";


interface Props {
	token: string;
	formState: FormState;
	attachmentId?: number | undefined;
	setFormState: (newState: FormState) => void;
	setChanged: (newState: boolean) => void;
}

const AttachmentForm: React.FC<Props> = (props) => {
	const { formState, token, attachmentId, setFormState, setChanged } = props;
	const [form] = Form.useForm();
	const [isVisible, setVisible] = useState<boolean>(false);

	const { sendRequest: attachmentsRequest } = useHttp();

	const onFinish = (values: any) => {
		const createAttachmentData = {
			name: values.name,
			productionYear: Number(values.productionYear),
			costPerHour: Number(values.costPerHour),
			purchasePrice: Number(values.purchasePrice),
		};

		const mapData = (registerResponseData: any) => {
			if (registerResponseData.success === undefined) {
				message.error(registerResponseData.message);
			} else {
				message.info(registerResponseData.message);
				setChanged(true);
				setFormState(FormState.None);
			}
		};

		attachmentsRequest(
			{
				url:
					formState === FormState.New
						? api_routes.ROUTE_RESOURCES_ATTACHMENTS
						: `${api_routes.ROUTE_RESOURCES_ATTACHMENTS}/${attachmentId}`,
				method: formState === FormState.New ? "POST" : "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: token,
				},
				body: createAttachmentData,
			},
			mapData.bind(null)
		);
	};

	const getAttachment = () => {
		const mapData = async (responseData: any) => {
			if (responseData.success === undefined) {
				message.error("No data");
			} else {
				form.setFieldsValue(responseData.data);
			}
		};

		attachmentsRequest(
			{
				url: `${api_routes.ROUTE_RESOURCES_ATTACHMENTS}/${attachmentId}`,
				method: "GET",
				headers: {
					Authorization: token,
				},
				body: null,
			},
			mapData.bind(null)
		);
	};

	useEffect(() => {
		if (formState === FormState.New) {
			form.resetFields();
			setVisible(true);
		}
		if (formState === FormState.Edit) {
			getAttachment();
			setVisible(true);
		}
		if (formState === FormState.None) {
			form.resetFields();
			setVisible(false);
		}
	}, [formState]);

	return (
		<Drawer
			onClose={() => setFormState(FormState.None)}
			title={formState === FormState.New ? "Kreiraj" : "Prilagodi"}
			placement='right'
			width={"80vw"}
			open={isVisible}>
			<Form form={form} name='attachment-form' onFinish={onFinish}>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"name"}
							key={"form-attachment-name"}
							label='Naziv'
							rules={[
								{
									required: true,
									message: "Unesite naziv opreme!",
								},
							]}>
							<Input
								suffix={<SettingOutlined />}
								placeholder='Unesite NAZIV opreme.'
							/>
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Form.Item
							name={"productionYear"}
							key={"form-attachment-production-year"}
							label='Godina proizvodnje'
							rules={[
								{
									required: true,
									message: "Unesite godinu proizvodnje!",
								},
								({ getFieldValue }) => ({
									validator(_, value) {
										if (
											!value ||
											getFieldValue("productionYear") >=
												1901
										) {
											return Promise.resolve();
										}
										let year = new Date().getFullYear();
										return Promise.reject(
											new Error(
												`Upišite validnu godinu (1901.-${year}.)`
											)
										);
									},
								}),
							]}>
							<InputNumber prefix={<CalendarOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row gutter={16}>
					<Col span={8}>
						<Form.Item
							name={"costPerHour"}
							key={"form-attachment-cost-per-hour"}
							label='Trošak po satu'
							rules={[
								{
									required: true,
									message: "Unesite trošak po satu!",
								},
								({ getFieldValue }) => ({
									validator(_, value) {
										if (
											!value ||
											getFieldValue("costPerHour") >= 0
										) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Trošak NE SMIJE biti negativan broj!"
											)
										);
									},
								}),
							]}>
							<InputNumber prefix={<EuroOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Form.Item
							name={"purchasePrice"}
							key={"form-attachment-purchase-price"}
							label='Trošak kupovine'
							rules={[
								{
									required: true,
									message: "Unesite trošak kupovine!",
								},
								({ getFieldValue }) => ({
									validator(_, value) {
										if (
											!value ||
											getFieldValue("purchasePrice") > 0
										) {
											return Promise.resolve();
										}
										return Promise.reject(
											new Error(
												"Trošak NE SMIJE biti negativan broj!"
											)
										);
									},
								}),
							]}>
							<InputNumber prefix={<EuroOutlined />} />
						</Form.Item>
					</Col>
				</Row>
				<Row>
					<Col span={8}>
						<Space>
							<Button
								type='primary'
								danger
								onClick={() => setVisible(false)}>
								Odustani
							</Button>
							<Button type='primary' htmlType='submit'>
								Spremi
							</Button>
						</Space>
					</Col>
				</Row>
			</Form>
		</Drawer>
	);
};

export default AttachmentForm;
