import image from "../assets/Fruity_logo.png";

const HomePage: React.FC = () => {
	return <img key={"home-logo"} src={image} alt='fruity logo' data-testid="imgTag" />;
};

export default HomePage;
