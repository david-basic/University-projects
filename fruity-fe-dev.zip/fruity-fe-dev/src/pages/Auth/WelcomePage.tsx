import React from "react";
import Welcome from "../../components/Auth/Welcome";

const WelcomePage = () => {
	return <Welcome />;
};

export default WelcomePage;
