import PasswordReset from "../../components/Auth/PasswordReset";

const PasswordResetPage = () => {
	return <PasswordReset />;
};

export default PasswordResetPage;
