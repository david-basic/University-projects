import React from "react";
import PwdResetForm from "../../components/Auth/PwdResetForm";

const PwdResetFormPage = () => {
	return <PwdResetForm />;
};

export default PwdResetFormPage;
