import { FC } from "react";
import { useDispatch } from "react-redux";
import { Button } from "antd";
import styles from "./LogoutPage.module.css";
import { authActions } from "../../store/auth-slice";
import localforage from "localforage";
import routes from "../../config/routes";
import { useNavigate } from "react-router-dom";

const LogoutPage: FC = () => {
	const dispatch = useDispatch();
	const navigate = useNavigate();

	const logoutHandler = () => {
		localforage.clear();
		sessionStorage.clear();
		localStorage.clear();

		dispatch(authActions.setIsLoggedIn(false));
		dispatch(authActions.resetAllStateToDefaults());

		navigate(routes.ROUTE_AUTH, { replace: true });
	};

	const cancelLogoutHandler = () => {
		navigate(routes.ROUTE_HOME, { replace: true });
	};

	return (
		<ul>
			<li>
				<h1>Jeste li sigurni da se želite odjaviti?</h1>
			</li>
			<li>
				<Button
					type='text'
					shape='round'
					size='large'
					onClick={logoutHandler}
					className={styles["btn-rounded-dark"]}>
					Odjavi se
				</Button>
			</li>
			<li>
				<Button
					type='text'
					shape='round'
					size='large'
					className={styles["btn-rounded-light"]}
					onClick={cancelLogoutHandler}>
					Odustani
				</Button>
			</li>
		</ul>
	);
};

export default LogoutPage;
