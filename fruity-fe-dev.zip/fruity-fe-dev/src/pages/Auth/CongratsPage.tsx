import React from "react";
import Congrats from "../../components/Auth/Congrats";

const CongratsPage = () => {
	return <Congrats />;
};

export default CongratsPage;
