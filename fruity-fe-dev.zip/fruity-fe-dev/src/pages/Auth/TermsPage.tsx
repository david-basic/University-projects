import React from "react";
import Terms from "../../components/Auth/Terms";

const TermsPage = () => {
	return <Terms />;
};

export default TermsPage;
