import Startup from "../../components/Auth/Startup";

const StartupPage = () => {
	return <Startup />;
};

export default StartupPage;
