import {
	UserOutlined,
	PhoneOutlined,
	HomeOutlined,
	FlagOutlined,
	NumberOutlined,
	EnvironmentOutlined,
} from "@ant-design/icons";
import { Button, Cascader, Form, Input, InputRef } from "antd";
import type { DefaultOptionType } from "antd/es/cascader";
import { FC, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import styles from "./ProfileSettingsForm.module.css";
import routes from "../../config/routes";
import useHttp from "../../hooks/use-http";
import api_routes from "../../config/api-routes";
import { useSelector } from "react-redux";
import { RootState } from "../../store";
import { SelectOption } from "../../core/fe/Option";

const ProfileSettingsForm: FC = () => {
	const navigate = useNavigate();
	const { sendRequest: fetchRequest } = useHttp();
	const { sendRequest: sendUserDataRequest } = useHttp();
	const tokenType: string = useSelector(
		(state: RootState) => state.auth.tokenType
	);
	const accessToken: string = useSelector(
		(state: RootState) => state.auth.accessToken
	);
	const [requestErrorMessage, setRequestErrorMessage] = useState("");
	const [countiesList, setCountiesList] = useState<SelectOption[]>([]);
	const userNameRef = useRef<InputRef>(null);
	const userPhoneRef = useRef<InputRef>(null);
	const userOibRef = useRef<InputRef>(null);
	const userAddressRef = useRef<InputRef>(null);

	function countiesHandler() {
		fetchRequest(
			{
				url: api_routes.ROUTE_COUNTIES_GET_ALL,
				method: "GET",
				headers: {
					Authorization: `${tokenType} ${accessToken}`,
				},
				body: null,
			},
			manageFetchedCounties.bind(null)
		);
	}

	function manageFetchedCounties(countiesResponseData: any) {
		if (countiesResponseData.success === undefined) {
			// console.log("There was response error");
			setRequestErrorMessage(countiesResponseData.message);
		} else {
			setRequestErrorMessage("");

			const tempList: SelectOption[] = [];

			countiesResponseData.data.map((county: any) =>
				tempList.push({
					value: county.id,
					label: `${county.abbreviation} ${county.name}`,
				})
			);
			setCountiesList(tempList);
		}
	}

	const filter = (inputValue: string, path: DefaultOptionType[]) =>
		path.some(
			(option) =>
				(option.label as string)
					.toLowerCase()
					.indexOf(inputValue.toLowerCase()) > -1
		);

	const onFinish = (values: any) => {
		// console.log("Values from the form:");
		// console.log(values);

		let opgName: string = "";
		if (Array.isArray(values.firmName)) {
			opgName = values.firmName.at(0);
		} else {
			opgName = values.firmName;
		}

		let opgOib: string = "";
		if (Array.isArray(values.oib)) {
			opgOib = values.oib.at(0);
		} else {
			opgOib = values.oib;
		}

		let opgPhone: string = "";
		if (Array.isArray(values.telephone)) {
			opgPhone = values.telephone.at(0);
		} else {
			opgPhone = values.telephone;
		}

		let opgAddress: string = "";
		if (Array.isArray(values.address)) {
			opgAddress = values.address.at(0);
		} else {
			opgAddress = values.address;
		}

		let updatedCountyId: string | null = "";
		if (sessionStorage.getItem("countyLabel") === values.county.at(0)) {
			updatedCountyId = sessionStorage.getItem("countyId");
		} else {
			updatedCountyId = values.county.at(0);
		}

		const updatedUserData = {
			name: opgName,
			oib: opgOib,
			phoneNumber: opgPhone,
			address: opgAddress,
			countyFk:
				updatedCountyId === null
					? parseInt("0")
					: parseInt(updatedCountyId),
		};

		// console.log("Updated user data prepared for PUT");
		// console.log(updatedUserData);

		sendUserDataRequest(
			{
				url: api_routes.ROUTE_USERS_UPDATE,
				method: "PUT",
				headers: {
					"Content-Type": "application/json",
					Authorization: `${tokenType} ${accessToken}`,
				},
				body: updatedUserData,
			},
			manageResponseData.bind(null)
		);

		function manageResponseData(responseData: any) {
			if (responseData.status !== 200) {
				// console.log("Failed to update user data: ");
				// console.log(responseData);
				setRequestErrorMessage(responseData.message);
			} else {
				sessionStorage.setItem("canFetchUserData", "true");
				// console.log("User data updated successfully: ");
				// console.log(responseData);

				navigate(routes.ROUTE_HOME);
			}
		}
	};

	return (
		<div className={`${styles.content} ${styles["centered-element"]}`}>
			<Form
				name='profile-settings'
				onFinish={onFinish}
				className={styles["settings-form"]}
				initialValues={{
					firmName: [sessionStorage.getItem("name")],
					address: [sessionStorage.getItem("address")],
					telephone: [sessionStorage.getItem("phone")],
					oib: [sessionStorage.getItem("oib")],
				}}>
				<h1>
					<UserOutlined /> Postavke gospodarstva
				</h1>
				{requestErrorMessage !== "" && (
					<p className={styles["error-text"]}>
						{requestErrorMessage}
					</p>
				)}
				<Form.Item
					name='firmName'
					hasFeedback
					rules={[
						{
							required: true,
							message:
								"Molimo unesite validan naziv vašeg gospodarstva!",
							pattern: new RegExp(
								/^[a-zA-Z0-9]+(?:\s[a-zA-Z0-9]+)*$/gi
							),
						},
					]}>
					<Input
						addonBefore={<HomeOutlined />}
						placeholder='Unesite NAZIV vašeg OPG-a'
						ref={userNameRef}
					/>
				</Form.Item>
				<Form.Item
					name='telephone'
					hasFeedback
					rules={[
						{
							required: true,
							message:
								"Molimo unesite validan telefonski broj gospodarstva!",
						},
						({ getFieldValue }) => ({
							validator(_) {
								if (getFieldValue("telephone").length <= 25) {
									return Promise.resolve();
								}
								return Promise.reject(
									new Error(
										"Duljina telefonskog broja mora biti manja od 25 znakova"
									)
								);
							},
						}),
					]}>
					<Input
						addonBefore={<PhoneOutlined />}
						placeholder='Unesite TELEFONSKI BROJ vašeg OPG-a'
						ref={userPhoneRef}
					/>
				</Form.Item>
				<Form.Item
					name='address'
					hasFeedback
					rules={[
						{
							required: true,
							message: "Molimo unesite adresu gospodarstva!",
						},
					]}>
					<Input
						addonBefore={<EnvironmentOutlined />}
						placeholder='Unesite ADRESU vašeg OPG-a'
						ref={userAddressRef}
					/>
				</Form.Item>
				<Form.Item
					name='county'
					initialValue={[sessionStorage.getItem("countyLabel")]}
					hasFeedback
					label={<FlagOutlined />}
					rules={[
						{
							required: true,
							message: "Molimo izaberite županiju!",
						},
					]}>
					<Cascader
						options={countiesList}
						placeholder='-- izaberite županiju vašeg OPG-a --'
						onClick={countiesHandler}
						onSearch={countiesHandler}
						showSearch={{ filter }}
					/>
				</Form.Item>
				<Form.Item
					name='oib'
					hasFeedback
					rules={[
						{
							required: true,
							pattern: new RegExp(/^(\d{10}(\d))$/),
							message: "Molimo unesite validan OIB!",
						},
					]}>
					<Input
						addonBefore={<NumberOutlined />}
						placeholder='Unesite OIB vašeg OPG-a'
						ref={userOibRef}
					/>
				</Form.Item>
				<Form.Item>
					<Link to={routes.ROUTE_HOME}>
						<Button
							type='text'
							shape='round'
							size='large'
							style={{ margin: "5px" }}
							className={styles["btn-rounded-dark"]}>
							Odustani
						</Button>
					</Link>
					<Button
						type='text'
						name='saveEditsButton'
						shape='round'
						size='large'
						htmlType='submit'
						style={{ margin: "5px" }}
						className={styles["btn-rounded-dark"]}>
						Spremi
					</Button>
				</Form.Item>
			</Form>
		</div>
	);
};

export default ProfileSettingsForm;
