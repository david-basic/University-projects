import { useRoutes } from "react-router-dom";
import "./App.css";
import StartupPage from "./pages/Auth/StartupPage";
import LoginPage from "./pages/Auth/LoginPage";
import SignupPage from "./pages/Auth/SignupPage";
import PasswordResetPage from "./pages/Auth/PasswordResetPage";
import PwdResetFormPage from "./pages/Auth/PwdResetFormPage";
import HomePage from "./pages/HomePage";
import WelcomePage from "./pages/Auth/WelcomePage";
import TermsPage from "./pages/Auth/TermsPage";
import CongratsPage from "./pages/Auth/CongratsPage";
import routes from "./config/routes";
import MainLayout from "./components/Layout/MainLayout";
import ChangePasswordForm from "./pages/UserManagement/ChangePasswordForm";
import ProfileSettingsForm from "./pages/UserManagement/ProfileSettingsForm";
import EmployeeList from "./pages/resources/Employee/EmployeeList";
import EquipmentList from "./pages/resources/Equipment/EquipmentList";
import AttachmentsList from "./pages/resources/Attachments/AttachmentsList";
import Protected from "./components/Auth/Protected";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "./store";
import { useEffect } from "react";
import { authActions } from "./store/auth-slice";
import localforage from "localforage";
import CadastralParcelList from "./pages/inventory/CadastralParcel/CadastralParcelList";
import LogoutPage from "./pages/Auth/LogoutPage";
import WorkAgentList from "./pages/Works/WorkAgent/WorkAgentList";
import WorkAttachmentList from "./pages/Works/WorkAttachment/WorkAttachmentList";
import WorkEmployeeList from "./pages/Works/WorkEmployee/WorkEmployeeList";
import WorkEquipmentList from "./pages/Works/WorkEquipment/WorkEquipmentList";
import WorkRowList from "./pages/Works/WorkRow/WorkRowList";
import WorksList from "./pages/Works/WorksList";
import RealisationAgentList from "./pages/Realisations/RealisationAgent/RealisationAgentList";
import RealisationAttachmentList from "./pages/Realisations/RealisationAttachment/RealisationAttachmentList";
import RealisationEquipmentList from "./pages/Realisations/RealisationEquipment/RealisationEquipmentList";
import RealisationRowList from "./pages/Realisations/RealisationRow/RealisationRowList";
import RealisationQuantitiesList from "./pages/Realisations/RealisationQuantity/RealisationQuantityList";

const App: React.FC = () => {
	const dispatch = useDispatch();

	useEffect(() => {
		async function getStoredStates() {
			const numberOfKeysInOfflineStore = await localforage
				.length()
				.then((numberOfKeys) => {
					return numberOfKeys;
				})
				.catch(function (err) {
					console.log("Error: " + err);
					return 0;
				});

			if (numberOfKeysInOfflineStore !== 0) {
				const loginState = await localforage
					.getItem<boolean>("isLoggedIn")
					.then((value) => {
						return value !== null ? value : false;
					})
					.catch((err) => {
						return false;
					});
				dispatch(authActions.setIsLoggedIn(loginState));

				const tokenValidState = await localforage
					.getItem<boolean>("isTokenValid")
					.then((value) => {
						return value !== null ? value : false;
					})
					.catch((err) => {
						return false;
					});
				dispatch(authActions.setIsTokenValid(tokenValidState));

				const username = await localforage
					.getItem<string>("username")
					.then((value) => {
						return value !== null ? value : "";
					})
					.catch((err) => {
						return "";
					});
				dispatch(authActions.setUsername(username));

				const accessToken = await localforage
					.getItem<string>("accessToken")
					.then((value) => {
						return value !== null ? value : "";
					})
					.catch((err) => {
						return "";
					});
				dispatch(authActions.setAccessToken(accessToken));

				const refreshToken = await localforage
					.getItem<string>("refreshToken")
					.then((value) => {
						return value !== null ? value : "";
					})
					.catch((err) => {
						return "";
					});
				dispatch(authActions.setRefreshToken(refreshToken));

				const tokenType = await localforage
					.getItem<string>("tokenType")
					.then((value) => {
						return value !== null ? value : "";
					})
					.catch((err) => {
						return "";
					});
				dispatch(authActions.setTokenType(tokenType));
			} else {
				dispatch(authActions.resetAllStateToDefaults());
			}
		}

		getStoredStates();
	}, [dispatch]);

	const isLoggedIn: boolean = useSelector(
		(state: RootState) => state.auth.isLoggedIn
	);

	const homeRoute = {
		path: routes.ROUTE_HOME,
		element: (
			<Protected
				isLoggedIn={isLoggedIn}
				children={<MainLayout children={<HomePage />} />}
			/>
		),
	};

	const authRoute = {
		path: routes.ROUTE_AUTH,
		element: <StartupPage />,
	};

	const authLoginRoute = {
		path: routes.ROUTE_AUTH_LOGIN,
		element: <LoginPage />,
	};

	const authPasswordResetRoute = {
		path: routes.ROUTE_AUTH_PASSWORD_RESET,
		element: <PasswordResetPage />,
	};

	const authPwdResetFormRoute = {
		path: routes.ROUTE_AUTH_PWD_RESET_FORM,
		element: <PwdResetFormPage />,
	};

	const authSignUpRoute = {
		path: routes.ROUTE_AUTH_SIGNUP,
		element: <SignupPage />,
	};

	const authWelcomeRoute = {
		path: routes.ROUTE_AUTH_WELCOME,
		element: <WelcomePage />,
	};

	const authTermsRoute = {
		path: routes.ROUTE_AUTH_TERMS,
		element: <TermsPage />,
	};

	const authCongratsRoute = {
		path: routes.ROUTE_AUTH_CONGRATS,
		element: <CongratsPage />,
	};

	const userLogoutRoute = {
		path: routes.ROUTE_USER_LOGOUT,
		element: (
			<Protected
				isLoggedIn={isLoggedIn}
				children={<MainLayout children={<LogoutPage />} />}
			/>
		),
	};

	const userChangePasswordRoute = {
		path: routes.ROUTE_USER_CHANGE_PASSWORD,
		element: (
			<Protected
				isLoggedIn={isLoggedIn}
				children={<MainLayout children={<ChangePasswordForm />} />}
			/>
		),
	};

	const userProfileSettingsRoute = {
		path: routes.ROUTE_USER_PROFILE_SETTINGS,
		element: (
			<Protected
				isLoggedIn={isLoggedIn}
				children={<MainLayout children={<ProfileSettingsForm />} />}
			/>
		),
	};

	const resourcesAttachmentsRoute = {
		path: routes.ROUTE_RESOURCES_ATTACHMENTS,
		element: (
			<Protected
				isLoggedIn={isLoggedIn}
				children={<MainLayout children={<AttachmentsList />} />}
			/>
		),
	};

	const resourcesEquipmentRoute = {
		path: routes.ROUTE_RESOURCES_EQUIPMENT,
		element: (
			<Protected
				isLoggedIn={isLoggedIn}
				children={<MainLayout children={<EquipmentList />} />}
			/>
		),
	};

	const resourcesEmployeeRoute = {
		path: routes.ROUTE_RESOURCES_EMPLOYEE,
		element: (
			<Protected
				isLoggedIn={isLoggedIn}
				children={<MainLayout children={<EmployeeList />} />}
			/>
		),
	};

	const inventoryCadastralParcelRoute = {
		path: routes.ROUTE_INVENTORY_CADASTRAL_PARCEL,
		element: <MainLayout children={<CadastralParcelList />} />,
	};

	const workRoute = {
		path: routes.ROUTE_WORKS,
		element: <MainLayout children={<WorksList />} />,
	};

	const workEmployeeRoute = {
		path: routes.ROUTE_WORKS_WORKERS,
		element: <MainLayout children={<WorkEmployeeList />} />,
	};

	const workRowRoute = {
		path: routes.ROUTE_WORKS_ROWS,
		element: <MainLayout children={<WorkRowList />} />,
	};

	const workEquipmentRoute = {
		path: routes.ROUTE_WORKS_EQUIPMENTS,
		element: <MainLayout children={<WorkEquipmentList />} />,
	};

	const workAttachmentRoute = {
		path: routes.ROUTE_WORKS_ATTACHMENTS,
		element: <MainLayout children={<WorkAttachmentList />} />,
	};

	const workAgentRoute = {
		path: routes.ROUTE_WORKS_AGENTS,
		element: <MainLayout children={<WorkAgentList />} />,
	};

	const realisationRowRoute = {
		path: routes.ROUTE_REALISATIONS_ROWS,
		element: <MainLayout children={<RealisationRowList />} />,
	};

	const realisationEquipmentRoute = {
		path: routes.ROUTE_REALISATIONS_EQUIPMENTS,
		element: <MainLayout children={<RealisationEquipmentList />} />,
	};

	const realisationAttachmentRoute = {
		path: routes.ROUTE_REALISATIONS_ATTACHMENTS,
		element: <MainLayout children={<RealisationAttachmentList />} />,
	};

	const realisationAgentRoute = {
		path: routes.ROUTE_REALISATIONS_AGENTS,
		element: <MainLayout children={<RealisationAgentList />} />,
	};

	const realisationQuantitiesRoute = {
		path: routes.ROUTE_REALISATIONS_QUANTITIES,
		element: <MainLayout children={<RealisationQuantitiesList />} />,
	};

	const routing = useRoutes([
		homeRoute,
		authRoute,
		authLoginRoute,
		userLogoutRoute,
		authPasswordResetRoute,
		authPwdResetFormRoute,
		authSignUpRoute,
		authWelcomeRoute,
		authTermsRoute,
		authCongratsRoute,
		userChangePasswordRoute,
		userProfileSettingsRoute,
		resourcesAttachmentsRoute,
		resourcesEquipmentRoute,
		resourcesEmployeeRoute,
		inventoryCadastralParcelRoute,
		workRoute,
		workEmployeeRoute,
		workRowRoute,
		workEquipmentRoute,
		workAttachmentRoute,
		workAgentRoute,
		realisationRowRoute,
		realisationEquipmentRoute,
		realisationAttachmentRoute,
		realisationAgentRoute,
		realisationQuantitiesRoute,
	]);

	return <>{routing}</>;
};

export default App;
