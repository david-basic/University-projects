import { ReactElement } from "react";
import { TableColumn } from "../core/fe/TableColumns";
import { Button, Divider } from "antd";
import { CheckOutlined, CloseOutlined } from "@ant-design/icons";
import { WorkTypeVm } from "../core/be/WorkTypeVm";
import moment from "moment";
import { EmployeeVm } from "../core/be/EmployeeVm";
import { RowVm } from "../core/be/RowVm";
import { EquipmentVm } from "../core/be/EquipmentVm";
import { AttachmentVm } from "../core/be/AttachmentVm";
import { AgentVm } from "../core/be/AgentVm";
import { UnitOfMeasurementVm } from "../core/be/UnitOfMeasurementVm";
import { WorkQuantityVm, WorkVm } from "../core/be/WorkVm";
import { FruitCultivarVm } from "../core/be/FruitCultivar";
import { FruitClassVm } from "../core/be/FruitClassVm";

export const workTableFixedColumns = (
	newRealisation: (selectedId: WorkVm) => void,
	editDrawer: (selectedId: WorkVm) => void,
	deleteDrawer: (selectedId: number) => void
): TableColumn[] => [
	{
		title: "Id",
		dataIndex: "id",
		key: "table-work-id",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Vrijeme početka",
		dataIndex: "startDateTime",
		key: "table-work-startDateTime",
		positioningNo: 100,
		render: (date: string): ReactElement => {
			return <span>{moment(date).format("HH:mm DD.MM.YY.")}</span>;
		},
		align: "center",
	},
	{
		title: "Vrijeme završetka",
		dataIndex: "endDateTime",
		key: "table-work-endDateTime",
		positioningNo: 100,
		render: (date: string): ReactElement => {
			return <span>{moment(date).format("HH:mm DD.MM.YY.")}</span>;
		},
		align: "center",
	},
	{
		title: "Tip",
		dataIndex: "type",
		key: "table-work-type",
		positioningNo: 100,

		render: (type: WorkTypeVm): ReactElement => {
			return <span>{type.name}</span>;
		},
		align: "center",
	},
	{
		title: "Završeno",
		dataIndex: "finished",
		key: "table-work-finished",
		positioningNo: 100,

		render: (finished: boolean): ReactElement => {
			return (
				<span>
					{finished === true ? (
						<CheckOutlined style={{ color: "green" }} />
					) : (
						<CloseOutlined style={{ color: "red" }} />
					)}
				</span>
			);
		},
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "",
		key: "table-works-actions",
		render: (row: WorkVm): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => newRealisation(row)}>
						Dodaj
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(row)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteDrawer(row.id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const workEmployeeTableFixedColumns = (
	editDrawer: (employeeId: number) => void,
	deleteEmploye: (employeeId: number) => void
): TableColumn[] => [
	{
		title: "Ime",
		dataIndex: "employee",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: EmployeeVm): ReactElement => {
			return <span>{employee.firstName}</span>;
		},
		align: "center",
	},
	{
		title: "Prezime",
		dataIndex: "employee",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: EmployeeVm): ReactElement => {
			return <span>{employee.lastName}</span>;
		},
		align: "center",
	},
	{
		title: "Bilješka",
		dataIndex: "note",
		key: "table-employee-cost-per-hour",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Početna satnica",
		dataIndex: "employee",
		key: "table-employee-cost-per-hour",
		positioningNo: 100,
		render: (employee: EmployeeVm): ReactElement => {
			return <span>{employee.costPerHour}</span>;
		},
		align: "center",
	},
	{
		title: "Satnica",
		dataIndex: "costPerHour",
		key: "table-employee-cost-per-hour",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "employee",
		key: "table-employee-actions",
		render: (employee: EmployeeVm): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(employee.id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteEmploye(employee.id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const workRowTableFixedColumns = (
	editDrawer: (employeeId: number) => void,
	deleteEmploye: (employeeId: number) => void
): TableColumn[] => [
	{
		title: "Tabela",
		dataIndex: "row",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: RowVm): ReactElement => {
			return <span>{employee.rowCluster.name}</span>;
		},
		align: "center",
	},
	{
		title: "Redni broj",
		dataIndex: "row",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: RowVm): ReactElement => {
			return <span>{employee.ordinal}</span>;
		},
		align: "center",
	},
	{
		title: "Broj sadnica",
		dataIndex: "row",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: RowVm): ReactElement => {
			return <span>{employee.numberOfSeedlings}</span>;
		},
		align: "center",
	},
	{
		title: "Vrsta sadnice",
		dataIndex: "row",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: RowVm): ReactElement => {
			return (
				<span>
					{employee.fruitCultivar.species}{" "}
					{employee.fruitCultivar.name}
				</span>
			);
		},
		align: "center",
	},
	{
		title: "Godina sadnje",
		dataIndex: "row",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: RowVm): ReactElement => {
			return <span>{employee.plantingYear}</span>;
		},
		align: "center",
	},
	{
		title: "Bilješka",
		dataIndex: "note",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "row",
		key: "table-employee-actions",
		render: (row: RowVm): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(row.id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteEmploye(row.id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const workEquipmentTableFixedColumns = (
	editDrawer: (employeeId: number) => void,
	deleteEmploye: (employeeId: number) => void
): TableColumn[] => [
	{
		title: "Oprema",
		dataIndex: "equipment",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: EquipmentVm): ReactElement => {
			return <span>{employee.name}</span>;
		},
		align: "center",
	},
	{
		title: "Godina proizvodnje",
		dataIndex: "equipment",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: EquipmentVm): ReactElement => {
			return <span>{employee.productionYear}</span>;
		},
		align: "center",
	},
	{
		title: "Bazni trošak po satu",
		dataIndex: "equipment",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: EquipmentVm): ReactElement => {
			return <span>{employee.costPerHour}</span>;
		},
		align: "center",
	},
	{
		title: "Trošak kupnje",
		dataIndex: "equipment",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: EquipmentVm): ReactElement => {
			return <span>{employee.purchasePrice}</span>;
		},
		align: "center",
	},
	{
		title: "Trošak po satu",
		dataIndex: "costPerHour",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Bilješka",
		dataIndex: "note",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "equipment",
		key: "table-employee-actions",
		render: (equipment: EquipmentVm): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(equipment.id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteEmploye(equipment.id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const workAttachmentTableFixedColumns = (
	editDrawer: (employeeId: number) => void,
	deleteEmploye: (employeeId: number) => void
): TableColumn[] => [
	{
		title: "Ime",
		dataIndex: "attachment",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: AttachmentVm): ReactElement => {
			return <span>{employee.name}</span>;
		},
		align: "center",
	},
	{
		title: "Bazni trošak po satu",
		dataIndex: "attachment",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: AttachmentVm): ReactElement => {
			return <span>{employee.costPerHour}</span>;
		},
		align: "center",
	},
	{
		title: "Trošak kupnje",
		dataIndex: "attachment",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: AttachmentVm): ReactElement => {
			return <span>{employee.purchasePrice}</span>;
		},
		align: "center",
	},
	{
		title: "Trošak po satu",
		dataIndex: "costPerHour",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Bilješka",
		dataIndex: "note",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "attachment",
		key: "table-employee-actions",
		render: (attachment: AttachmentVm): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(attachment.id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteEmploye(attachment.id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const workAgentTableFixedColumns = (
	editDrawer: (employeeId: number) => void,
	deleteEmploye: (employeeId: number) => void
): TableColumn[] => [
	{
		title: "Sredstvo",
		dataIndex: "agent",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: AgentVm): ReactElement => {
			return <span>{employee.name}</span>;
		},
		align: "center",
	},
	{
		title: "Proizvođač",
		dataIndex: "agent",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: AgentVm): ReactElement => {
			return <span>{employee.manufacturer}</span>;
		},
		align: "center",
	},
	{
		title: "Stanje",
		dataIndex: "agent",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: AgentVm): ReactElement => {
			return <span>{employee.state}</span>;
		},
		align: "center",
	},
	{
		title: "Količina",
		dataIndex: "agentQuantity",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Jedinica mjere",
		dataIndex: "agentUnitOfMeasure",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: UnitOfMeasurementVm): ReactElement => {
			return (
				<span>
					{employee.abbreviation}/{employee.name}
				</span>
			);
		},
		align: "center",
	},
	{
		title: "Trošak po jedinici mjere",
		dataIndex: "costPerUnitOfMeasure",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Količina vode",
		dataIndex: "waterQuantity",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Jedinica mjere",
		dataIndex: "waterUnitOfMeasure",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: UnitOfMeasurementVm): ReactElement => {
			return (
				<span>
					{employee.abbreviation}/{employee.name}
				</span>
			);
		},
		align: "center",
	},
	{
		title: "Bilješka",
		dataIndex: "note",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "agent",
		key: "table-employee-actions",
		render: (agent: AgentVm): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(agent.id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteEmploye(agent.id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const realisationTableFixedColumns = (
	editDrawer: (selectedId: number) => void,
	deleteDrawer: (selectedId: number) => void
): TableColumn[] => [
	{
		title: "Id",
		dataIndex: "id",
		key: "table-work-id",
		positioningNo: 100,
		align: "center",
	},

	{
		title: "Radnik",
		dataIndex: "employee",
		key: "table-work-startDateTime",
		positioningNo: 100,
		render: (employee: EmployeeVm): ReactElement => {
			return (
				<span>
					{employee.firstName} {employee.lastName}
				</span>
			);
		},
		align: "center",
	},
	{
		title: "Vrijeme početka",
		dataIndex: "startDateTime",
		key: "table-work-startDateTime",
		positioningNo: 100,
		render: (date: string): ReactElement => {
			return <span>{moment(date).format("HH:mm DD.MM.YY.")}</span>;
		},
		align: "center",
	},
	{
		title: "Vrijeme završetka",
		dataIndex: "endDateTime",
		key: "table-work-endDateTime",
		positioningNo: 100,
		render: (date: string): ReactElement => {
			return <span>{moment(date).format("HH:mm DD.MM.YY.")}</span>;
		},
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "id",
		key: "table-realisations-actions",
		render: (id: number): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-realisations-button'
						onClick={(): void => editDrawer(id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-realisations-button'
						onClick={(): void => deleteDrawer(id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const realisationQuantityTableFixedColumns = (
	editDrawer: (employeeId: any) => void,
	deleteEmploye: (employeeId: any) => void
): TableColumn[] => [
	{
		title: "Sorta",
		dataIndex: "fruitCultivar",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (fruitCultivar: FruitCultivarVm): ReactElement => {
			return (
				<span>
					{fruitCultivar.species} {fruitCultivar.name}
				</span>
			);
		},
		align: "center",
	},
	{
		title: "Klasa",
		dataIndex: "fruitClass",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (fruit: FruitClassVm): ReactElement => {
			return <span>{fruit.name}</span>;
		},
		align: "center",
	},
	{
		title: "Količina",
		dataIndex: "quantity",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Mjerna jedinica",
		dataIndex: "unitOfMeasure",
		key: "table-employee-first-name",
		positioningNo: 100,
		render: (employee: UnitOfMeasurementVm): ReactElement => {
			return (
				<span>
					{employee.abbreviation}/{employee.name}
				</span>
			);
		},
		align: "center",
	},
	{
		title: "Bilješka",
		dataIndex: "note",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "",
		key: "table-employee-actions",
		render: (row: WorkQuantityVm): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void =>
							editDrawer({
								realisaationId: row.realisationFk,
								fruitCultivarId: row.fruitCultivar.id,
								fruitClassId: row.fruitClass.id,
							})
						}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void =>
							deleteEmploye({
								realisaationId: row.realisationFk,
								fruitCultivarId: row.fruitCultivar.id,
								fruitClassId: row.fruitClass.id,
							})
						}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];
