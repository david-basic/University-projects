import { Button, Divider } from "antd";
import { ReactElement } from "react";
import { TableColumn } from "../core/fe/TableColumns";
import { CadastralMunicipalityVM } from "../core/be/CadastralMunicipalityVm";
import { FruitCultivarVm } from "../core/be/FruitCultivar";

export const cadastralParcelTableFixedColumns = (
	newDrawer: (selectedId: number) => void,
	editDrawer: (selectedId: number) => void,
	deleteCadastralParcel: (cadastralParcelId: number) => void
): TableColumn[] => [
	{
		title: "Id",
		dataIndex: "id",
		key: `table-cadastral-parcel-id${"id"}`,
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Ime",
		dataIndex: "name",
		key: "table-cadastral-parcel-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Ime",
		dataIndex: "name",
		key: "table-cadastral-parcel-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Katastarska opcina",
		dataIndex: "cadastralMunicipality",
		key: "table-cadastral-parcel-cadastralMunicipality",
		positioningNo: 100,
		render: (municipality: CadastralMunicipalityVM): ReactElement => {
			return (
				<span>
					{municipality.name} ({municipality.registrationNumber})
				</span>
			);
		},
		align: "center",
	},
	{
		title: "Povrsina (ha)",
		dataIndex: "surface",
		key: "table-cadastral-parcel-surface",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Vlasnistvo",
		dataIndex: "ownershipStatus",
		key: "table-cadastral-parcel-ownershipStatus",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "id",
		key: "table-cadastral-parcel-actions",
		render: (id: number): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => newDrawer(id)}>
						Dodaj
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteCadastralParcel(id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const arkodParcelTableFixedColumns = (
	newDrawer: (selectedId: number) => void,
	editDrawer: (selectedId: number) => void,
	deleteModal: (selectedId: number) => void
): TableColumn[] => [
	{
		title: "Key",
		dataIndex: "id",
		key: "id",
		positioningNo: 0,
	},
	{
		title: "Id",
		dataIndex: "id",
		key: "table-arkod-parcel-id",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Ime",
		dataIndex: "name",
		key: `table-arkod-parcel-name`,
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Arkod",
		dataIndex: "arcode",
		key: `table-arkod-parcel-arcode`,
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Povrsina",
		dataIndex: "surface",
		key: `table-arkod-parcel-surface`,
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "id",
		key: "table-arkod-parcel-actions",
		render: (id: number): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => newDrawer(id)}>
						Dodaj
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteModal(id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const rowClusterTableFixedColumns = (
	newDrawer: (selectedId: number) => void,
	editDrawer: (selectedId: number) => void,
	deleteModal: (selectedId: number) => void
): TableColumn[] => [
	{
		title: "Id",
		dataIndex: "id",
		key: "table-row-cluster-id",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Ime",
		dataIndex: "name",
		key: `table-row-cluster-name`,
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Povrsina",
		dataIndex: "surface",
		key: `table-row-cluster-surface`,
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "id",
		key: "table-row-cluster-actions",
		render: (id: number): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => newDrawer(id)}>
						Dodaj
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteModal(id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const rowTableFixedColumns = (
	newAddAboveDrawer: (selectedId: number) => void,
	newAddBelowDrawer: (selectedId: number) => void,
	editDrawer: (selectedId: number) => void,
	deleteModal: (selectedId: number) => void
): TableColumn[] => [
	{
		title: "Id",
		dataIndex: "id",
		key: "table-row-id",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Redni broj",
		dataIndex: "ordinal",
		key: `table-row-ordinal`,
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Broj sadnica",
		dataIndex: "numberOfSeedlings",
		key: `table-row-number-of-seedlings`,
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Sorta sadnice",
		dataIndex: "fruitCultivar",
		key: `table-row-number-of-seedlings`,
		render: (fruit: FruitCultivarVm): ReactElement => {
			return (
				<>
					<span>
						{fruit.species} - {fruit.name}
					</span>
				</>
			);
		},
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Godina sadnje",
		dataIndex: "plantingYear",
		key: `table-row-planting-year`,
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "id",
		key: "table-row-actions",
		render: (id: number): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => newAddAboveDrawer(id)}>
						Dodaj iznad
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => newAddBelowDrawer(id)}>
						Dodaj ispod
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteModal(id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 400,
		positioningNo: 100,
		align: "center",
	},
];
