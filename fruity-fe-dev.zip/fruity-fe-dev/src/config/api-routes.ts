export const routesParams = {
	API: "http://localhost:8080/api/v1",
};

const api_routes = {
	ROUTE_HOME: `${routesParams.API}`,

	ROUTE_AUTH_LOGIN: `${routesParams.API}/user-management/auth/login`,
	ROUTE_AUTH_REGISTER: `${routesParams.API}/user-management/auth/register`,
	ROUTE_AUTH_CONFIRM_REGISTRATION: `${routesParams.API}/user-management/auth/confirm-registration`,
	ROUTE_AUTH_REFRESH_TOKEN: `${routesParams.API}/user-management/auth/refresh-token`,

	ROUTE_COUNTIES_GET_ALL: `${routesParams.API}/user-management/counties`,

	ROUTE_USERS_GET: `${routesParams.API}/user-management/users`,
	ROUTE_USERS_UPDATE: `${routesParams.API}/user-management/users`,

	ROUTE_RESOURCES_ATTACHMENTS: `${routesParams.API}/resource-management/attachments`,
	ROUTE_RESOURCES_EMPLOYEES: `${routesParams.API}/resource-management/employees`,
	ROUTE_RESOURCES_EQUIPMENTS: `${routesParams.API}/resource-management/equipment`,
	ROUTE_RESOURCES_AGENTS: `${routesParams.API}/resource-management/agents`,
	ROUTE_RESOURCES_UNIT_OF_MEASUREMENT: `${routesParams.API}/resource-management/units-of-measure`,

	ROUTE_INVENTORY_CADASTRAL_PARCELS: `${routesParams.API}/inventory-management/cadastral-parcels`,
	ROUTE_INVENTORY_CADASTRAL_MUNITCIPALITIES: `${routesParams.API}/inventory-management/cadastral-municipalities`,
	ROUTE_INVENTORY_OWNERSHIP_STATUSES: `${routesParams.API}/inventory-management/cadastral-parcels/ownership-statuses`,
	ROUTE_INVENTORY_ARKOD_PARCELS: `${routesParams.API}/inventory-management/arcode-parcels`,
	ROUTE_INVENTORY_ROW_CLUSTERS: `${routesParams.API}/inventory-management/row-clusters`,
	ROUTE_INVENTORY_ROWS: `${routesParams.API}/inventory-management/rows`,
	ROUTE_INVENTORY_FRUIT_CULTIVARS: `${routesParams.API}/inventory-management/fruit-cultivars`,

	ROUTE_WORK_MANAGEMENT_WORKS: `${routesParams.API}/work-management/works`,
	ROUTE_WORK_MANAGEMENT_REALISATIONS: `${routesParams.API}/work-management/realisations`,
	ROUTE_WORK_MANAGEMENT_REALISATIONS_CLASSES: `${routesParams.API}/work-management/realisations/harvests/classes`,
};

export default api_routes;
