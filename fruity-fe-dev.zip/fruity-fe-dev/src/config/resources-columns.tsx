import { ReactElement } from "react";
import { TableColumn } from "../core/fe/TableColumns";
import { Button, Divider } from "antd";
import { QrcodeOutlined } from "@ant-design/icons";

export const employeeTableFixedColumns = (
	editDrawer: (employeeId: number) => void,
	deleteEmploye: (employeeId: number) => void,
	showQRcode: (employeeId: number) => void
): TableColumn[] => [
	{
		title: "Id",
		dataIndex: "id",
		key: "table-employee-id",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Ime",
		dataIndex: "firstName",
		key: "table-employee-first-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Prezime",
		dataIndex: "lastName",
		key: "table-employee-last-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Uloga",
		dataIndex: "role",
		key: "table-employee-role",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Email",
		dataIndex: "email",
		key: "table-employee-email",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Telefon",
		dataIndex: "phoneNumber",
		key: "table-employee-phone-number",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Satnica",
		dataIndex: "costPerHour",
		key: "table-employee-cost-per-hour",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "id",
		key: "table-employee-actions",
		render: (id: number): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteEmploye(id)}>
						Briši
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => showQRcode(id)}>
						<QrcodeOutlined />
					</Button>
				</>
			);
		},
		width: 200,
		positioningNo: 100,
		align: "center",
	},
];

export const equipmentTableFixedColumns = (
	editDrawer: (employeeId: number) => void,
	deleteEmploye: (employeeId: number) => void
): TableColumn[] => [
	{
		title: "Id",
		dataIndex: "id",
		key: "table-equipment-id",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Naziv",
		dataIndex: "name",
		key: "table-equipment-name",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Godina proizvodnje",
		dataIndex: "productionYear",
		key: "table-equipment-production-year",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Trošak po satu",
		dataIndex: "costPerHour",
		key: "table-equipment-cost-per-hour",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Cijena kupnje",
		dataIndex: "purchasePrice",
		key: "table-equipment-purchade-price",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "id",
		key: "table-equipment-actions",
		render: (id: number): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(id)}>
						Uredi
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteEmploye(id)}>
						Briši
					</Button>
				</>
			);
		},
		width: 150,
		positioningNo: 100,
		align: "center",
	},
];

export const attachmentsTableFixedColumns = (
	editDrawer: (employeeId: number) => void,
	deleteEmploye: (employeeId: number) => void
): TableColumn[] => [
	{
		title: "Id",
		dataIndex: "id",
		key: "table-attachment-",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Naziv",
		dataIndex: "name",
		key: "table-attachment-",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Godina proizvodnje",
		dataIndex: "productionYear",
		key: "table-attachment-",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Trošak po satu",
		dataIndex: "costPerHour",
		key: "table-attachment-",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Cijena kupnje",
		dataIndex: "purchasePrice",
		key: "table-attachment-",
		positioningNo: 100,
		align: "center",
	},
	{
		title: "Akcije",
		dataIndex: "id",
		key: "table-attachment-actions",
		render: (id: number): ReactElement => {
			return (
				<>
					<Button
						size='small'
						className='table-action-button'
						onClick={(): void => editDrawer(id)}>
						Edit
					</Button>
					<Divider type='vertical' />
					<Button
						size='small'
						type='primary'
						danger
						className='table-action-button'
						onClick={(): void => deleteEmploye(id)}>
						Delete
					</Button>
				</>
			);
		},
		width: 150,
		positioningNo: 100,
		align: "center",
	},
];
