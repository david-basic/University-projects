export const routesParams = {
	workId: ":workId",
	realisationId: ":realisationId",
};

const routes = {
	ROUTE_HOME: "/",

	ROUTE_AUTH: "/auth",
	ROUTE_AUTH_LOGIN: "/auth/login",
	ROUTE_AUTH_PASSWORD_RESET: "/auth/password-reset",
	ROUTE_AUTH_PWD_RESET_FORM: "/auth/pwd-reset-form",
	ROUTE_AUTH_SIGNUP: "/auth/signup",
	ROUTE_AUTH_WELCOME: "/auth/welcome",
	ROUTE_AUTH_TERMS: "/auth/terms",
	ROUTE_AUTH_CONGRATS: "/auth/congrats/:token",

	ROUTE_USER_LOGOUT: "/logout",
	ROUTE_USER_CHANGE_PASSWORD: "/user/change-password",
	ROUTE_USER_PROFILE_SETTINGS: "/user/profile-settings",

	ROUTE_RESOURCES_ATTACHMENTS: "/resources/attachments",
	ROUTE_RESOURCES_EQUIPMENT: "/resources/equipment",
	ROUTE_RESOURCES_EMPLOYEE: "/resources/employee",

	ROUTE_INVENTORY_CADASTRAL_PARCEL: "/inventory",

	ROUTE_WORKS: "/works",
	ROUTE_WORKS_WORKERS: `/works/employees/${routesParams.workId}`,
	ROUTE_WORKS_ROWS: `/works/rows/${routesParams.workId}`,
	ROUTE_WORKS_EQUIPMENTS: `/works/equipments/${routesParams.workId}`,
	ROUTE_WORKS_ATTACHMENTS: `/works/attachments/${routesParams.workId}`,
	ROUTE_WORKS_AGENTS: `/works/agents/${routesParams.workId}`,

	ROUTE_REALISATIONS_ROWS: `/realisations/rows/${routesParams.realisationId}`,
	ROUTE_REALISATIONS_EQUIPMENTS: `/realisations/equipments/${routesParams.realisationId}`,
	ROUTE_REALISATIONS_ATTACHMENTS: `/realisations/attachments/${routesParams.realisationId}`,
	ROUTE_REALISATIONS_AGENTS: `/realisations/agents/${routesParams.realisationId}`,
	ROUTE_REALISATIONS_QUANTITIES: `/realisations/quantities/${routesParams.realisationId}`,
};

export const sidebarKey = {
	Inventar: "sidebar-inventar",
	KatastarskeCestice: "sidebar-inventar-katastarske-cestice",
	ArkodParcele: "sidebar-inventar-arkod-parcele",
	Tabele: "sidebar-inventar-tabele",
	Redovi: "sidebar-inventar-redovi",
	Resursi: "sidebar-resursi",
	Djelatnici: "sidebar-resursi-djelatnici",
	Oprema: "sidebar-resursi-oprema",
	Prikljucci: "sidebar-resursi-prikljucci",
	Radovi: "sidebar-radovi",
	Realizacije: "sidebar-realizacije",
	Settings: "sidebar-settings",
	LogOut: "sidebar-logout",
};

export default routes;
