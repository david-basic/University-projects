export enum FormState {
	None,
	New,
	Edit,
	Changed,
}

export enum RowState {
	None,
	Above,
	Below,
}

export enum FormType {
	Work,
	Realisation,
}
