export interface WorkTypeVm {
	id: number;
	name: string;
	workersTab: boolean;
	rowsTab: boolean;
	equipmentsTab: boolean;
	attachmentsTab: boolean;
	agentsTab: boolean;
	quantitiesTab: boolean;
}
