export interface CadastralMunicipalityVM {
	id: number;
	registrationNumber: number;
	name: string;
}
