export interface AttachmentVm {
	id: number;
	name: string;
	productionYear: number;
	costPerHour: number;
	purchasePrice: number;
}
