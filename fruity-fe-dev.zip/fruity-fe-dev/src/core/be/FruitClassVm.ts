export interface FruitClassVm {
	id: number;
	number: number;
	name: string;
}
