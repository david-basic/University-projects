export interface FruitCultivarVm {
	key: number;
	id: number;
	name: string;
	species: string;
}
