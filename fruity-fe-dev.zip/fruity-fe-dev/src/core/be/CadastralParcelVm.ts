import { CadastralMunicipalityVM } from "./CadastralMunicipalityVm";

export interface CadastralParcelVm {
	key: string;
	id: number;
	name: string;
	CadastralMunicipality: CadastralMunicipalityVM;
	cadastralNumber: string;
	surface: number;
	ownershipStatus: string;
}
