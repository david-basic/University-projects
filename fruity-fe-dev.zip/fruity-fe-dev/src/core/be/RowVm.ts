import { FruitCultivarVm } from "./FruitCultivar";
import { RowClusterVm } from "./RowClusterVm";

export interface RowVm {
	key: string;
	id: number;
	ordinal: number;
	numberOfSeedlings: number;
	rowClusterFk: number;
	fruitCultivar: FruitCultivarVm;
	plantingYear: number;
	rowCluster: RowClusterVm;
}
