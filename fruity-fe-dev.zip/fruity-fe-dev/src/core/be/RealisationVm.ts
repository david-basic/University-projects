import { EmployeeVm } from "./EmployeeVm";

export interface RealisationVm {
	id: number;
	employee: EmployeeVm;
	startDateTime: string;
	endDateTime: string;
}
