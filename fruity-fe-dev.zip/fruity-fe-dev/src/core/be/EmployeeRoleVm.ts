export interface EmployeeRoleVm {
	id: number;
	name: string;
	displayName: string;
}
