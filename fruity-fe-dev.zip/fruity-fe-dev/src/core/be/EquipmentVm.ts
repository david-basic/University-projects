export interface EquipmentVm {
	id: number;
	name: string;
	productionYear: number;
	costPerHour: number;
	purchasePrice: number;
}
