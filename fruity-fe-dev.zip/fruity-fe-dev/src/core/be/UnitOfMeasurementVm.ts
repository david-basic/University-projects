export interface UnitOfMeasurementVm {
	id: number;
	abbreviation: string;
	name: string;
}
