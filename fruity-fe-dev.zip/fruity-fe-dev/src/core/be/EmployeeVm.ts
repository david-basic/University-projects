export interface EmployeeVm {
	id: number;
	firstName: string;
	lastName: string;
	email: string;
	phoneNumber: string;
	costPerHour: number;
	role: string;
}
