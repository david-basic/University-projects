export interface ArkodParcelVm {
	key: string;
	id: number;
	name: string;
	cadastralParcelFk: number;
	surface: number;
	arcode: number;
}
