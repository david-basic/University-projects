export interface RowClusterVm {
	key: string;
	id: number;
	name: string;
	arcodeParcelFk: number;
	surface: number;
}
