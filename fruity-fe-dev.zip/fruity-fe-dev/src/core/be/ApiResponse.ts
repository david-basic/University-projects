export interface ApiResponse<T> {
	timeStamp: string;
	success: boolean;
	status: number;
	message: string;
	data: T[];
}
