export interface AgentVm {
	id: number;
	name: string;
	manufacturer: string;
	state: string;
}
