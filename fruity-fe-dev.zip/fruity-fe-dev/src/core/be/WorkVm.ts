import { AgentVm } from "./AgentVm";
import { AttachmentVm } from "./AttachmentVm";
import { EmployeeVm } from "./EmployeeVm";
import { EquipmentVm } from "./EquipmentVm";
import { FruitClassVm } from "./FruitClassVm";
import { RowVm } from "./RowVm";
import { UnitOfMeasurementVm } from "./UnitOfMeasurementVm";
import { WorkTypeVm } from "./WorkTypeVm";

export interface WorkVm {
	id: number;
	startDateTime: string;
	endDateTime: string;
	finished: boolean;
	type: WorkTypeVm;
}
export interface WorkEmployeeVm {
	workFk: number;
	costPerHour: number;
	note: string;
	employee: EmployeeVm;
}

export interface WorkRowVm {
	workFk: number;
	note: string;
	row: RowVm;
}

export interface WorkEquipmentVm {
	workFk: number;
	note: string;
	equipment: EquipmentVm[];
}

export interface WorkAttachmentVm {
	workFk: number;
	note: string;
	attachment: AttachmentVm[];
}

export interface WorkAgentVm {
	workFk: number;
	note: string;
	agent: AgentVm[];
}

export interface WorkQuantityVm {
	realisationFk: number;
	fruitCultivar: FruitClassVm;
	fruitClass: FruitClassVm;
	quantity: number;
	unitOfMeasure: UnitOfMeasurementVm;
}
