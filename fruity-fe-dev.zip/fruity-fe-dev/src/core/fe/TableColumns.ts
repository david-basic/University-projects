import { ReactElement } from "react";

export interface TableColumn {
	title: string;
	dataIndex: string | string[];
	key: string;
	positioningNo: number;
	align?: "left" | "right" | "center";
	fixed?: "left" | "right" | boolean;
	width?: string | number;
	render?: (value: any, record?: any) => ReactElement;
}
