export interface TableDimensions {
	headerHeight: number;
	screenHeight: number;
	tableHeaderHeight: number;
}
