const routes = {
	ROUTE_HOME: "/",

	ROUTE_XSD_VALIDATION: "/xsd",
	ROUTE_RNG_VALIDATION: "/rng",
	ROUTE_JAXB_VALIDATION: "/jaxb",
	ROUTE_DHMZ: "/dhmz",
	ROUTE_MEMES_API: "/memes",
};

export default routes;
