import React from "react";

const Homepage = () => {
	return (
		<div className='container-fluid'>
			<div className='h1'>Homepage</div>
		</div>
	);
};

export default Homepage;
