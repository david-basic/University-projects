import Navigation from "./navigation/Navigation";

const Header = () => {
	return <>
        <Navigation/>
    </>;
};

export default Header;
