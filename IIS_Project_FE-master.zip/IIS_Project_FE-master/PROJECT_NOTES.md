# Project notes during coding

- stao na video 268
