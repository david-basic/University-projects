# PPPK_MVCApp

MVC app with Entity framework for PPPK project delivery for 9th week of exercises.
