package hr.algebra.pppkandroidapp

import android.os.Bundle

interface NavigableFragment {
    fun navigate(bundle: Bundle)
}