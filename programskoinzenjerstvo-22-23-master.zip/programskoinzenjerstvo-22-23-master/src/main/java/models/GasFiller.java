package models;

public interface GasFiller {
    void refillGas(Vehicle vehicle);
}
