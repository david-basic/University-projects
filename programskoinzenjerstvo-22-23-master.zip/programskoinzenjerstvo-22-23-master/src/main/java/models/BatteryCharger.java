package models;

public interface BatteryCharger {
    void chargeBattery(Vehicle vehicle);
}
