package models;

public enum TrainType {
    SMALL,
    LARGE
}
