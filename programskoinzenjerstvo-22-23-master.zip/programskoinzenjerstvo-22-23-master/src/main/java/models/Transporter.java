package models;

public interface Transporter {
    void addVehicle(Vehicle vehicle);
}
