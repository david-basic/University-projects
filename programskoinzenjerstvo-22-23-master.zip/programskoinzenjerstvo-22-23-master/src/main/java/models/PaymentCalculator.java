package models;

public interface PaymentCalculator {
    double getPayment();
}
