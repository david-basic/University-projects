package models;

public enum VehicleType {
    CAR,
    VAN,
    BUS,
    TRUCK
}
