package hr.algebra.tabletopshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TabletopShopApplicationTests {

    @Test
    void contextLoads() {
    }

}
