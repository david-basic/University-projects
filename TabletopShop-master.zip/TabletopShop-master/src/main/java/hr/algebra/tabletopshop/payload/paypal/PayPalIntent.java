package hr.algebra.tabletopshop.payload.paypal;

public enum PayPalIntent {
    
    CAPTURE,
    AUTHORIZE;
    
}
