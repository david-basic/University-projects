package hr.algebra.tabletopshop.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RegisterSuccessDto {
    private Boolean success;
}
