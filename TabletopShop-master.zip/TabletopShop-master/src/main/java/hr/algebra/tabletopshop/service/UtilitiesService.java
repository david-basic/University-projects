package hr.algebra.tabletopshop.service;

public interface UtilitiesService {
    Integer calculateNextItemIdInSequence();
    
    Integer calculateNextCartIdInSequence();
    
    Integer calculateNextCategoryIdInSequence();
    
    Integer calculateNextLogIdInSequence();
}
