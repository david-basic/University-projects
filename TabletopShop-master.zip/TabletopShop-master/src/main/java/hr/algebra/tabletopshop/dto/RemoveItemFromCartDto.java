package hr.algebra.tabletopshop.dto;

public record RemoveItemFromCartDto(Double cartTotal) {
}
