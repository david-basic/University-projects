package hr.algebra.tabletopshop.payload.paypal;

public enum PayPalStatus {
    
    CREATED,
    SAVED,
    APPROVED,
    VOIDED,
    COMPLETED,
    PAYER_ACTION_REQUIRED;
    
}
