package hr.algebra.tabletopshop.payload.paypal;

public enum PurchaseUnitItemCategory {
    DIGITAL_GOODS,
    PHYSICAL_GOODS,
    DONATION;
}
