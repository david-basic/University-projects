package hr.algebra.tabletopshop.model.users;

public enum RoleEnum {
    ROLE_USER,
    ROLE_ADMIN
}
