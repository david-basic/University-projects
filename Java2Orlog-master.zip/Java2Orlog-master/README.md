# Java2Orlog
Project for Java2 subject. Made a Orlog game lookalike from AC Valhalla using JavaFX. Simplified rules, same concept
