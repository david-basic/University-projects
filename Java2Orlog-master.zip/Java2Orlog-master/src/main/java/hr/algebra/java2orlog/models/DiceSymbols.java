package hr.algebra.java2orlog.models;

public enum DiceSymbols {
    Axe,
    Helmet,
    Helmet_S,
    Arrow,
    Arrow_S,
    Shield,
    Shield_S,
    Hand,
    Hand_S
}

