package hr.algebra.iis_validation.repositories;

import java.io.File;

public interface RngFactory {
    String ValidateRng(File xml);
}
