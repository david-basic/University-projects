# OOP.NET-project
OOP .NET subject project. Made with WPF, Windows Forms and contains a dll as well.
