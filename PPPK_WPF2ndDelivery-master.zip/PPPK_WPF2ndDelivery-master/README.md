# PPPK_WPF2ndDelivery
PPPK subject WPF app for 2nd delivery. Uses Azure.
