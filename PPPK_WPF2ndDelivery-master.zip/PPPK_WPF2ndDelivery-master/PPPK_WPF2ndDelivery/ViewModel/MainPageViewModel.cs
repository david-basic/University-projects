﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPPK_WPF2ndDelivery.ViewModel
{
    public class MainPageViewModel
    {
        public string Title { get; }
        public MainPageViewModel()
        {
            Title = "Welcome to VetManager app!";
        }
    }
}
