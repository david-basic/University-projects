package hr.algebra.fruity.service;

import hr.algebra.fruity.model.Email;

public interface EmailSenderService {

  void send(Email email);

}
