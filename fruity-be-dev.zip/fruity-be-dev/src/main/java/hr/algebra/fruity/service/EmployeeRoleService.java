package hr.algebra.fruity.service;

import hr.algebra.fruity.model.EmployeeRole;
import hr.algebra.fruity.model.codebook.EmployeeRoles;

public interface EmployeeRoleService {

  EmployeeRole getEmployeeRole(EmployeeRoles employeeRole);

}
