package hr.algebra.fruity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruityApiApplication {

  public static void main(String[] args) {
    SpringApplication.run(FruityApiApplication.class, args);
  }

}
